/**
 * Run Tax Check Script
 * Runs tax validation logic for loan requests
 * 
 * Usage: node scripts/run-tax-check.js <loan-id> [--json] [--verbose]
 *        node scripts/run-tax-check.js --batch <input-file.json> [--output <output-file.json>]
 * 
 * @module run-tax-check
 */

const fs = require('fs');
const path = require('path');
const yaml = require('js-yaml');

// Import tax-check module
const { 
  runTaxCheck, 
  clearCache, 
  getCacheStats,
  CONFIG: taxConfig 
} = require('../webhook/tax-check');

// Configuration
const CONFIG = {
  inputDir: path.join(__dirname, '..', 'data', 'input'),
  outputDir: path.join(__dirname, '..', 'data', 'output'),
  taxDataDir: path.join(__dirname, '..', 'data', 'tax'),
  defaultOutputFormat: 'json',
  batchSize: 100
};

/**
 * Main function for running tax checks
 */
async function runTaxCheckScript(args) {
  console.log('=== Tax Check Script ===\n');
  
  const options = parseArguments(args);
  
  if (options.help) {
    printHelp();
    return;
  }
  
  if (options.cacheStats) {
    printCacheStats();
    return;
  }
  
  if (options.clearCache) {
    clearCache();
    console.log('✓ Tax check cache cleared\n');
    return;
  }
  
  try {
    if (options.batch) {
      await runBatchTaxCheck(options);
    } else if (options.loanId) {
      await runSingleTaxCheck(options.loanId, options);
    } else {
      console.error('Error: No loan ID specified. Use --help for usage information.');
      process.exit(1);
    }
    
  } catch (error) {
    console.error('Tax check failed:', error.message);
    process.exit(1);
  }
}

/**
 * Parse command line arguments
 */
function parseArguments(args) {
  const options = {
    loanId: null,
    batch: false,
    inputFile: null,
    outputFile: null,
    format: CONFIG.defaultOutputFormat,
    verbose: false,
    help: false,
    cacheStats: false,
    clearCache: false
  };
  
  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--help' || arg === '-h') {
      options.help = true;
    } else if (arg === '--batch' || arg === '-b') {
      options.batch = true;
      options.inputFile = args[++i];
    } else if (arg === '--output' || arg === '-o') {
      options.outputFile = args[++i];
    } else if (arg === '--format' || arg === '-f') {
      options.format = args[++i];
    } else if (arg === '--verbose' || arg === '-v') {
      options.verbose = true;
    } else if (arg === '--cache-stats') {
      options.cacheStats = true;
    } else if (arg === '--clear-cache') {
      options.clearCache = true;
    } else if (arg === '--json') {
      options.format = 'json';
    } else if (!arg.startsWith('--')) {
      options.loanId = arg;
    }
  }
  
  return options;
}

/**
 * Run tax check for a single loan
 */
async function runSingleTaxCheck(loanId, options) {
  console.log(`Running tax check for loan: ${loanId}\n`);
  
  // Load loan data
  const loanData = await loadLoanData(loanId);
  
  if (!loanData) {
    console.error(`Error: Loan data not found for ID: ${loanId}`);
    process.exit(1);
  }
  
  if (options.verbose) {
    console.log('Loan Data:');
    console.log(JSON.stringify(loanData, null, 2));
    console.log('');
  }
  
  // Build tax check request
  const checkRequest = buildTaxCheckRequest(loanData);
  
  if (options.verbose) {
    console.log('Tax Check Request:');
    console.log(JSON.stringify(checkRequest, null, 2));
    console.log('');
  }
  
  // Run tax check
  const result = await runTaxCheck(checkRequest);
  
  // Output results
  if (options.format === 'json') {
    console.log(JSON.stringify(result, null, 2));
  } else {
    printHumanReadableResult(result);
  }
  
  // Save result if output file specified
  if (options.outputFile) {
    await saveResult(options.outputFile, result);
    console.log(`\n✓ Results saved to: ${options.outputFile}`);
  }
  
  // Exit with appropriate code
  if (!result.valid) {
    process.exit(1);
  }
}

/**
 * Run batch tax checks
 */
async function runBatchTaxCheck(options) {
  if (!options.inputFile) {
    console.error('Error: Batch mode requires input file. Use --batch <input-file>');
    process.exit(1);
  }
  
  console.log(`Running batch tax checks from: ${options.inputFile}\n`);
  
  // Load input data
  let inputData;
  
  try {
    const content = fs.readFileSync(options.inputFile, 'utf8');
    inputData = JSON.parse(content);
  } catch (error) {
    console.error(`Error reading input file: ${error.message}`);
    process.exit(1);
  }
  
  // Ensure input is an array
  const loans = Array.isArray(inputData) ? inputData : [inputData];
  
  console.log(`Found ${loans.length} loans to process\n`);
  
  // Process in batches
  const results = [];
  const batchSize = options.batchSize || CONFIG.batchSize;
  
  for (let i = 0; i < loans.length; i += batchSize) {
    const batch = loans.slice(i, i + batchSize);
    console.log(`Processing batch ${Math.floor(i / batchSize) + 1} (${batch.length} loans)...`);
    
    const batchResults = await Promise.all(
      batch.map(async (loan) => {
        const checkRequest = buildTaxCheckRequest(loan);
        const result = await runTaxCheck(checkRequest);
        
        return {
          loan_id: loan.loan_id || loan.id,
          valid: result.valid,
          federal_valid: result.federal_valid,
          state_valid: result.state_valid,
          usury_compliant: result.usury_compliant,
          findings_count: result.findings?.length || 0,
          result
        };
      })
    );
    
    results.push(...batchResults);
    
    // Show progress
    const processed = Math.min(i + batchSize, loans.length);
    console.log(`  Processed ${processed}/${loans.length} loans\n`);
  }
  
  // Print batch summary
  printBatchSummary(results);
  
  // Save results
  const outputFile = options.outputFile || 
    options.inputFile.replace('.json', '-results.json');
  
  await saveResult(outputFile, results);
  console.log(`\n✓ Batch results saved to: ${outputFile}`);
  
  // Exit with appropriate code if any loans failed
  const failedCount = results.filter(r => !r.valid).length;
  if (failedCount > 0) {
    console.log(`\n⚠ ${failedCount} loans failed tax validation`);
    process.exit(1);
  }
}

/**
 * Load loan data from file
 */
async function loadLoanData(loanId) {
  // Try multiple locations
  const possiblePaths = [
    path.join(CONFIG.inputDir, `${loanId}.json`),
    path.join(__dirname, '..', 'data', 'loans', `${loanId}.json`),
    `${loanId}.json`
  ];
  
  for (const filePath of possiblePaths) {
    try {
      if (fs.existsSync(filePath)) {
        const content = fs.readFileSync(filePath, 'utf8');
        return JSON.parse(content);
      }
    } catch (error) {
      // Continue to next path
    }
  }
  
  // Return sample data if no file found (for testing)
  return {
    loan_id: loanId,
    borrower_id: 'sample-borrower',
    loan_amount: 25000,
    loan_purpose: 'debt_consolidation',
    interest_rate: 0.12,
    loan_term_months: 36,
    borrower_state: 'CA',
    tax_lien_check: true,
    refund_offset_check: true,
    withholding_required: false,
    income_verification: true
  };
}

/**
 * Build tax check request from loan data
 */
function buildTaxCheckRequest(loanData) {
  return {
    borrower_id: loanData.borrower_id,
    loan_id: loanData.loan_id || loanData.id,
    loan_amount: loanData.loan_amount,
    loan_purpose: loanData.loan_purpose,
    interest_rate: loanData.interest_rate,
    loan_term_months: loanData.loan_term_months,
    borrower_state: loanData.borrower_state || loanData.state,
    tax_lien_check: loanData.tax_lien_check !== false,
    refund_offset_check: loanData.refund_offset_check !== false,
    withholding_required: loanData.withholding_required || false,
    withholding_rate: loanData.withholding_rate,
    state_withholding_rate: loanData.state_withholding_rate,
    income_verification: loanData.income_verification !== false
  };
}

/**
 * Print human-readable result
 */
function printHumanReadableResult(result) {
  console.log('=== Tax Validation Results ===\n');
  
  console.log(`Overall Valid: ${result.valid ? '✓ Yes' : '✗ No'}`);
  console.log(`Federal Tax Valid: ${result.federal_valid ? '✓ Yes' : '✗ No'}`);
  console.log(`State Tax Valid: ${result.state_valid ? '✓ Yes' : '✗ No'}`);
  console.log(`Usury Compliant: ${result.usury_compliant ? '✓ Yes' : '✗ No'}`);
  
  if (result.findings && result.findings.length > 0) {
    console.log(`\nFindings (${result.findings.length}):`);
    
    for (const finding of result.findings) {
      const icon = finding.severity === 'critical' ? '🔴' : 
                   finding.severity === 'high' ? '🟠' : 
                   finding.severity === 'medium' ? '🟡' : '⚪';
      console.log(`  ${icon} [${finding.code}] ${finding.message}`);
      
      if (finding.details) {
        console.log(`     Details: ${JSON.stringify(finding.details)}`);
      }
    }
  }
  
  if (result.warnings && result.warnings.length > 0) {
    console.log(`\nWarnings (${result.warnings.length}):`);
    
    for (const warning of result.warnings) {
      console.log(`  ⚠ [${warning.code}] ${warning.message}`);
    }
  }
  
  if (result.tax_implications) {
    console.log('\nTax Implications:');
    console.log(`  Deductible Interest: ${result.tax_implications.deductible_interest ? 'Yes' : 'No'}`);
    console.log(`  Deductible Fees: ${result.tax_implications.deductible_fees ? 'Yes' : 'No'}`);
    console.log(`  Taxable Forgiveness: ${result.tax_implications.taxable_forgiveness ? 'Yes' : 'No'}`);
    
    if (result.tax_implications.forms_required?.length > 0) {
      console.log(`  Forms Required: ${result.tax_implications.forms_required.join(', ')}`);
    }
    
    if (result.tax_implications.estimated_annual_interest) {
      console.log(`  Est. Annual Interest: $${result.tax_implications.estimated_annual_interest.toFixed(2)}`);
    }
  }
  
  console.log('\nMetadata:');
  console.log(`  Validation Timestamp: ${result.metadata?.validation_timestamp || 'N/A'}`);
  console.log(`  Federal Status: ${result.metadata?.federalStatus || 'N/A'}`);
  console.log(`  State Status: ${result.metadata?.stateStatus || 'N/A'}`);
  console.log(`  Usury Status: ${result.metadata?.usuryStatus || 'N/A'}`);
}

/**
 * Print batch summary
 */
function printBatchSummary(results) {
  const total = results.length;
  const valid = results.filter(r => r.valid).length;
  const invalid = total - valid;
  const federalInvalid = results.filter(r => !r.federal_valid).length;
  const stateInvalid = results.filter(r => !r.state_valid).length;
  const usuryInvalid = results.filter(r => !r.usury_compliant).length;
  
  console.log('\n=== Batch Summary ===');
  console.log(`Total Loans: ${total}`);
  console.log(`Valid: ${valid} (${((valid/total)*100).toFixed(1)}%)`);
  console.log(`Invalid: ${invalid} (${((invalid/total)*100).toFixed(1)}%)`);
  console.log(`  - Federal Tax Issues: ${federalInvalid}`);
  console.log(`  - State Tax Issues: ${stateInvalid}`);
  console.log(`  - Usury Compliance Issues: ${usuryInvalid}`);
}

/**
 * Save result to file
 */
async function saveResult(outputPath, result) {
  try {
    // Ensure output directory exists
    const outputDir = path.dirname(outputPath);
    if (!fs.existsSync(outputDir)) {
      fs.mkdirSync(outputDir, { recursive: true });
    }
    
    const content = typeof result === 'string' ? result : JSON.stringify(result, null, 2);
    fs.writeFileSync(outputPath, content);
    
  } catch (error) {
    console.error(`Error saving result: ${error.message}`);
    throw error;
  }
}

/**
 * Print cache statistics
 */
function printCacheStats() {
  const stats = getCacheStats();
  
  console.log('=== Tax Check Cache Statistics ===\n');
  console.log(`Total Entries: ${stats.totalEntries}`);
  console.log(`Valid Entries: ${stats.validEntries}`);
  console.log(`Expired Entries: ${stats.expiredEntries}`);
  console.log(`Max Age: ${(stats.maxAgeMs / 3600000).toFixed(1)} hours`);
}

/**
 * Print help message
 */
function printHelp() {
  console.log(`
Tax Check Script
================

Usage:
  node scripts/run-tax-check.js <loan-id> [options]
  node scripts/run-tax-check.js --batch <input-file.json> [options]
  node scripts/run-tax-check.js --cache-stats
  node scripts/run-tax-check.js --clear-cache

Options:
  -h, --help           Show this help message
  -b, --batch <file>   Run tax checks in batch mode
  -o, --output <file>  Save results to file
  -f, --format         Output format (json, text) [default: json]
  -v, --verbose        Show detailed information
      --cache-stats    Show cache statistics
      --clear-cache    Clear the tax check cache
      --json           Output in JSON format (default)

Examples:
  # Single loan check
  node scripts/run-tax-check.js LOAN-001 --verbose
  
  # Batch processing
  node scripts/run-tax-check.js --batch loans.json --output results.json --verbose
  
  # Check cache status
  node scripts/run-tax-check.js --cache-stats
`);
}

// CLI Interface
if (require.main === module) {
  runTaxCheckScript(process.argv.slice(2));
}

module.exports = {
  runTaxCheckScript,
  loadLoanData,
  buildTaxCheckRequest,
  CONFIG
};
