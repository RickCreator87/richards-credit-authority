/**
 * Sync Cross-Repo Script
 * Syncs with all linked repositories
 * 
 * Usage: node scripts/sync-cross-repo.js [--all] [--repo <repo-name>] [--verbose]
 * 
 * @module sync-cross-repo
 */

const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');
const { promisify } = require('util');

const execAsync = promisify(exec);

// Configuration
const CONFIG = {
  baseDir: path.join(__dirname, '..'),
  reposDir: path.join(__dirname, '..', '..'),
  linkedRepos: {
    'loaner-ledger': {
      url: 'https://github.com/RickCreator87/richard-loaner-ledger',
      localPath: 'richard-loaner-ledger',
      syncDirection: 'bidirectional',
      priority: 'high'
    },
    'agreements': {
      url: 'https://github.com/RickCreator87/richard-agreements',
      localPath: 'richard-agreements',
      syncDirection: 'outbound',
      priority: 'medium'
    },
    'credit-tools': {
      url: 'https://github.com/RickCreator87/richard-credit-tools',
      localPath: 'richard-credit-tools',
      syncDirection: 'outbound',
      priority: 'medium'
    },
    'loan-disbursement': {
      url: 'https://github.com/RickCreator87/richard-loan-disbursement',
      localPath: 'richard-loan-disbursement',
      syncDirection: 'outbound',
      priority: 'critical'
    }
  },
  syncToken: process.env.SYNC_TOKEN || '',
  maxRetries: 3,
  retryDelayMs: 5000,
  timeoutMs: 120000
};

// Sync results storage
const syncResults = {};

/**
 * Main sync function
 */
async function syncCrossRepo(args) {
  console.log('=== Cross-Repository Sync ===\n');
  
  const options = parseArguments(args);
  
  if (options.help) {
    printHelp();
    return;
  }
  
  const startTime = Date.now();
  
  try {
    // Determine which repos to sync
    const reposToSync = options.repo 
      ? [options.repo] 
      : (options.all ? Object.keys(CONFIG.linkedRepos) : ['loaner-ledger']);
    
    console.log(`Repositories to sync: ${reposToSync.join(', ')}\n`);
    
    // Validate repo names
    const invalidRepos = reposToSync.filter(r => !CONFIG.linkedRepos[r]);
    if (invalidRepos.length > 0) {
      console.error(`Error: Unknown repositories: ${invalidRepos.join(', ')}`);
      console.error(`Valid repositories: ${Object.keys(CONFIG.linkedRepos).join(', ')}`);
      process.exit(1);
    }
    
    // Sync each repository
    for (const repoName of reposToSync) {
      const repoConfig = CONFIG.linkedRepos[repoName];
      console.log(`\n--- Syncing ${repoName} ---`);
      
      try {
        const result = await syncRepository(repoName, repoConfig, options);
        syncResults[repoName] = result;
        
        if (result.success) {
          console.log(`✓ ${repoName} sync completed successfully`);
          if (options.verbose) {
            console.log(`  Changes: ${result.changes}`);
            console.log(`  Duration: ${result.duration}ms`);
          }
        } else {
          console.log(`✗ ${repoName} sync failed: ${result.error}`);
        }
        
      } catch (error) {
        syncResults[repoName] = {
          success: false,
          error: error.message
        };
        console.log(`✗ ${repoName} sync error: ${error.message}`);
      }
    }
    
    // Print summary
    const summary = printSummary(startTime, options.verbose);
    
    // Save sync report
    await saveSyncReport(summary);
    
    // Exit with appropriate code
    const failedRepos = Object.values(syncResults).filter(r => !r.success);
    if (failedRepos.length > 0 && !options.force) {
      process.exit(1);
    }
    
  } catch (error) {
    console.error('Sync failed:', error.message);
    process.exit(1);
  }
}

/**
 * Sync a single repository
 */
async function syncRepository(repoName, repoConfig, options) {
  const startTime = Date.now();
  let changes = 0;
  
  try {
    // Check if local repository exists
    const localPath = path.join(CONFIG.reposDir, repoConfig.localPath);
    const repoExists = fs.existsSync(localPath);
    
    if (!repoExists && options.verbose) {
      console.log(`  Repository not found locally, cloning...`);
    }
    
    // Clone or update repository
    if (!repoExists) {
      await cloneRepository(repoName, repoConfig);
    } else {
      await updateRepository(repoName, repoConfig);
    }
    
    // Perform sync based on direction
    switch (repoConfig.syncDirection) {
      case 'bidirectional':
        changes = await performBidirectionalSync(repoName, repoConfig, options);
        break;
      case 'outbound':
        changes = await performOutboundSync(repoName, repoConfig, options);
        break;
      case 'inbound':
        changes = await performInboundSync(repoName, repoConfig, options);
        break;
    }
    
    return {
      success: true,
      changes,
      duration: Date.now() - startTime,
      timestamp: new Date().toISOString()
    };
    
  } catch (error) {
    return {
      success: false,
      error: error.message,
      duration: Date.now() - startTime
    };
  }
}

/**
 * Clone a repository
 */
async function cloneRepository(repoName, repoConfig) {
  const localPath = path.join(CONFIG.reposDir, repoConfig.localPath);
  
  let lastError;
  
  for (let attempt = 1; attempt <= CONFIG.maxRetries; attempt++) {
    try {
      const authUrl = repoConfig.url.replace(
        'https://',
        `https://${CONFIG.syncToken}@`
      );
      
      await execAsync(`git clone ${authUrl} ${localPath}`, {
        timeout: CONFIG.timeoutMs
      });
      
      return;
      
    } catch (error) {
      lastError = error;
      console.log(`  Clone attempt ${attempt} failed, retrying...`);
      await new Promise(resolve => setTimeout(resolve, CONFIG.retryDelayMs * attempt));
    }
  }
  
  throw lastError || new Error('Clone failed after retries');
}

/**
 * Update a repository
 */
async function updateRepository(repoName, repoConfig) {
  const localPath = path.join(CONFIG.reposDir, repoConfig.localPath);
  
  try {
    // Fetch latest changes
    await execAsync('git fetch origin', {
      cwd: localPath,
      timeout: CONFIG.timeoutMs
    });
    
    // Get current branch
    const { stdout: currentBranch } = await execAsync(
      'git rev-parse --abbrev-ref HEAD',
      { cwd: localPath }
    );
    
    // Pull latest changes
    await execAsync(`git pull origin ${currentBranch.trim()}`, {
      cwd: localPath,
      timeout: CONFIG.timeoutMs
    });
    
  } catch (error) {
    // If pull fails, try rebase
    if (error.message.includes('could not apply') || 
        error.message.includes('conflict')) {
      console.log('  Resolving merge conflicts...');
      await execAsync('git rebase --abort', { cwd: localPath });
    }
    throw error;
  }
}

/**
 * Perform bidirectional sync
 */
async function performBidirectionalSync(repoName, repoConfig, options) {
  const localPath = path.join(CONFIG.reposDir, repoConfig.localPath);
  let changes = 0;
  
  try {
    // Get status
    const { stdout: status } = await execAsync('git status --porcelain', {
      cwd: localPath
    });
    
    if (status.trim()) {
      // Stage changes
      await execAsync('git add -A', { cwd: localPath });
      
      // Create commit
      const commitMessage = `Sync from credit-authority - ${new Date().toISOString()}`;
      await execAsync(`git commit -m "${commitMessage}"`, {
        cwd: localPath
      });
      
      // Push to remote
      const { stdout: branch } = await execAsync(
        'git rev-parse --abbrev-ref HEAD',
        { cwd: localPath }
      );
      
      await execAsync(`git push origin ${branch.trim()}`, {
        cwd: localPath,
        timeout: CONFIG.timeoutMs
      });
      
      changes = 1;
    }
    
    // Also pull any remote changes
    await updateRepository(repoName, repoConfig);
    
  } catch (error) {
    if (error.message.includes('nothing to commit')) {
      return 0;
    }
    throw error;
  }
  
  return changes;
}

/**
 * Perform outbound sync
 */
async function performOutboundSync(repoName, repoConfig, options) {
  const localPath = path.join(CONFIG.reposDir, repoConfig.localPath);
  const creditAuthPath = CONFIG.baseDir;
  let changes = 0;
  
  try {
    // Copy relevant files from credit-authority to target repo
    const syncPaths = getSyncPaths(repoName);
    
    for (const syncPath of syncPaths) {
      const sourcePath = path.join(creditAuthPath, syncPath);
      const destPath = path.join(localPath, syncPath);
      
      if (fs.existsSync(sourcePath)) {
        // Create destination directory if needed
        const destDir = path.dirname(destPath);
        if (!fs.existsSync(destDir)) {
          fs.mkdirSync(destDir, { recursive: true });
        }
        
        // Copy file or directory
        if (fs.statSync(sourcePath).isDirectory()) {
          await copyDirectory(sourcePath, destPath);
        } else {
          fs.copyFileSync(sourcePath, destPath);
        }
        
        changes++;
      }
    }
    
    // Commit and push changes
    if (changes > 0) {
      await execAsync('git add -A', { cwd: localPath });
      
      const commitMessage = `Sync from credit-authority - ${new Date().toISOString()}`;
      await execAsync(`git commit -m "${commitMessage}"`, {
        cwd: localPath
      });
      
      const { stdout: branch } = await execAsync(
        'git rev-parse --abbrev-ref HEAD',
        { cwd: localPath }
      );
      
      await execAsync(`git push origin ${branch.trim()}`, {
        cwd: localPath,
        timeout: CONFIG.timeoutMs
      });
    }
    
  } catch (error) {
    if (error.message.includes('nothing to commit')) {
      return 0;
    }
    throw error;
  }
  
  return changes;
}

/**
 * Perform inbound sync
 */
async function performInboundSync(repoName, repoConfig, options) {
  const localPath = path.join(CONFIG.reposDir, repoConfig.localPath);
  const creditAuthPath = CONFIG.baseDir;
  let changes = 0;
  
  try {
    // Copy relevant files from target repo to credit-authority
    const syncPaths = getSyncPaths(repoName);
    
    for (const syncPath of syncPaths) {
      const sourcePath = path.join(localPath, syncPath);
      const destPath = path.join(creditAuthPath, syncPath);
      
      if (fs.existsSync(sourcePath)) {
        // Create destination directory if needed
        const destDir = path.dirname(destPath);
        if (!fs.existsSync(destDir)) {
          fs.mkdirSync(destDir, { recursive: true });
        }
        
        // Copy file or directory
        if (fs.statSync(sourcePath).isDirectory()) {
          await copyDirectory(sourcePath, destPath);
        } else {
          fs.copyFileSync(sourcePath, destPath);
        }
        
        changes++;
      }
    }
    
  } catch (error) {
    throw error;
  }
  
  return changes;
}

/**
 * Get paths to sync for a repository
 */
function getSyncPaths(repoName) {
  const syncMappings = {
    'loaner-ledger': [
      'data/ledger/',
      'config/ledger.json'
    ],
    'agreements': [
      'templates/',
      'config/agreement-templates.json'
    ],
    'credit-tools': [
      'tools/',
      'config/credit-config.json'
    ],
    'loan-disbursement': [
      'data/disbursements/',
      'config/disbursement-config.json'
    ]
  };
  
  return syncMappings[repoName] || [];
}

/**
 * Copy directory recursively
 */
async function copyDirectory(source, destination) {
  if (!fs.existsSync(destination)) {
    fs.mkdirSync(destination, { recursive: true });
  }
  
  const entries = fs.readdirSync(source, { withFileTypes: true });
  
  for (const entry of entries) {
    const sourcePath = path.join(source, entry.name);
    const destPath = path.join(destination, entry.name);
    
    if (entry.isDirectory()) {
      await copyDirectory(sourcePath, destPath);
    } else {
      fs.copyFileSync(sourcePath, destPath);
    }
  }
}

/**
 * Parse command line arguments
 */
function parseArguments(args) {
  const options = {
    help: false,
    all: false,
    repo: null,
    verbose: false,
    force: false
  };
  
  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--help' || arg === '-h') {
      options.help = true;
    } else if (arg === '--all' || arg === '-a') {
      options.all = true;
    } else if (arg === '--repo' || arg === '-r') {
      options.repo = args[++i];
    } else if (arg === '--verbose' || arg === '-v') {
      options.verbose = true;
    } else if (arg === '--force' || arg === '-f') {
      options.force = true;
    }
  }
  
  return options;
}

/**
 * Print sync summary
 */
function printSummary(startTime, verbose) {
  const duration = Date.now() - startTime;
  const successful = Object.values(syncResults).filter(r => r.success).length;
  const failed = Object.keys(syncResults).length - successful;
  const totalChanges = Object.values(syncResults)
    .reduce((sum, r) => sum + (r.changes || 0), 0);
  
  console.log('\n=== Sync Summary ===');
  console.log(`Duration: ${duration}ms`);
  console.log(`Repositories: ${Object.keys(syncResults).length}`);
  console.log(`Successful: ${successful}`);
  console.log(`Failed: ${failed}`);
  console.log(`Total Changes: ${totalChanges}`);
  
  if (verbose) {
    console.log('\nDetails:');
    for (const [repo, result] of Object.entries(syncResults)) {
      const status = result.success ? '✓' : '✗';
      const changes = result.changes || 0;
      const duration = result.duration || 0;
      console.log(`  ${status} ${repo}: ${changes} changes, ${duration}ms`);
    }
  }
  
  return {
    duration,
    totalRepos: Object.keys(syncResults).length,
    successful,
    failed,
    totalChanges,
    results: syncResults,
    timestamp: new Date().toISOString()
  };
}

/**
 * Save sync report
 */
async function saveSyncReport(summary) {
  const reportPath = path.join(
    CONFIG.baseDir,
    'data',
    'sync-report.json'
  );
  
  try {
    // Ensure directory exists
    const reportDir = path.dirname(reportPath);
    if (!fs.existsSync(reportDir)) {
      fs.mkdirSync(reportDir, { recursive: true });
    }
    
    // Load existing reports
    let reports = [];
    if (fs.existsSync(reportPath)) {
      const content = fs.readFileSync(reportPath, 'utf8');
      reports = JSON.parse(content);
    }
    
    // Add new report
    reports.push(summary);
    
    // Keep last 100 reports
    if (reports.length > 100) {
      reports = reports.slice(-100);
    }
    
    // Save
    fs.writeFileSync(reportPath, JSON.stringify(reports, null, 2));
    
    console.log(`\n✓ Sync report saved to: ${reportPath}`);
    
  } catch (error) {
    console.error(`\nWarning: Failed to save sync report: ${error.message}`);
  }
}

/**
 * Print help message
 */
function printHelp() {
  console.log(`
Cross-Repository Sync Script
============================

Usage:
  node scripts/sync-cross-repo.js [options]
  node scripts/sync-cross-repo.js --repo <repo-name> [options]
  node scripts/sync-cross-repo.js --all [options]

Options:
  -h, --help           Show this help message
  -a, --all            Sync all linked repositories
  -r, --repo <name>    Sync specific repository only
  -v, --verbose        Show detailed output
  -f, --force          Continue even if some repos fail

Linked Repositories:
  - loaner-ledger      Bidirectional sync (high priority)
  - agreements         Outbound sync (medium priority)
  - credit-tools       Outbound sync (medium priority)
  - loan-disbursement  Outbound sync (critical priority)

Examples:
  # Sync all repositories
  node scripts/sync-cross-repo.js --all --verbose
  
  # Sync specific repository
  node scripts/sync-cross-repo.js --repo loaner-ledger
  
  # Verbose output
  node scripts/sync-cross-repo.js --all -v

Environment Variables:
  SYNC_TOKEN   GitHub personal access token for authentication
`);
}

// CLI Interface
if (require.main === module) {
  syncCrossRepo(process.argv.slice(2));
}

module.exports = {
  syncCrossRepo,
  syncRepository,
  CONFIG
};
