/**
 * Validate Permissions Script
 * Validates permission files against schema
 * 
 * Usage: node scripts/validate-permissions.js [--verbose] [--fix]
 * 
 * @module validate-permissions
 */

const fs = require('fs');
const path = require('path');
const yaml = require('js-yaml');

// Configuration
const CONFIG = {
  permissionDir: path.join(__dirname, '..', 'permission'),
  schemaFile: path.join(__dirname, '..', 'permission', 'permission-schema.json'),
  supportedExtensions: ['.yaml', '.yml', '.json'],
  maxFileSize: 1024 * 1024 // 1MB
};

// Validation counters
const stats = {
  filesScanned: 0,
  filesValid: 0,
  filesInvalid: 0,
  errors: [],
  warnings: []
};

/**
 * Main validation function
 */
async function validatePermissions(options = {}) {
  console.log('=== Permission File Validation ===\n');
  
  const startTime = Date.now();
  
  try {
    // Load schema
    const schema = await loadSchema();
    if (!schema) {
      console.error('ERROR: Could not load permission schema');
      process.exit(1);
    }
    
    // Get all permission files
    const files = getPermissionFiles();
    console.log(`Found ${files.length} permission files to validate\n`);
    
    // Validate each file
    for (const file of files) {
      await validateFile(file, schema, options);
    }
    
    // Print summary
    printSummary(stats, startTime);
    
    // Exit with appropriate code
    if (stats.filesInvalid > 0 && !options.fix) {
      process.exit(1);
    }
    
  } catch (error) {
    console.error('Validation failed:', error.message);
    process.exit(1);
  }
}

/**
 * Load the JSON schema
 */
async function loadSchema() {
  try {
    if (fs.existsSync(CONFIG.schemaFile)) {
      const content = fs.readFileSync(CONFIG.schemaFile, 'utf8');
      return JSON.parse(content);
    }
  } catch (error) {
    console.error('Error loading schema:', error.message);
  }
  return null;
}

/**
 * Get all permission files to validate
 */
function getPermissionFiles() {
  const files = [];
  
  if (!fs.existsSync(CONFIG.permissionDir)) {
    return files;
  }
  
  const entries = fs.readdirSync(CONFIG.permissionDir, { withFileTypes: true });
  
  for (const entry of entries) {
    const fullPath = path.join(CONFIG.permissionDir, entry.name);
    
    if (entry.isFile()) {
      const ext = path.extname(entry.name).toLowerCase();
      
      if (CONFIG.supportedExtensions.includes(ext)) {
        // Check file size
        const stats = fs.statSync(fullPath);
        if (stats.size <= CONFIG.maxFileSize) {
          files.push(fullPath);
        } else {
          stats.warnings.push({
            file: fullPath,
            message: 'File exceeds maximum size, skipping'
          });
        }
      }
    }
  }
  
  return files;
}

/**
 * Validate a single permission file
 */
async function validateFile(filePath, schema, options) {
  stats.filesScanned++;
  
  const relativePath = path.relative(process.cwd(), filePath);
  
  try {
    // Load file content
    const content = fs.readFileSync(filePath, 'utf8');
    let data;
    
    // Parse based on file type
    const ext = path.extname(filePath).toLowerCase();
    
    if (ext === '.json') {
      data = JSON.parse(content);
    } else if (ext === '.yaml' || ext === '.yml') {
      data = yaml.load(content);
    } else {
      throw new Error(`Unsupported file type: ${ext}`);
    }
    
    // Validate against schema
    const validationResult = validateAgainstSchema(data, schema);
    
    if (validationResult.valid) {
      stats.filesValid++;
      
      if (options.verbose) {
        console.log(`✓ ${relativePath} - Valid`);
      }
      
      // Check for additional best practices
      const bestPracticeResult = checkBestPractices(data, filePath);
      
      if (bestPracticeResult.warnings.length > 0) {
        stats.warnings.push(...bestPracticeResult.warnings.map(w => ({
          file: relativePath,
          ...w
        })));
        
        if (options.verbose) {
          for (const warning of bestPracticeResult.warnings) {
            console.log(`  ⚠ ${warning.code}: ${warning.message}`);
          }
        }
      }
      
    } else {
      stats.filesInvalid++;
      
      console.log(`✗ ${relativePath} - Invalid`);
      
      for (const error of validationResult.errors) {
        const errorEntry = {
          file: relativePath,
          ...error
        };
        stats.errors.push(errorEntry);
        
        console.log(`  ✗ ${error.path}: ${error.message}`);
        
        if (options.verbose && error.details) {
          console.log(`    Details: ${JSON.stringify(error.details)}`);
        }
      }
      
      // Auto-fix if requested
      if (options.fix) {
        await fixValidationErrors(filePath, data, validationResult.errors);
      }
    }
    
  } catch (error) {
    stats.filesInvalid++;
    
    const errorEntry = {
      file: relativePath,
      code: 'PARSE_ERROR',
      message: error.message,
      path: 'file'
    };
    stats.errors.push(errorEntry);
    
    console.log(`✗ ${relativePath} - Parse Error`);
    console.log(`  ✗ ${error.message}`);
  }
}

/**
 * Validate data against schema
 */
function validateAgainstSchema(data, schema) {
  const errors = [];
  
  if (!data) {
    return { valid: false, errors: [{ path: 'root', message: 'File is empty' }] };
  }
  
  // Check schema version
  if (data.schema_version && schema.$id) {
    const expectedVersion = schema.$id.split('/').pop().replace('.json', '');
    if (data.schema_version !== expectedVersion) {
      errors.push({
        path: 'schema_version',
        message: `Schema version mismatch: expected ${expectedVersion}, found ${data.schema_version}`
      });
    }
  }
  
  // Validate based on file type
  const fileType = determineFileType(data);
  
  if (fileType === 'permission_matrix') {
    validatePermissionMatrix(data, errors);
  } else if (fileType === 'allowed_actions') {
    validateAllowedActions(data, errors);
  } else if (fileType === 'restricted_actions') {
    validateRestrictedActions(data, errors);
  } else if (fileType === 'cross_repo_permissions') {
    validateCrossRepoPermissions(data, errors);
  } else if (fileType === 'validation_rules') {
    validateValidationRules(data, errors);
  } else if (fileType === 'permission_schema') {
    validatePermissionSchema(data, errors);
  }
  
  return {
    valid: errors.length === 0,
    errors
  };
}

/**
 * Determine file type from content
 */
function determineFileType(data) {
  if (data.roles && data.actions) return 'permission_matrix';
  if (data.founder_allowed_actions) return 'allowed_actions';
  if (data.dual_approval_required) return 'restricted_actions';
  if (data.repositories) return 'cross_repo_permissions';
  if (data.identity_validation) return 'validation_rules';
  if (data.$schema && data.$id) return 'permission_schema';
  return 'unknown';
}

/**
 * Validate permission matrix structure
 */
function validatePermissionMatrix(data, errors) {
  // Check for required fields
  if (!data.roles) {
    errors.push({ path: 'roles', message: 'Missing roles definition' });
  }
  
  if (!data.actions) {
    errors.push({ path: 'actions', message: 'Missing actions definition' });
  }
  
  // Validate role structure
  if (data.roles) {
    for (const [roleName, roleData] of Object.entries(data.roles)) {
      if (!roleData.authority_level) {
        errors.push({
          path: `roles.${roleName}.authority_level`,
          message: `Missing authority_level for role ${roleName}`
        });
      }
      
      if (!roleData.permissions || !Array.isArray(roleData.permissions)) {
        errors.push({
          path: `roles.${roleName}.permissions`,
          message: `Invalid or missing permissions for role ${roleName}`
        });
      }
    }
  }
  
  // Validate action structure
  if (data.actions) {
    for (const [actionName, actionData] of Object.entries(data.actions)) {
      if (actionData.requires_authority_level === undefined) {
        errors.push({
          path: `actions.${actionName}.requires_authority_level`,
          message: `Missing requires_authority_level for action ${actionName}`
        });
      }
    }
  }
}

/**
 * Validate allowed actions structure
 */
function validateAllowedActions(data, errors) {
  const roleLevels = ['founder_allowed_actions', 'admin_allowed_actions', 
                      'officer_allowed_actions', 'auditor_allowed_actions', 
                      'system_service_allowed_actions'];
  
  for (const level of roleLevels) {
    if (data[level]) {
      if (!Array.isArray(data[level])) {
        errors.push({ path: level, message: `${level} must be an array` });
      }
    }
  }
}

/**
 * Validate restricted actions structure
 */
function validateRestrictedActions(data, errors) {
  if (data.dual_approval_required) {
    if (!Array.isArray(data.dual_approval_required)) {
      errors.push({
        path: 'dual_approval_required',
        message: 'dual_approval_required must be an array'
      });
    }
  }
  
  if (data.tax_validation_required) {
    if (!Array.isArray(data.tax_validation_required)) {
      errors.push({
        path: 'tax_validation_required',
        message: 'tax_validation_required must be an array'
      });
    }
  }
}

/**
 * Validate cross-repo permissions structure
 */
function validateCrossRepoPermissions(data, errors) {
  if (!data.repositories) {
    errors.push({ path: 'repositories', message: 'Missing repositories definition' });
  }
  
  if (data.repositories) {
    const requiredRepos = ['loaner-ledger', 'agreements', 'credit-tools', 'loan-disbursement'];
    
    for (const repo of requiredRepos) {
      if (!data.repositories[repo]) {
        errors.push({
          path: `repositories.${repo}`,
          message: `Missing configuration for repository ${repo}`
        });
      }
    }
  }
}

/**
 * Validate validation rules structure
 */
function validateValidationRules(data, errors) {
  const ruleCategories = ['identity_validation', 'loan_request_validation', 
                          'credit_score_validation', 'risk_validation',
                          'tax_validation', 'governance_validation'];
  
  for (const category of ruleCategories) {
    if (data[category] === undefined) {
      errors.push({
        path: category,
        message: `Missing ${category} definition`
      });
    }
  }
}

/**
 * Validate permission schema structure
 */
function validatePermissionSchema(data, errors) {
  if (!data.$schema) {
    errors.push({ path: '$schema', message: 'Missing $schema reference' });
  }
  
  if (!data.$id) {
    errors.push({ path: '$id', message: 'Missing $id' });
  }
  
  if (!data.definitions) {
    errors.push({ path: 'definitions', message: 'Missing definitions' });
  }
}

/**
 * Check best practices
 */
function checkBestPractices(data, filePath) {
  const warnings = [];
  
  // Check for documentation
  if (!data.description && !data.$id) {
    warnings.push({
      code: 'MISSING_DESCRIPTION',
      message: 'File should have a description'
    });
  }
  
  // Check for version
  if (!data.version && !data.schema_version) {
    warnings.push({
      code: 'MISSING_VERSION',
      message: 'File should have a version field'
    });
  }
  
  // Check for last_updated
  if (!data.last_updated) {
    warnings.push({
      code: 'MISSING_LAST_UPDATED',
      message: 'File should have a last_updated field'
    });
  }
  
  return { warnings };
}

/**
 * Attempt to fix validation errors
 */
async function fixValidationErrors(filePath, data, errors) {
  console.log(`\nAttempting to fix errors in ${path.basename(filePath)}...`);
  
  let fixed = false;
  
  for (const error of errors) {
    if (error.code === 'MISSING_LAST_UPDATED') {
      data.last_updated = new Date().toISOString().split('T')[0];
      fixed = true;
    }
    
    if (error.code === 'MISSING_VERSION' && !data.version) {
      data.version = '1.0.0';
      fixed = true;
    }
  }
  
  if (fixed) {
    try {
      const ext = path.extname(filePath);
      let content;
      
      if (ext === '.json') {
        content = JSON.stringify(data, null, 2);
      } else {
        content = yaml.dump(data);
      }
      
      fs.writeFileSync(filePath, content);
      console.log(`  ✓ Fixed and saved ${path.basename(filePath)}`);
    } catch (error) {
      console.error(`  ✗ Failed to save fixes: ${error.message}`);
    }
  }
}

/**
 * Print validation summary
 */
function printSummary(stats, startTime) {
  const duration = Date.now() - startTime;
  
  console.log('\n=== Validation Summary ===');
  console.log(`Files scanned: ${stats.filesScanned}`);
  console.log(`Valid files: ${stats.filesValid}`);
  console.log(`Invalid files: ${stats.filesInvalid}`);
  console.log(`Duration: ${duration}ms\n`);
  
  if (stats.errors.length > 0) {
    console.log(`Errors (${stats.errors.length}):`);
    
    // Group errors by type
    const errorGroups = {};
    for (const error of stats.errors) {
      const key = error.code || 'UNKNOWN';
      if (!errorGroups[key]) {
        errorGroups[key] = [];
      }
      errorGroups[key].push(error);
    }
    
    for (const [code, group] of Object.entries(errorGroups)) {
      console.log(`  ${code}: ${group.length} occurrences`);
    }
    console.log('');
  }
  
  if (stats.warnings.length > 0) {
    console.log(`Warnings (${stats.warnings.length}):`);
    const warningGroups = {};
    for (const warning of stats.warnings) {
      const key = warning.code || 'UNKNOWN';
      if (!warningGroups[key]) {
        warningGroups[key] = [];
      }
      warningGroups[key].push(warning);
    }
    
    for (const [code, group] of Object.entries(warningGroups)) {
      console.log(`  ${code}: ${group.length} occurrences`);
    }
    console.log('');
  }
}

// CLI Interface
if (require.main === module) {
  const args = process.argv.slice(2);
  const options = {
    verbose: args.includes('--verbose') || args.includes('-v'),
    fix: args.includes('--fix') || args.includes('-f')
  };
  
  validatePermissions(options);
}

module.exports = {
  validatePermissions,
  CONFIG
};
