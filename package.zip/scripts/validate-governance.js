/**
 * Validate Governance Script
 * Validates governance files against schema
 * 
 * Usage: node scripts/validate-governance.js [--verbose] [--fix]
 * 
 * @module validate-governance
 */

const fs = require('fs');
const path = require('path');
const yaml = require('js-yaml');

// Configuration
const CONFIG = {
  governanceDir: path.join(__dirname, '..', 'governance'),
  schemaFile: path.join(__dirname, '..', 'governance', 'governance-schema.json'),
  supportedExtensions: ['.yaml', '.yml', '.json', '.md'],
  maxFileSize: 1024 * 1024 // 1MB
};

// Validation counters
const stats = {
  filesScanned: 0,
  filesValid: 0,
  filesInvalid: 0,
  errors: [],
  warnings: []
};

/**
 * Main validation function
 */
async function validateGovernance(options = {}) {
  console.log('=== Governance File Validation ===\n');
  
  const startTime = Date.now();
  
  try {
    // Load schema
    const schema = await loadSchema();
    if (!schema) {
      console.error('ERROR: Could not load governance schema');
      process.exit(1);
    }
    
    // Get all governance files
    const files = getGovernanceFiles();
    console.log(`Found ${files.length} governance files to validate\n`);
    
    // Validate each file
    for (const file of files) {
      await validateFile(file, schema, options);
    }
    
    // Validate cross-file consistency
    await validateCrossFileConsistency(options);
    
    // Print summary
    printSummary(stats, startTime);
    
    // Exit with appropriate code
    if (stats.filesInvalid > 0 && !options.fix) {
      process.exit(1);
    }
    
  } catch (error) {
    console.error('Validation failed:', error.message);
    process.exit(1);
  }
}

/**
 * Load the JSON schema
 */
async function loadSchema() {
  try {
    if (fs.existsSync(CONFIG.schemaFile)) {
      const content = fs.readFileSync(CONFIG.schemaFile, 'utf8');
      return JSON.parse(content);
    }
  } catch (error) {
    console.error('Error loading schema:', error.message);
  }
  return null;
}

/**
 * Get all governance files to validate
 */
function getGovernanceFiles() {
  const files = [];
  
  if (!fs.existsSync(CONFIG.governanceDir)) {
    return files;
  }
  
  const entries = fs.readdirSync(CONFIG.governanceDir, { withFileTypes: true });
  
  for (const entry of entries) {
    const fullPath = path.join(CONFIG.governanceDir, entry.name);
    
    if (entry.isFile()) {
      const ext = path.extname(entry.name).toLowerCase();
      
      if (CONFIG.supportedExtensions.includes(ext)) {
        const stats = fs.statSync(fullPath);
        if (stats.size <= CONFIG.maxFileSize) {
          files.push(fullPath);
        } else {
          stats.warnings.push({
            file: fullPath,
            message: 'File exceeds maximum size, skipping'
          });
        }
      }
    }
  }
  
  return files;
}

/**
 * Validate a single governance file
 */
async function validateFile(filePath, schema, options) {
  stats.filesScanned++;
  
  const relativePath = path.relative(process.cwd(), filePath);
  const ext = path.extname(filePath).toLowerCase();
  
  // Skip markdown files (they're documentation)
  if (ext === '.md') {
    if (options.verbose) {
      console.log(`✓ ${relativePath} - Skipped (documentation)`);
    }
    return;
  }
  
  try {
    // Load file content
    const content = fs.readFileSync(filePath, 'utf8');
    let data;
    
    // Parse based on file type
    if (ext === '.json') {
      data = JSON.parse(content);
    } else if (ext === '.yaml' || ext === '.yml') {
      data = yaml.load(content);
    } else {
      return;
    }
    
    // Validate against schema
    const validationResult = validateAgainstSchema(data, schema);
    
    if (validationResult.valid) {
      stats.filesValid++;
      
      if (options.verbose) {
        console.log(`✓ ${relativePath} - Valid`);
      }
      
      // Check for additional best practices
      const bestPracticeResult = checkBestPractices(data, filePath);
      
      if (bestPracticeResult.warnings.length > 0) {
        stats.warnings.push(...bestPracticeResult.warnings.map(w => ({
          file: relativePath,
          ...w
        })));
        
        if (options.verbose) {
          for (const warning of bestPracticeResult.warnings) {
            console.log(`  ⚠ ${warning.code}: ${warning.message}`);
          }
        }
      }
      
    } else {
      stats.filesInvalid++;
      
      console.log(`✗ ${relativePath} - Invalid`);
      
      for (const error of validationResult.errors) {
        const errorEntry = {
          file: relativePath,
          ...error
        };
        stats.errors.push(errorEntry);
        
        console.log(`  ✗ ${error.path}: ${error.message}`);
        
        if (options.verbose && error.details) {
          console.log(`    Details: ${JSON.stringify(error.details)}`);
        }
      }
      
      // Auto-fix if requested
      if (options.fix) {
        await fixValidationErrors(filePath, data, validationResult.errors);
      }
    }
    
  } catch (error) {
    stats.filesInvalid++;
    
    const errorEntry = {
      file: relativePath,
      code: 'PARSE_ERROR',
      message: error.message,
      path: 'file'
    };
    stats.errors.push(errorEntry);
    
    console.log(`✗ ${relativePath} - Parse Error`);
    console.log(`  ✗ ${error.message}`);
  }
}

/**
 * Validate data against schema
 */
function validateAgainstSchema(data, schema) {
  const errors = [];
  
  if (!data) {
    return { valid: false, errors: [{ path: 'root', message: 'File is empty' }] };
  }
  
  // Check schema version
  if (data.schema_version && schema.$id) {
    const expectedVersion = schema.$id.split('/').pop().replace('.json', '');
    if (data.schema_version !== expectedVersion) {
      errors.push({
        path: 'schema_version',
        message: `Schema version mismatch: expected ${expectedVersion}, found ${data.schema_version}`
      });
    }
  }
  
  // Validate based on file type
  const fileType = determineFileType(data);
  
  if (fileType === 'approval_workflow') {
    validateApprovalWorkflow(data, errors);
  } else if (fileType === 'milestone_rules') {
    validateMilestoneRules(data, errors);
  } else if (fileType === 'audit_rules') {
    validateAuditRules(data, errors);
  } else if (fileType === 'risk_controls') {
    validateRiskControls(data, errors);
  } else if (fileType === 'governance_schema') {
    validateGovernanceSchema(data, errors);
  }
  
  return {
    valid: errors.length === 0,
    errors
  };
}

/**
 * Determine file type from content
 */
function determineFileType(data) {
  if (data.workflows) return 'approval_workflow';
  if (data.milestones) return 'milestone_rules';
  if (data.event_categories) return 'audit_rules';
  if (data.risk_calculation) return 'risk_controls';
  if (data.$schema && data.$id) return 'governance_schema';
  return 'unknown';
}

/**
 * Validate approval workflow structure
 */
function validateApprovalWorkflow(data, errors) {
  if (!data.workflows) {
    errors.push({ path: 'workflows', message: 'Missing workflows definition' });
    return;
  }
  
  // Validate each workflow
  for (const [workflowName, workflow] of Object.entries(data.workflows)) {
    if (!workflow.initial_state) {
      errors.push({
        path: `workflows.${workflowName}.initial_state`,
        message: `Missing initial_state for workflow ${workflowName}`
      });
    }
    
    if (!workflow.final_states || !Array.isArray(workflow.final_states)) {
      errors.push({
        path: `workflows.${workflowName}.final_states`,
        message: `Missing or invalid final_states for workflow ${workflowName}`
      });
    }
    
    if (!workflow.states || !Array.isArray(workflow.states)) {
      errors.push({
        path: `workflows.${workflowName}.states`,
        message: `Missing or invalid states for workflow ${workflowName}`
      });
    }
    
    // Validate state transitions
    if (workflow.states) {
      const stateNames = new Set(workflow.states.map(s => s.state));
      
      for (const state of workflow.states) {
        if (state.transitions) {
          for (const transition of state.transitions) {
            if (!stateNames.has(transition.target)) {
              errors.push({
                path: `workflows.${workflowName}.states.${state.state}.transitions`,
                message: `Transition target '${transition.target}' not found in states`
              });
            }
          }
        }
      }
    }
  }
  
  // Validate approval paths
  if (data.approval_paths) {
    for (const [pathName, pathData] of Object.entries(data.approval_paths)) {
      if (!pathData.amount_range) {
        errors.push({
          path: `approval_paths.${pathName}.amount_range`,
          message: `Missing amount_range for approval path ${pathName}`
        });
      }
      
      if (!pathData.required_approvers || !Array.isArray(pathData.required_approvers)) {
        errors.push({
          path: `approval_paths.${pathName}.required_approvers`,
          message: `Missing or invalid required_approvers for path ${pathName}`
        });
      }
    }
  }
}

/**
 * Validate milestone rules structure
 */
function validateMilestoneRules(data, errors) {
  if (!data.milestones) {
    errors.push({ path: 'milestones', message: 'Missing milestones definition' });
    return;
  }
  
  // Check milestone levels
  const milestoneLevels = new Set();
  
  for (const [milestoneName, milestone] of Object.entries(data.milestones)) {
    if (milestone.level === undefined) {
      errors.push({
        path: `milestones.${milestoneName}.level`,
        message: `Missing level for milestone ${milestoneName}`
      });
    } else {
      if (milestoneLevels.has(milestone.level)) {
        errors.push({
          path: `milestones.${milestoneName}.level`,
          message: `Duplicate milestone level: ${milestone.level}`
        });
      }
      milestoneLevels.add(milestone.level);
    }
    
    if (!milestone.name) {
      errors.push({
        path: `milestones.${milestoneName}.name`,
        message: `Missing name for milestone ${milestoneName}`
      });
    }
    
    if (!milestone.requirements || !Array.isArray(milestone.requirements)) {
      errors.push({
        path: `milestones.${milestoneName}.requirements`,
        message: `Missing or invalid requirements for milestone ${milestoneName}`
      });
    }
  }
  
  // Validate progression rules
  if (data.progression_rules) {
    if (data.progression_rules.advancement_criteria) {
      for (const criteria of data.progression_rules.advancement_criteria) {
        if (criteria.from_milestone >= criteria.to_milestone) {
          errors.push({
            path: 'progression_rules.advancement_criteria',
            message: 'from_milestone must be less than to_milestone'
          });
        }
      }
    }
  }
}

/**
 * Validate audit rules structure
 */
function validateAuditRules(data, errors) {
  if (!data.event_categories) {
    errors.push({ path: 'event_categories', message: 'Missing event_categories definition' });
    return;
  }
  
  // Validate event categories
  for (const [categoryName, category] of Object.entries(data.event_categories)) {
    if (!category.description) {
      errors.push({
        path: `event_categories.${categoryName}.description`,
        message: `Missing description for event category ${categoryName}`
      });
    }
    
    if (!category.priority) {
      errors.push({
        path: `event_categories.${categoryName}.priority`,
        message: `Missing priority for event category ${categoryName}`
      });
    }
    
    if (!category.retention_days) {
      errors.push({
        path: `event_categories.${categoryName}.retention_days`,
        message: `Missing retention_days for event category ${categoryName}`
      });
    }
  }
  
  // Validate required fields
  if (!data.audit_fields) {
    errors.push({ path: 'audit_fields', message: 'Missing audit_fields definition' });
  }
  
  // Validate access control
  if (data.access_control) {
    for (const access of data.access_control) {
      if (!access.role) {
        errors.push({
          path: 'access_control.entry',
          message: 'Missing role in access control entry'
        });
      }
      
      if (!access.access_level) {
        errors.push({
          path: `access_control.${access.role}`,
          message: `Missing access_level for role ${access.role}`
        });
      }
    }
  }
}

/**
 * Validate risk controls structure
 */
function validateRiskControls(data, errors) {
  if (!data.risk_calculation) {
    errors.push({ path: 'risk_calculation', message: 'Missing risk_calculation definition' });
    return;
  }
  
  // Validate base score
  if (data.risk_calculation.base_score === undefined) {
    errors.push({
      path: 'risk_calculation.base_score',
      message: 'Missing base_score'
    });
  }
  
  // Validate factors
  if (data.risk_calculation.factors) {
    for (const factor of data.risk_calculation.factors) {
      if (factor.name === undefined) {
        errors.push({
          path: 'risk_calculation.factors.entry',
          message: 'Missing factor name'
        });
      }
      
      if (factor.weight === undefined) {
        errors.push({
          path: `risk_calculation.factors.${factor.name}.weight`,
          message: `Missing weight for factor ${factor.name}`
        });
      }
      
      if (!factor.scoring || !Array.isArray(factor.scoring)) {
        errors.push({
          path: `risk_calculation.factors.${factor.name}.scoring`,
          message: `Missing or invalid scoring for factor ${factor.name}`
        });
      }
    }
  }
  
  // Validate risk tiers
  if (!data.risk_tiers || !Array.isArray(data.risk_tiers)) {
    errors.push({ path: 'risk_tiers', message: 'Missing or invalid risk_tiers' });
  } else {
    // Check for overlapping ranges
    const ranges = [];
    for (const tier of data.risk_tiers) {
      ranges.push({ min: tier.min_score, max: tier.max_score, name: tier.tier });
    }
    
    for (let i = 0; i < ranges.length; i++) {
      for (let j = i + 1; j < ranges.length; j++) {
        if (ranges[i].max >= ranges[j].min) {
          errors.push({
            path: 'risk_tiers',
            message: `Overlapping ranges: ${ranges[i].name} and ${ranges[j].name}`
          });
        }
      }
    }
  }
}

/**
 * Validate governance schema structure
 */
function validateGovernanceSchema(data, errors) {
  if (!data.$schema) {
    errors.push({ path: '$schema', message: 'Missing $schema reference' });
  }
  
  if (!data.$id) {
    errors.push({ path: '$id', message: 'Missing $id' });
  }
  
  if (!data.definitions) {
    errors.push({ path: 'definitions', message: 'Missing definitions' });
  }
}

/**
 * Validate cross-file consistency
 */
async function validateCrossFileConsistency(options) {
  console.log('\nValidating cross-file consistency...');
  
  try {
    // Load all YAML files
    const files = getGovernanceFiles();
    const fileData = {};
    
    for (const file of files) {
      const ext = path.extname(file).toLowerCase();
      
      if (ext === '.yaml' || ext === '.yml') {
        const content = fs.readFileSync(file, 'utf8');
        const data = yaml.load(content);
        fileData[path.basename(file, '.yaml')] = data;
      }
    }
    
    // Check for consistency issues
    const consistencyIssues = [];
    
    // Check workflow approval paths reference valid roles
    if (fileData['approval-workflow']?.approval_paths) {
      const validRoles = ['richard_founder', 'richard_admin', 'richard_officer', 'auditor'];
      
      for (const [pathName, pathData] of Object.entries(fileData['approval-workflow'].approval_paths)) {
        if (pathData.required_approvers) {
          for (const approver of pathData.required_approvers) {
            if (approver.role && !validRoles.includes(approver.role)) {
              consistencyIssues.push({
                code: 'INVALID_ROLE',
                message: `Approval path '${pathName}' references unknown role: ${approver.role}`
              });
            }
          }
        }
      }
    }
    
    // Check milestone levels match risk tier expectations
    if (fileData['milestone-rules']?.milestones) {
      for (const [name, milestone] of Object.entries(fileData['milestone-rules'].milestones)) {
        if (milestone.level < 0 || milestone.level > 5) {
          consistencyIssues.push({
            code: 'INVALID_MILESTONE_LEVEL',
            message: `Milestone '${name}' has invalid level: ${milestone.level}`
          });
        }
      }
    }
    
    if (consistencyIssues.length > 0) {
      console.log(`\n⚠ Found ${consistencyIssues.length} cross-file consistency issues:`);
      
      for (const issue of consistencyIssues) {
        stats.warnings.push(issue);
        console.log(`  ⚠ ${issue.code}: ${issue.message}`);
      }
    } else {
      if (options.verbose) {
        console.log('  ✓ Cross-file consistency check passed');
      }
    }
    
  } catch (error) {
    console.error(`  ✗ Cross-file validation error: ${error.message}`);
  }
}

/**
 * Check best practices
 */
function checkBestPractices(data, filePath) {
  const warnings = [];
  
  if (!data.description && !data.$id) {
    warnings.push({
      code: 'MISSING_DESCRIPTION',
      message: 'File should have a description'
    });
  }
  
  if (!data.version && !data.schema_version) {
    warnings.push({
      code: 'MISSING_VERSION',
      message: 'File should have a version field'
    });
  }
  
  if (!data.last_updated) {
    warnings.push({
      code: 'MISSING_LAST_UPDATED',
      message: 'File should have a last_updated field'
    });
  }
  
  return { warnings };
}

/**
 * Attempt to fix validation errors
 */
async function fixValidationErrors(filePath, data, errors) {
  console.log(`\nAttempting to fix errors in ${path.basename(filePath)}...`);
  
  let fixed = false;
  
  for (const error of errors) {
    if (error.code === 'MISSING_LAST_UPDATED') {
      data.last_updated = new Date().toISOString().split('T')[0];
      fixed = true;
    }
    
    if (error.code === 'MISSING_VERSION' && !data.version) {
      data.version = '1.0.0';
      fixed = true;
    }
  }
  
  if (fixed) {
    try {
      const ext = path.extname(filePath);
      let content;
      
      if (ext === '.json') {
        content = JSON.stringify(data, null, 2);
      } else {
        content = yaml.dump(data);
      }
      
      fs.writeFileSync(filePath, content);
      console.log(`  ✓ Fixed and saved ${path.basename(filePath)}`);
    } catch (error) {
      console.error(`  ✗ Failed to save fixes: ${error.message}`);
    }
  }
}

/**
 * Print validation summary
 */
function printSummary(stats, startTime) {
  const duration = Date.now() - startTime;
  
  console.log('\n=== Validation Summary ===');
  console.log(`Files scanned: ${stats.filesScanned}`);
  console.log(`Valid files: ${stats.filesValid}`);
  console.log(`Invalid files: ${stats.filesInvalid}`);
  console.log(`Duration: ${duration}ms\n`);
  
  if (stats.errors.length > 0) {
    console.log(`Errors (${stats.errors.length}):`);
    
    const errorGroups = {};
    for (const error of stats.errors) {
      const key = error.code || 'UNKNOWN';
      if (!errorGroups[key]) {
        errorGroups[key] = [];
      }
      errorGroups[key].push(error);
    }
    
    for (const [code, group] of Object.entries(errorGroups)) {
      console.log(`  ${code}: ${group.length} occurrences`);
    }
    console.log('');
  }
  
  if (stats.warnings.length > 0) {
    console.log(`Warnings (${stats.warnings.length}):`);
    const warningGroups = {};
    for (const warning of stats.warnings) {
      const key = warning.code || 'UNKNOWN';
      if (!warningGroups[key]) {
        warningGroups[key] = [];
      }
      warningGroups[key].push(warning);
    }
    
    for (const [code, group] of Object.entries(warningGroups)) {
      console.log(`  ${code}: ${group.length} occurrences`);
    }
    console.log('');
  }
}

// CLI Interface
if (require.main === module) {
  const args = process.argv.slice(2);
  const options = {
    verbose: args.includes('--verbose') || args.includes('-v'),
    fix: args.includes('--fix') || args.includes('-f')
  };
  
  validateGovernance(options);
}

module.exports = {
  validateGovernance,
  CONFIG
};
