/**
 * Richard's Credit Authority - Main Application Entry Point
 * 
 * This is the primary entry point for the Credit Authority API server.
 * It initializes all middleware, routes, and services required for operation.
 */

require('dotenv').config();

const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const morgan = require('morgan');
const rateLimit = require('express-rate-limit');

const config = require('./config');
const logger = require('./utils/logger');
const errorHandler = require('./middleware/errorHandler');
const validationMiddleware = require('./middleware/validation');

// Import routes
const identityRoutes = require('./routes/identity');
const applicationRoutes = require('./routes/applications');
const creditRoutes = require('./routes/credits');
const taxRoutes = require('./routes/tax');
const webhookRoutes = require('./routes/webhooks');
const healthRoutes = require('./routes/health');

// Create Express application
const app = express();

// =============================================================================
// Security Middleware
// =============================================================================

// Helmet for security headers
app.use(helmet());

// CORS configuration
app.use(cors({
  origin: config.cors.origins,
  methods: config.cors.methods,
  allowedHeaders: config.cors.headers,
  credentials: config.cors.credentials
}));

// Rate limiting
const limiter = rateLimit({
  windowMs: config.rateLimit.windowMs,
  max: config.rateLimit.maxRequests,
  message: {
    error: 'Too many requests, please try again later.',
    retryAfter: Math.ceil(config.rateLimit.windowMs / 1000)
  },
  standardHeaders: true,
  legacyHeaders: false
});
app.use('/api/', limiter);

// =============================================================================
// Body Parsing
// =============================================================================

app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// =============================================================================
// Logging
// =============================================================================

// HTTP request logging
app.use(morgan('combined', {
  stream: {
    write: (message) => logger.info(message.trim())
  }
}));

// Request ID middleware
app.use((req, res, next) => {
  req.id = require('uuid').v4();
  res.setHeader('X-Request-ID', req.id);
  next();
});

// =============================================================================
// Health Check Routes
// =============================================================================

app.use('/health', healthRoutes);

// =============================================================================
// API Routes
// =============================================================================

app.use('/api/v1/identity', identityRoutes);
app.use('/api/v1/applications', applicationRoutes);
app.use('/api/v1/credits', creditRoutes);
app.use('/api/v1/tax', taxRoutes);
app.use('/api/v1/webhooks', webhookRoutes);

// =============================================================================
// Root Route
// =============================================================================

app.get('/', (req, res) => {
  res.json({
    name: "Richard's Credit Authority API",
    version: config.app.version,
    description: "Credit authority management system with approval workflows, governance, and compliance automation",
    documentation: "/api/v1/docs",
    health: "/health",
    status: "operational"
  });
});

// =============================================================================
// API Documentation Route
// =============================================================================

app.get('/api/v1/docs', (req, res) => {
  res.json({
    message: "API documentation available in docs/api-webhooks.md",
    endpoints: {
      identity: "/api/v1/identity",
      applications: "/api/v1/applications",
      credits: "/api/v1/credits",
      tax: "/api/v1/tax",
      webhooks: "/api/v1/webhooks",
      health: "/health"
    }
  });
});

// =============================================================================
// 404 Handler
// =============================================================================

app.use((req, res) => {
  res.status(404).json({
    error: {
      code: 'NOT_FOUND',
      message: `Route ${req.method} ${req.path} not found`,
      requestId: req.id
    }
  });
});

// =============================================================================
// Error Handling
// =============================================================================

app.use(errorHandler);

// =============================================================================
// Server Startup
// =============================================================================

const server = app.listen(config.app.port, () => {
  logger.info(`Credit Authority API started`, {
    port: config.app.port,
    environment: config.app.environment,
    version: config.app.version
  });
  logger.info(`Health check available at http://localhost:${config.app.port}/health`);
  logger.info(`API documentation at http://localhost:${config.app.port}/api/v1/docs`);
});

// =============================================================================
// Graceful Shutdown
// =============================================================================

const gracefulShutdown = (signal) => {
  logger.info(`${signal} received, starting graceful shutdown...`);
  
  server.close((err) => {
    if (err) {
      logger.error('Error during shutdown', { error: err.message });
      process.exit(1);
    }
    
    logger.info('HTTP server closed');
    
    // Close database connections if any
    // await closeDatabaseConnections();
    
    logger.info('Graceful shutdown complete');
    process.exit(0);
  });
  
  // Force shutdown after timeout
  setTimeout(() => {
    logger.error('Forced shutdown due to timeout');
    process.exit(1);
  }, 30000);
};

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

// =============================================================================
// Unhandled Exception Handler
// =============================================================================

process.on('unhandledException', (error) => {
  logger.error('Unhandled exception', { error: error.message, stack: error.stack });
  process.exit(1);
});

process.on('unhandledRejection', (reason, promise) => {
  logger.error('Unhandled rejection', { reason: String(reason) });
});

// =============================================================================
// Export for testing
// =============================================================================

module.exports = { app, server };
