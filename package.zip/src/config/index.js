/**
 * Application Configuration
 * 
 * Centralized configuration management for the Credit Authority application.
 * Loads configuration from environment variables with appropriate defaults.
 */

const path = require('path');

// Load .env file if present
require('dotenv').config({ path: path.join(__dirname, '..', '.env') });

const config = {
  app: {
    name: "Richard's Credit Authority",
    version: '1.0.0',
    environment: process.env.NODE_ENV || 'development',
    port: parseInt(process.env.PORT, 10) || 3000,
    apiPrefix: '/api/v1'
  },

  cors: {
    origins: process.env.CORS_ORIGINS?.split(',') || ['http://localhost:3000'],
    methods: ['GET', 'POST', 'PUT', 'PATCH', 'DELETE', 'OPTIONS'],
    headers: ['Content-Type', 'Authorization', 'X-Request-ID'],
    credentials: true
  },

  rateLimit: {
    windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS, 10) || 900000,
    maxRequests: parseInt(process.env.RATE_LIMIT_MAX_REQUESTS, 10) || 100
  },

  jwt: {
    secret: process.env.JWT_SECRET || 'default-dev-secret-change-in-production',
    expiry: process.env.JWT_EXPIRY || '24h'
  },

  apiKey: {
    header: 'X-API-Key',
    value: process.env.API_KEY || 'dev-api-key'
  },

  logging: {
    level: process.env.LOG_LEVEL || 'info',
    file: process.env.LOG_FILE_PATH || './logs/app.log',
    maxSize: parseInt(process.env.LOG_MAX_SIZE, 10) || 10485760,
    maxFiles: parseInt(process.env.LOG_MAX_FILES, 10) || 5,
    auditFile: process.env.AUDIT_LOG_PATH || './logs/audit.log'
  },

  repositories: {
    ledger: {
      baseUrl: process.env.LEDGER_API_URL || 'http://localhost:3001',
      apiKey: process.env.LEDGER_API_KEY
    },
    agreements: {
      baseUrl: process.env.AGREEMENTS_API_URL || 'http://localhost:3002',
      apiKey: process.env.AGREEMENTS_API_KEY
    },
    creditTools: {
      baseUrl: process.env.CREDIT_TOOLS_API_URL || 'http://localhost:3003',
      apiKey: process.env.CREDIT_TOOLS_API_KEY
    },
    disbursement: {
      baseUrl: process.env.DISBURSEMENT_API_URL || 'http://localhost:3004',
      apiKey: process.env.DISBURSEMENT_API_KEY
    }
  },

  tax: {
    federal: {
      baseUrl: process.env.FEDERAL_TAX_API_URL || 'https://api.irs.gov',
      apiKey: process.env.FEDERAL_TAX_API_KEY
    },
    state: {
      baseUrl: process.env.STATE_TAX_API_URL || 'https://api.state-tax.gov',
      apiKey: process.env.STATE_TAX_API_KEY
    }
  },

  identity: {
    providerUrl: process.env.IDENTITY_PROVIDER_URL || 'http://localhost:3200',
    apiKey: process.env.IDENTITY_PROVIDER_API_KEY
  },

  redis: {
    host: process.env.REDIS_HOST || 'localhost',
    port: parseInt(process.env.REDIS_PORT, 10) || 6379,
    password: process.env.REDIS_PASSWORD,
    db: parseInt(process.env.REDIS_DB, 10) || 0
  },

  webhook: {
    secret: process.env.WEBHOOK_SECRET || 'webhook-dev-secret',
    retryAttempts: parseInt(process.env.WEBHOOK_RETRY_ATTEMPTS, 10) || 3,
    retryDelay: parseInt(process.env.WEBHOOK_RETRY_DELAY, 10) || 1000
  },

  encryption: {
    key: process.env.ENCRYPTION_KEY || 'default-encryption-key-32chars!',
    iv: process.env.ENCRYPTION_IV || 'default-iv-16!'
  },

  features: {
    taxValidation: process.env.ENABLE_TAX_VALIDATION !== 'false',
    identityVerification: process.env.ENABLE_IDENTITY_VERIFICATION !== 'false',
    autoEscalation: process.env.ENABLE_AUTO_ESCALATION !== 'false',
    auditLogging: process.env.ENABLE_AUDIT_LOGGING !== 'false'
  }
};

// Validate required configuration
const validateConfig = () => {
  const errors = [];

  if (config.app.environment === 'production') {
    if (config.jwt.secret.includes('default')) {
      errors.push('JWT_SECRET must be set in production');
    }
    if (config.apiKey.value === 'dev-api-key') {
      errors.push('API_KEY must be set in production');
    }
    if (config.encryption.key.includes('default')) {
      errors.push('ENCRYPTION_KEY must be set in production');
    }
  }

  if (errors.length > 0) {
    throw new Error(`Configuration validation failed:\n${errors.join('\n')}`);
  }
};

// Run validation in production
if (config.app.environment === 'production') {
  validateConfig();
}

module.exports = config;
