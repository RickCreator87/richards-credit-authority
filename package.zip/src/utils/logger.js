/**
 * Winston Logger Configuration
 * 
 * Centralized logging for the Credit Authority application.
 * Provides structured logging with file rotation and audit trail support.
 */

const winston = require('winston');
const path = require('path');
const fs = require('fs');

// Ensure logs directory exists
const logsDir = path.join(__dirname, '..', '..', 'logs');
if (!fs.existsSync(logsDir)) {
  fs.mkdirSync(logsDir, { recursive: true });
}

// Custom format for structured logging
const structuredFormat = winston.format.combine(
  winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss.SSS' }),
  winston.format.errors({ stack: true }),
  winston.format.json()
);

// Human-readable format for console output
const consoleFormat = winston.format.combine(
  winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss' }),
  winston.format.colorize(),
  winston.format.printf(({ timestamp, level, message, ...meta }) => {
    const metaStr = Object.keys(meta).length ? JSON.stringify(meta, null, 2) : '';
    return `${timestamp} [${level}]: ${message} ${metaStr}`;
  })
);

// Audit log format - more detailed for compliance
const auditFormat = winston.format.combine(
  winston.format.timestamp({ format: 'YYYY-MM-DD HH:mm:ss.SSS' }),
  winston.format.json()
);

// Create the main logger
const logger = winston.createLogger({
  level: process.env.LOG_LEVEL || 'info',
  format: structuredFormat,
  defaultMeta: { service: 'credit-authority' },
  transports: [
    // Error log file
    new winston.transports.File({
      filename: path.join(logsDir, 'error.log'),
      level: 'error',
      maxsize: 10 * 1024 * 1024, // 10MB
      maxFiles: 5,
      tailable: true
    }),
    // Combined log file
    new winston.transports.File({
      filename: path.join(logsDir, 'combined.log'),
      maxsize: 10 * 1024 * 1024,
      maxFiles: 5,
      tailable: true
    })
  ],
  exceptionHandlers: [
    new winston.transports.File({
      filename: path.join(logsDir, 'exceptions.log')
    })
  ],
  rejectionHandlers: [
    new winston.transports.File({
      filename: path.join(logsDir, 'rejections.log')
    })
  ]
});

// Add console transport in development
if (process.env.NODE_ENV !== 'production') {
  logger.add(new winston.transports.Console({
    format: consoleFormat
  }));
}

// Create audit logger for compliance
const auditLogger = winston.createLogger({
  level: 'info',
  format: auditFormat,
  defaultMeta: { service: 'credit-authority', type: 'audit' },
  transports: [
    new winston.transports.File({
      filename: path.join(logsDir, 'audit.log'),
      maxsize: 50 * 1024 * 1024, // 50MB for audit logs
      maxFiles: 10,
      tailable: true
    })
  ]
});

// Helper methods for common logging patterns
logger.logRequest = (level, message, requestMeta = {}) => {
  logger.log(level, message, {
    ...requestMeta,
    timestamp: new Date().toISOString()
  });
};

logger.logDecision = (decisionType, decision, meta = {}) => {
  logger.info(`Decision: ${decisionType}`, {
    decision,
    ...meta,
    decisionType,
    timestamp: new Date().toISOString()
  });
};

logger.logApproval = (applicationId, approverId, authorityLevel, decision, meta = {}) => {
  logger.info(`Approval decision`, {
    applicationId,
    approverId,
    authorityLevel,
    decision,
    ...meta,
    timestamp: new Date().toISOString()
  });
};

logger.logEscalation = (applicationId, fromLevel, toLevel, reason, meta = {}) => {
  logger.info(`Escalation`, {
    applicationId,
    fromAuthorityLevel: fromLevel,
    toAuthorityLevel: toLevel,
    reason,
    ...meta,
    timestamp: new Date().toISOString()
  });
};

logger.logSecurityEvent = (eventType, description, meta = {}) => {
  logger.warn(`Security event: ${eventType}`, {
    eventType,
    description,
    ...meta,
    timestamp: new Date().toISOString()
  });
};

logger.logApiCall = (method, path, statusCode, duration, meta = {}) => {
  const level = statusCode >= 400 ? 'warn' : 'debug';
  logger.log(level, `API ${method} ${path}`, {
    method,
    path,
    statusCode,
    duration,
    ...meta,
    timestamp: new Date().toISOString()
  });
};

// Audit logging methods
auditLogger.logIdentityEvent = (eventType, identityId, meta = {}) => {
  auditLogger.info(`Identity event: ${eventType}`, {
    eventType,
    identityId,
    ...meta,
    timestamp: new Date().toISOString()
  });
};

auditLogger.logTransactionEvent = (eventType, transactionId, meta = {}) => {
  auditLogger.info(`Transaction event: ${eventType}`, {
    eventType,
    transactionId,
    ...meta,
    timestamp: new Date().toISOString()
  });
};

auditLogger.logConfigurationChange = (configType, fieldName, oldValue, newValue, changedBy) => {
  auditLogger.info(`Configuration change`, {
    configType,
    fieldName,
    oldValue,
    newValue,
    changedBy,
    timestamp: new Date().toISOString()
  });
};

auditLogger.logAccessEvent = (eventType, userId, resource, meta = {}) => {
  auditLogger.info(`Access event: ${eventType}`, {
    eventType,
    userId,
    resource,
    ...meta,
    timestamp: new Date().toISOString()
  });
};

module.exports = { logger, auditLogger };
