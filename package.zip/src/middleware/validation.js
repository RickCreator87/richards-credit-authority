/**
 * Validation Middleware
 * 
 * Request validation middleware for the Credit Authority API.
 * Provides reusable validation schemas and validation logic.
 */

const Ajv = require('ajv');
const addFormats = require('ajv-formats');
const fs = require('fs');
const path = require('path');

// Initialize AJV with formats
const ajv = new Ajv({ allErrors: true, strict: false });
addFormats(ajv);

// =============================================================================
// Common Validation Schemas
// =============================================================================

const uuidSchema = {
  type: 'string',
  pattern: '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$'
};

const paginationSchema = {
  type: 'object',
  properties: {
    page: { type: 'integer', minimum: 1, default: 1 },
    limit: { type: 'integer', minimum: 1, maximum: 100, default: 20 },
    sortBy: { type: 'string' },
    sortOrder: { type: 'string', enum: ['asc', 'desc'] }
  }
};

const dateRangeSchema = {
  type: 'object',
  properties: {
    startDate: { type: 'string', format: 'date' },
    endDate: { type: 'string', format: 'date' }
  }
};

// =============================================================================
// Identity Validation Schemas
// =============================================================================

const identityVerificationSchema = {
  type: 'object',
  required: ['identityId', 'method'],
  properties: {
    identityId: { type: 'string', minLength: 1 },
    method: { type: 'string', enum: ['document', 'biometric', 'external', 'knowledge'] },
    options: {
      type: 'object',
      properties: {
        enhancedVerification: { type: 'boolean' },
        provider: { type: 'string' }
      }
    }
  }
};

const createIdentitySchema = {
  type: 'object',
  required: ['type', 'profile'],
  properties: {
    type: { type: 'string', enum: ['individual', 'corporate', 'institutional', 'system'] },
    profile: {
      type: 'object',
      required: ['legalName'],
      properties: {
        legalName: { type: 'string', minLength: 1 },
        dateOfBirth: { type: 'string', format: 'date' },
        governmentId: { type: 'string' },
        taxId: { type: 'string' }
      }
    },
    contact: {
      type: 'object',
      properties: {
        email: { type: 'string', format: 'email' },
        phone: { type: 'string' },
        address: { type: 'string' }
      }
    }
  }
};

// =============================================================================
// Application Validation Schemas
// =============================================================================

const createApplicationSchema = {
  type: 'object',
  required: ['borrowerId', 'loanType', 'amount', 'term'],
  properties: {
    borrowerId: { type: 'string', minLength: 1 },
    loanType: { type: 'string' },
    amount: { type: 'number', minimum: 1 },
    term: { type: 'integer', minimum: 1, maximum: 360 },
    purpose: { type: 'string' },
    collateral: {
      type: 'object',
      properties: {
        type: { type: 'string' },
        value: { type: 'number', minimum: 0 }
      }
    },
    coBorrowerIds: {
      type: 'array',
      items: { type: 'string' }
    }
  }
};

const updateApplicationSchema = {
  type: 'object',
  properties: {
    action: { type: 'string', enum: ['add_document', 'update_info', 'withdraw'] },
    data: {
      type: 'object',
      properties: {
        documentType: { type: 'string' },
        documentUrl: { type: 'string', format: 'uri' },
        information: { type: 'object' }
      }
    }
  }
};

// =============================================================================
// Credit Validation Schemas
// =============================================================================

const disbursementSchema = {
  type: 'object',
  required: ['amount', 'method'],
  properties: {
    amount: { type: 'number', minimum: 1 },
    method: { type: 'string', enum: ['ach', 'wire', 'check'] },
    destination: {
      type: 'object',
      required: ['accountNumber', 'routingNumber'],
      properties: {
        accountNumber: { type: 'string' },
        routingNumber: { type: 'string' },
        accountType: { type: 'string', enum: ['checking', 'savings'] }
      }
    }
  }
};

const amendmentSchema = {
  type: 'object',
  required: ['amendmentType'],
  properties: {
    amendmentType: { type: 'string', enum: ['rate', 'term', 'principal', 'collateral'] },
    proposedTerms: {
      type: 'object',
      properties: {
        newRate: { type: 'number', minimum: 0, maximum: 1 },
        newTerm: { type: 'integer', minimum: 1, maximum: 360 },
        additionalPrincipal: { type: 'number', minimum: 0 }
      }
    },
    justification: { type: 'string', minLength: 10 }
  }
};

// =============================================================================
// Tax Validation Schemas
// =============================================================================

const taxValidationSchema = {
  type: 'object',
  required: ['transactionType', 'amount', 'partyId'],
  properties: {
    transactionType: { type: 'string' },
    amount: { type: 'number', minimum: 0 },
    partyId: { type: 'string', minLength: 1 },
    jurisdiction: { type: 'string' }
  }
};

// =============================================================================
// Webhook Validation Schemas
// =============================================================================

const webhookSchema = {
  type: 'object',
  required: ['url', 'events'],
  properties: {
    url: { type: 'string', format: 'uri' },
    events: {
      type: 'array',
      items: {
        type: 'string',
        enum: [
          'application.submitted',
          'application.approved',
          'application.denied',
          'disbursement.completed',
          'credit.amended'
        ]
      },
      minItems: 1
    },
    secret: { type: 'string', minLength: 16 },
    active: { type: 'boolean', default: true }
  }
};

// =============================================================================
// Validator Compilation
// =============================================================================

const validators = {
  pagination: ajv.compile(paginationSchema),
  dateRange: ajv.compile(dateRangeSchema),
  uuid: ajv.compile(uuidSchema),
  identityVerification: ajv.compile(identityVerificationSchema),
  createIdentity: ajv.compile(createIdentitySchema),
  createApplication: ajv.compile(createApplicationSchema),
  updateApplication: ajv.compile(updateApplicationSchema),
  disbursement: ajv.compile(disbursementSchema),
  amendment: ajv.compile(amendmentSchema),
  taxValidation: ajv.compile(taxValidationSchema),
  webhook: ajv.compile(webhookSchema)
};

// =============================================================================
// Middleware Factory Functions
// =============================================================================

const validateRequest = (schemaName) => {
  const validator = validators[schemaName];
  
  if (!validator) {
    throw new Error(`Unknown schema: ${schemaName}`);
  }
  
  return (req, res, next) => {
    const data = req.method === 'GET' ? req.query : req.body;
    
    const valid = validator(data);
    
    if (!valid) {
      return res.status(400).json({
        error: {
          code: 'VALIDATION_ERROR',
          message: 'Request validation failed',
          details: validator.errors.map(err => ({
            field: err.instancePath || err.params?.missingProperty || 'unknown',
            message: err.message,
            params: err.params
          }))
        }
      });
    }
    
    next();
  };
};

const validateQuery = (schemaName) => {
  const validator = validators[schemaName];
  
  return (req, res, next) => {
    const valid = validator(req.query);
    
    if (!valid) {
      return res.status(400).json({
        error: {
          code: 'VALIDATION_ERROR',
          message: 'Query validation failed',
          details: validator.errors
        }
      });
    }
    
    next();
  };
};

const validateParams = (schema) => {
  return (req, res, next) => {
    const errors = [];
    
    for (const [param, rules] of Object.entries(schema)) {
      const value = req.params[param];
      
      if (rules.required && !value) {
        errors.push({ param, message: `${param} is required` });
        continue;
      }
      
      if (value && rules.pattern && !new RegExp(rules.pattern).test(value)) {
        errors.push({ param, message: rules.message || `Invalid ${param}` });
      }
      
      if (value && rules.type === 'number' && isNaN(parseInt(value, 10))) {
        errors.push({ param, message: `${param} must be a number` });
      }
    }
    
    if (errors.length > 0) {
      return res.status(400).json({
        error: {
          code: 'VALIDATION_ERROR',
          message: 'Parameter validation failed',
          details: errors
        }
      });
    }
    
    next();
  };
};

// =============================================================================
// YAML Configuration Validation
// =============================================================================

const loadAndValidateYaml = (filePath, schemaPath) => {
  const yaml = require('js-yaml');
  const schema = JSON.parse(fs.readFileSync(schemaPath, 'utf8'));
  
  const data = yaml.load(fs.readFileSync(filePath, 'utf8'));
  const validate = ajv.compile(schema);
  const valid = validate(data);
  
  if (!valid) {
    throw new Error(`YAML validation failed: ${JSON.stringify(validate.errors, null, 2)}`);
  }
  
  return data;
};

// =============================================================================
// Export
// =============================================================================

module.exports = {
  validateRequest,
  validateQuery,
  validateParams,
  loadAndValidateYaml,
  validators,
  ajv
};
