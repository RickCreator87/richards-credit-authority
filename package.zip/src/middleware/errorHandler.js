/**
 * Error Handler Middleware
 * 
 * Centralized error handling for the Credit Authority API.
 * Ensures consistent error responses and proper logging.
 */

const { logger, auditLogger } = require('../utils/logger');
const config = require('../config');

// Custom error classes
class AppError extends Error {
  constructor(message, statusCode, code, details = null) {
    super(message);
    this.statusCode = statusCode;
    this.code = code;
    this.details = details;
    this.isOperational = true;

    Error.captureStackTrace(this, this.constructor);
  }
}

class ValidationError extends AppError {
  constructor(message, details = null) {
    super(message, 400, 'VALIDATION_ERROR', details);
  }
}

class AuthenticationError extends AppError {
  constructor(message = 'Authentication required') {
    super(message, 401, 'UNAUTHORIZED');
  }
}

class AuthorizationError extends AppError {
  constructor(message = 'Access denied') {
    super(message, 403, 'FORBIDDEN', message);
  }
}

class NotFoundError extends AppError {
  constructor(resource = 'Resource') {
    super(`${resource} not found`, 404, 'NOT_FOUND');
  }
}

class ConflictError extends AppError {
  constructor(message) {
    super(message, 409, 'CONFLICT');
  }
}

class RateLimitError extends AppError {
  constructor(retryAfter) {
    super('Rate limit exceeded', 429, 'RATE_LIMIT', { retryAfter });
  }
}

class ExternalServiceError extends AppError {
  constructor(service, message) {
    super(`External service error: ${service}`, 502, 'SERVICE_UNAVAILABLE', { service, message });
  }
}

// Error response formatter
const formatErrorResponse = (error, requestId) => {
  const response = {
    error: {
      code: error.code || 'INTERNAL_ERROR',
      message: error.isOperational ? error.message : 'An unexpected error occurred',
      requestId
    }
  };

  if (error.details) {
    response.error.details = error.details;
  }

  // Include stack trace in development
  if (process.env.NODE_ENV === 'development' && error.stack) {
    response.error.stack = error.stack;
  }

  return response;
};

// Main error handler middleware
const errorHandler = (err, req, res, next) => {
  const requestId = req.id || 'unknown';
  
  // Default error values
  let statusCode = err.statusCode || 500;
  let errorCode = err.code || 'INTERNAL_ERROR';
  let message = err.message || 'Internal server error';
  let details = err.details || null;

  // Handle specific error types
  if (err.name === 'JsonWebTokenError') {
    statusCode = 401;
    errorCode = 'INVALID_TOKEN';
    message = 'Invalid authentication token';
  } else if (err.name === 'TokenExpiredError') {
    statusCode = 401;
    errorCode = 'TOKEN_EXPIRED';
    message = 'Authentication token has expired';
  } else if (err.name === 'ValidationError') {
    // Mongoose validation error
    statusCode = 400;
    errorCode = 'VALIDATION_ERROR';
    message = 'Validation failed';
    details = formatMongooseValidationError(err);
  } else if (err.name === 'CastError') {
    statusCode = 400;
    errorCode = 'INVALID_ID';
    message = 'Invalid ID format';
  } else if (err.code === 'LIMIT_FILE_SIZE') {
    statusCode = 413;
    errorCode = 'FILE_TOO_LARGE';
    message = 'File size exceeds limit';
  } else if (err.code === 'ENOENT') {
    statusCode = 404;
    errorCode = 'NOT_FOUND';
    message = 'Requested resource not found';
  }

  // Log the error
  const logData = {
    requestId,
    method: req.method,
    path: req.path,
    statusCode,
    errorCode,
    message: err.message,
    stack: process.env.NODE_ENV === 'development' ? err.stack : undefined,
    userId: req.user?.id,
    ip: req.ip
  };

  if (statusCode >= 500) {
    logger.error('Server error', logData);
    auditLogger.logAccessEvent('SERVER_ERROR', req.user?.id, req.path, {
      ...logData,
      errorMessage: err.message
    });
  } else if (statusCode >= 400) {
    logger.warn('Client error', logData);
  }

  // Send error response
  res.status(statusCode).json(formatErrorResponse({
    statusCode,
    code: errorCode,
    message,
    details,
    isOperational: err.isOperational,
    stack: process.env.NODE_ENV === 'development' ? err.stack : undefined
  }, requestId));
};

// Helper to format Mongoose validation errors
const formatMongooseValidationError = (err) => {
  if (!err.errors) return null;
  
  return Object.keys(err.errors).map(field => ({
    field,
    message: err.errors[field].message,
    kind: err.errors[field].kind
  }));
};

// Async handler wrapper to catch async errors
const asyncHandler = (fn) => (req, res, next) => {
  Promise.resolve(fn(req, res, next)).catch(next);
};

// Not found handler for undefined routes
const notFoundHandler = (req, res, next) => {
  const error = new NotFoundError('Route');
  errorHandler(error, req, res, next);
};

// Error response helper
const sendErrorResponse = (res, statusCode, code, message, details = null) => {
  res.status(statusCode).json({
    error: { code, message, details }
  });
};

module.exports = {
  AppError,
  ValidationError,
  AuthenticationError,
  AuthorizationError,
  NotFoundError,
  ConflictError,
  RateLimitError,
  ExternalServiceError,
  errorHandler,
  asyncHandler,
  notFoundHandler,
  sendErrorResponse
};
