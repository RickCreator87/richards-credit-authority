/**
 * Application Routes
 * 
 * API endpoints for credit application management.
 */

const express = require('express');
const { v4: uuidv4 } = require('uuid');
const { logger, auditLogger } = require('../utils/logger');
const { asyncHandler } = require('../middleware/errorHandler');
const { validateRequest } = require('../middleware/validation');

const router = express.Router();

/**
 * @route POST /api/v1/applications
 * @description Creates a new loan application
 */
router.post('/', asyncHandler(async (req, res) => {
  const { borrowerId, loanType, amount, term, purpose, collateral, coBorrowerIds } = req.body;
  
  const applicationId = uuidv4();
  
  logger.info('New application created', {
    applicationId,
    borrowerId,
    loanType,
    amount,
    term,
    requestId: req.id
  });
  
  const application = {
    applicationId,
    borrowerId,
    loanType,
    amount,
    term,
    purpose,
    collateral,
    coBorrowerIds: coBorrowerIds || [],
    status: 'submitted',
    submissionDate: new Date().toISOString(),
    estimatedDecisionDate: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString()
  };
  
  auditLogger.logTransactionEvent('APPLICATION_CREATED', applicationId, {
    borrowerId,
    loanType,
    amount
  });
  
  res.status(201).json(application);
}));

/**
 * @route GET /api/v1/applications/:applicationId
 * @description Retrieves application details including status and results
 */
router.get('/:applicationId', asyncHandler(async (req, res) => {
  const { applicationId } = req.params;
  
  // Mock application retrieval
  const application = {
    applicationId,
    borrowerId: 'borrower-001',
    amount: 50000,
    term: 60,
    status: 'under_review',
    creditAssessment: {
      score: 720,
      riskCategory: 'low'
    },
    decision: null,
    createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000).toISOString(),
    updatedAt: new Date().toISOString()
  };
  
  res.json(application);
}));

/**
 * @route PATCH /api/v1/applications/:applicationId
 * @description Updates application information or adds documentation
 */
router.patch('/:applicationId', asyncHandler(async (req, res) => {
  const { applicationId } = req.params;
  const { action, data } = req.body;
  
  logger.info('Application update requested', {
    applicationId,
    action,
    requestId: req.id
  });
  
  const updated = {
    applicationId,
    action,
    data,
    updatedAt: new Date().toISOString()
  };
  
  auditLogger.logTransactionEvent('APPLICATION_UPDATED', applicationId, {
    action,
    dataKeys: Object.keys(data || {})
  });
  
  res.json(updated);
}));

/**
 * @route GET /api/v1/applications
 * @description Lists applications with pagination
 */
router.get('/', asyncHandler(async (req, res) => {
  const { page = 1, limit = 20, status, borrowerId } = req.query;
  
  // Mock application list
  const applications = [
    {
      applicationId: uuidv4(),
      borrowerId: borrowerId || 'borrower-001',
      amount: 50000,
      status: status || 'submitted',
      submissionDate: new Date().toISOString()
    }
  ];
  
  const response = {
    applications,
    pagination: {
      page: parseInt(page, 10),
      limit: parseInt(limit, 10),
      total: 1,
      totalPages: 1
    },
    filters: {
      status,
      borrowerId
    }
  };
  
  res.json(response);
}));

/**
 * @route POST /api/v1/applications/:applicationId/submit
 * @description Submits application for review
 */
router.post('/:applicationId/submit', asyncHandler(async (req, res) => {
  const { applicationId } = req.params;
  
  logger.info('Application submitted for review', {
    applicationId,
    requestId: req.id
  });
  
  const result = {
    applicationId,
    status: 'submitted',
    submittedAt: new Date().toISOString(),
    estimatedDecisionDate: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString()
  };
  
  auditLogger.logTransactionEvent('APPLICATION_SUBMITTED', applicationId, {});
  
  res.json(result);
}));

/**
 * @route POST /api/v1/applications/:applicationId/withdraw
 * @description Withdraws an application
 */
router.post('/:applicationId/withdraw', asyncHandler(async (req, res) => {
  const { applicationId } = req.params;
  const { reason } = req.body;
  
  logger.info('Application withdrawn', {
    applicationId,
    reason,
    requestId: req.id
  });
  
  const result = {
    applicationId,
    status: 'withdrawn',
    withdrawnAt: new Date().toISOString(),
    reason
  };
  
  auditLogger.logTransactionEvent('APPLICATION_WITHDRAWN', applicationId, {
    reason
  });
  
  res.json(result);
}));

module.exports = router;
