/**
 * Credit Routes
 * 
 * API endpoints for credit operations including disbursements and amendments.
 */

const express = require('express');
const { v4: uuidv4 } = require('uuid');
const { logger, auditLogger } = require('../utils/logger');
const { asyncHandler } = require('../middleware/errorHandler');

const router = express.Router();

/**
 * @route POST /api/v1/credits/:creditId/disburse
 * @description Initiates disbursement for an approved credit
 */
router.post('/:creditId/disburse', asyncHandler(async (req, res) => {
  const { creditId } = req.params;
  const { amount, method, destination } = req.body;
  
  const disbursementId = uuidv4();
  
  logger.info('Disbursement initiated', {
    creditId,
    disbursementId,
    amount,
    method,
    requestId: req.id
  });
  
  const disbursement = {
    disbursementId,
    creditId,
    amount,
    method,
    destination,
    status: 'pending',
    initiatedAt: new Date().toISOString(),
    estimatedDelivery: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000).toISOString()
  };
  
  auditLogger.logTransactionEvent('DISBURSEMENT_INITIATED', disbursementId, {
    creditId,
    amount,
    method
  });
  
  res.status(202).json(disbursement);
}));

/**
 * @route GET /api/v1/credits/:creditId
 * @description Retrieves credit details
 */
router.get('/:creditId', asyncHandler(async (req, res) => {
  const { creditId } = req.params;
  
  const credit = {
    creditId,
    borrowerId: 'borrower-001',
    amount: 50000,
    outstandingBalance: 45000,
    interestRate: 0.065,
    term: 60,
    status: 'active',
    startDate: '2024-01-15',
    nextPaymentDate: '2024-03-15',
    createdAt: new Date(Date.now() - 45 * 24 * 60 * 60 * 1000).toISOString()
  };
  
  res.json(credit);
}));

/**
 * @route POST /api/v1/credits/:creditId/amend
 * @description Requests amendment to credit terms
 */
router.post('/:creditId/amend', asyncHandler(async (req, res) => {
  const { creditId } = req.params;
  const { amendmentType, proposedTerms, justification } = req.body;
  
  const amendmentId = uuidv4();
  
  logger.info('Amendment requested', {
    creditId,
    amendmentId,
    amendmentType,
    requestId: req.id
  });
  
  const amendment = {
    amendmentId,
    creditId,
    amendmentType,
    proposedTerms,
    justification,
    status: 'pending_review',
    requestedAt: new Date().toISOString()
  };
  
  auditLogger.logTransactionEvent('AMENDMENT_REQUESTED', amendmentId, {
    creditId,
    amendmentType,
    proposedTerms
  });
  
  res.status(202).json(amendment);
}));

/**
 * @route GET /api/v1/credits/:creditId/transactions
 * @description Retrieves transaction history for a credit
 */
router.get('/:creditId/transactions', asyncHandler(async (req, res) => {
  const { creditId } = req.params;
  const { page = 1, limit = 20, type } = req.query;
  
  const transactions = [
    {
      transactionId: uuidv4(),
      type: 'payment',
      amount: 943.87,
      date: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
      status: 'completed'
    },
    {
      transactionId: uuidv4(),
      type: 'disbursement',
      amount: 50000,
      date: new Date(Date.now() - 45 * 24 * 60 * 60 * 1000).toISOString(),
      status: 'completed'
    }
  ];
  
  const response = {
    creditId,
    transactions,
    pagination: {
      page: parseInt(page, 10),
      limit: parseInt(limit, 10),
      total: transactions.length,
      totalPages: 1
    }
  };
  
  res.json(response);
}));

/**
 * @route POST /api/v1/credits/:creditId/payment
 * @description Records a payment for a credit
 */
router.post('/:creditId/payment', asyncHandler(async (req, res) => {
  const { creditId } = req.params;
  const { amount, paymentMethod, paymentDate } = req.body;
  
  const paymentId = uuidv4();
  
  logger.info('Payment recorded', {
    creditId,
    paymentId,
    amount,
    requestId: req.id
  });
  
  const payment = {
    paymentId,
    creditId,
    amount,
    paymentMethod,
    paymentDate: paymentDate || new Date().toISOString(),
    status: 'completed',
    recordedAt: new Date().toISOString()
  };
  
  auditLogger.logTransactionEvent('PAYMENT_RECORDED', paymentId, {
    creditId,
    amount,
    paymentMethod
  });
  
  res.status(201).json(payment);
}));

/**
 * @route GET /api/v1/credits
 * @description Lists credits with pagination
 */
router.get('/', asyncHandler(async (req, res) => {
  const { page = 1, limit = 20, status, borrowerId } = req.query;
  
  const credits = [
    {
      creditId: uuidv4(),
      borrowerId: borrowerId || 'borrower-001',
      amount: 50000,
      outstandingBalance: 45000,
      status: status || 'active',
      startDate: '2024-01-15'
    }
  ];
  
  const response = {
    credits,
    pagination: {
      page: parseInt(page, 10),
      limit: parseInt(limit, 10),
      total: 1,
      totalPages: 1
    }
  };
  
  res.json(response);
}));

module.exports = router;
