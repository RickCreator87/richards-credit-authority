/**
 * Webhook Routes
 * 
 * API endpoints for webhook configuration and event handling.
 */

const express = require('express');
const crypto = require('crypto');
const { v4: uuidv4 } = require('uuid');
const { logger, auditLogger } = require('../utils/logger');
const { asyncHandler, ValidationError } = require('../middleware/errorHandler');
const config = require('../config');

const router = express.Router();

// In-memory webhook store (use database in production)
const webhookStore = new Map();

/**
 * @route POST /api/v1/webhooks
 * @description Registers a new webhook endpoint
 */
router.post('/', asyncHandler(async (req, res) => {
  const { url, events, secret, active } = req.body;
  
  // Validate URL
  try {
    new URL(url);
  } catch {
    throw new ValidationError('Invalid webhook URL');
  }
  
  // Validate events
  const validEvents = [
    'application.submitted',
    'application.approved',
    'application.denied',
    'disbursement.completed',
    'credit.amended'
  ];
  
  const invalidEvents = events.filter(e => !validEvents.includes(e));
  if (invalidEvents.length > 0) {
    throw new ValidationError(`Invalid events: ${invalidEvents.join(', ')}`);
  }
  
  const webhookId = uuidv4();
  const webhookSecret = secret || crypto.randomBytes(32).toString('hex');
  
  const webhook = {
    webhookId,
    url,
    events,
    secret: webhookSecret,
    active: active !== false,
    createdAt: new Date().toISOString()
  };
  
  webhookStore.set(webhookId, webhook);
  
  logger.info('Webhook registered', {
    webhookId,
    url,
    events,
    requestId: req.id
  });
  
  res.status(201).json({
    webhookId,
    status: webhook.active ? 'active' : 'inactive',
    createdAt: webhook.createdAt
  });
}));

/**
 * @route GET /api/v1/webhooks
 * @description Lists all registered webhook endpoints
 */
router.get('/', asyncHandler(async (req, res) => {
  const webhooks = Array.from(webhookStore.values()).map(w => ({
    webhookId: w.webhookId,
    url: w.url,
    events: w.events,
    status: w.active ? 'active' : 'inactive',
    createdAt: w.createdAt
  }));
  
  res.json({ webhooks });
}));

/**
 * @route GET /api/v1/webhooks/:webhookId
 * @description Retrieves webhook configuration
 */
router.get('/:webhookId', asyncHandler(async (req, res) => {
  const { webhookId } = req.params;
  
  const webhook = webhookStore.get(webhookId);
  if (!webhook) {
    throw new ValidationError('Webhook not found');
  }
  
  res.json({
    webhookId: webhook.webhookId,
    url: webhook.url,
    events: webhook.events,
    status: webhook.active ? 'active' : 'inactive',
    createdAt: webhook.createdAt
  });
}));

/**
 * @route DELETE /api/v1/webhooks/:webhookId
 * @description Removes a webhook configuration
 */
router.delete('/:webhookId', asyncHandler(async (req, res) => {
  const { webhookId } = req.params;
  
  const webhook = webhookStore.get(webhookId);
  if (!webhook) {
    throw new ValidationError('Webhook not found');
  }
  
  webhookStore.delete(webhookId);
  
  logger.info('Webhook deleted', {
    webhookId,
    requestId: req.id
  });
  
  res.json({
    deleted: true,
    effectiveDate: new Date().toISOString()
  });
}));

/**
 * @route PATCH /api/v1/webhooks/:webhookId
 * @description Updates webhook configuration
 */
router.patch('/:webhookId', asyncHandler(async (req, res) => {
  const { webhookId } = req.params;
  const updates = req.body;
  
  const webhook = webhookStore.get(webhookId);
  if (!webhook) {
    throw new ValidationError('Webhook not found');
  }
  
  // Apply updates
  if (updates.url) webhook.url = updates.url;
  if (updates.events) webhook.events = updates.events;
  if (updates.active !== undefined) webhook.active = updates.active;
  if (updates.secret) webhook.secret = updates.secret;
  
  webhookStore.set(webhookId, webhook);
  
  logger.info('Webhook updated', {
    webhookId,
    updates: Object.keys(updates),
    requestId: req.id
  });
  
  res.json({
    webhookId,
    status: 'updated',
    updatedAt: new Date().toISOString()
  });
}));

/**
 * @route POST /api/v1/webhooks/:webhookId/test
 * @description Sends a test event to a webhook
 */
router.post('/:webhookId/test', asyncHandler(async (req, res) => {
  const { webhookId } = req.params;
  const { testEvent } = req.body;
  
  const webhook = webhookStore.get(webhookId);
  if (!webhook) {
    throw new ValidationError('Webhook not found');
  }
  
  logger.info('Webhook test initiated', {
    webhookId,
    testEvent,
    requestId: req.id
  });
  
  res.json({
    webhookId,
    status: 'test_sent',
    testEvent: testEvent || 'application.submitted',
    sentAt: new Date().toISOString()
  });
}));

/**
 * @route GET /api/v1/webhooks/:webhookId/deliveries
 * @description Lists webhook delivery history
 */
router.get('/:webhookId/deliveries', asyncHandler(async (req, res) => {
  const { webhookId } = req.params;
  const { page = 1, limit = 20 } = req.query;
  
  const webhook = webhookStore.get(webhookId);
  if (!webhook) {
    throw new ValidationError('Webhook not found');
  }
  
  // Mock delivery history
  const deliveries = [
    {
      deliveryId: uuidv4(),
      eventType: 'application.submitted',
      status: 'delivered',
      attemptedAt: new Date(Date.now() - 60 * 60 * 1000).toISOString(),
      duration: 245
    },
    {
      deliveryId: uuidv4(),
      eventType: 'application.approved',
      status: 'delivered',
      attemptedAt: new Date(Date.now() - 30 * 60 * 1000).toISOString(),
      duration: 189
    }
  ];
  
  res.json({
    webhookId,
    deliveries,
    pagination: {
      page: parseInt(page, 10),
      limit: parseInt(limit, 10),
      total: deliveries.length
    }
  });
}));

/**
 * @route POST /api/v1/webhooks/events
 * @description Internal endpoint to trigger webhook events
 * This would be called by internal services when events occur
 */
router.post('/events', asyncHandler(async (req, res) => {
  const { eventType, data } = req.body;
  
  logger.info('Webhook event triggered', {
    eventType,
    requestId: req.id
  });
  
  // Find and notify relevant webhooks
  const relevantWebhooks = Array.from(webhookStore.values())
    .filter(w => w.active && w.events.includes(eventType));
  
  const deliveries = relevantWebhooks.map(webhook => ({
    webhookId: webhook.webhookId,
    eventType,
    data,
    scheduledAt: new Date().toISOString()
  }));
  
  res.json({
    eventType,
    webhookCount: deliveries.length,
    deliveries
  });
}));

/**
 * Webhook signature verification helper
 */
const verifyWebhookSignature = (payload, signature, secret) => {
  const expectedSignature = 't=' + Date.now() + ',v1=' + 
    crypto.createHmac('sha256', secret)
      .update(payload)
      .digest('hex');
  
  return signature === expectedSignature;
};

module.exports = router;
