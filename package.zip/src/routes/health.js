/**
 * Health Check Routes
 * 
 * Provides health check and status endpoints for monitoring and load balancers.
 */

const express = require('express');
const { v4: uuidv4 } = require('uuid');
const config = require('../config');
const { logger } = require('../utils/logger');

const router = express.Router();

// Store for tracking service health
const healthStore = {
  startTime: Date.now(),
  checks: {},
  lastCheck: null
};

// Perform basic health check
const basicHealthCheck = () => {
  return {
    status: 'healthy',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
    memory: process.memoryUsage(),
    environment: config.app.environment
  };
};

// Detailed health check including dependencies
const detailedHealthCheck = async () => {
  const checks = {};
  const startTime = Date.now();
  
  // Check memory
  const memUsage = process.memoryUsage();
  checks.memory = {
    status: memUsage.heapUsed < 500 * 1024 * 1024 ? 'healthy' : 'degraded',
    heapUsed: Math.round(memUsage.heapUsed / 1024 / 1024) + 'MB',
    heapTotal: Math.round(memUsage.heapTotal / 1024 / 1024) + 'MB'
  };
  
  // Check uptime
  checks.uptime = {
    status: process.uptime() > 60 ? 'healthy' : 'degraded',
    seconds: Math.round(process.uptime())
  };
  
  // Check event loop delay (approximation)
  checks.eventLoop = {
    status: 'healthy',
    note: 'Event loop responsive'
  };
  
  // Check configuration
  checks.configuration = {
    status: 'healthy',
    environment: config.app.environment,
    version: config.app.version
  };
  
  // Aggregate status
  const allHealthy = Object.values(checks).every(c => c.status === 'healthy');
  const anyDegraded = Object.values(checks).some(c => c.status === 'degraded');
  
  const overallStatus = allHealthy ? 'healthy' : (anyDegraded ? 'degraded' : 'unhealthy');
  
  healthStore.lastCheck = {
    timestamp: new Date().toISOString(),
    status: overallStatus,
    duration: Date.now() - startTime
  };
  
  return {
    status: overallStatus,
    timestamp: new Date().toISOString(),
    version: config.app.version,
    checks,
    duration: healthStore.lastCheck.duration + 'ms'
  };
};

// =============================================================================
// Routes
// =============================================================================

/**
 * @route GET /health
 * @description Simple health check for load balancers
 */
router.get('/', (req, res) => {
  const health = basicHealthCheck();
  const statusCode = health.status === 'healthy' ? 200 : 503;
  res.status(statusCode).json(health);
});

/**
 * @route GET /health/live
 * @description Liveness probe - is the service running?
 */
router.get('/live', (req, res) => {
  res.json({
    status: 'alive',
    timestamp: new Date().toISOString(),
    requestId: req.id || uuidv4()
  });
});

/**
 * @route GET /health/ready
 * @description Readiness probe - is the service ready to receive traffic?
 */
router.get('/ready', (req, res) => {
  const health = basicHealthCheck();
  
  // Additional readiness checks could go here
  // For example: database connections, cache connectivity
  
  if (health.status === 'healthy') {
    res.json({
      status: 'ready',
      timestamp: new Date().toISOString(),
      requestId: req.id || uuidv4()
    });
  } else {
    res.status(503).json({
      status: 'not ready',
      timestamp: new Date().toISOString(),
      details: health,
      requestId: req.id || uuidv4()
    });
  }
});

/**
 * @route GET /health/detailed
 * @description Detailed health check with component status
 */
router.get('/detailed', async (req, res) => {
  try {
    const health = await detailedHealthCheck();
    const statusCode = health.status === 'healthy' ? 200 : (health.status === 'degraded' ? 200 : 503);
    res.status(statusCode).json(health);
  } catch (error) {
    logger.error('Health check failed', { error: error.message });
    res.status(503).json({
      status: 'unhealthy',
      timestamp: new Date().toISOString(),
      error: error.message,
      requestId: req.id || uuidv4()
    });
  }
});

/**
 * @route GET /health/stats
 * @description Service statistics and metrics
 */
router.get('/stats', (req, res) => {
  const memUsage = process.memoryUsage();
  const cpuUsage = process.cpuUsage();
  
  res.json({
    timestamp: new Date().toISOString(),
    uptime: {
      seconds: Math.round(process.uptime()),
      formatted: formatUptime(process.uptime())
    },
    memory: {
      heapUsed: Math.round(memUsage.heapUsed / 1024 / 1024) + 'MB',
      heapTotal: Math.round(memUsage.heapTotal / 1024 / 1024) + 'MB',
      rss: Math.round(memUsage.rss / 1024 / 1024) + 'MB',
      external: Math.round(memUsage.external / 1024 / 1024) + 'MB'
    },
    cpu: {
      user: cpuUsage.user,
      system: cpuUsage.system
    },
    gc: {
      note: 'GC statistics not available in this runtime'
    },
    environment: config.app.environment,
    version: config.app.version,
    requestId: req.id || uuidv4()
  });
});

/**
 * @route GET /health/dependencies
 * @description Status of external dependencies
 */
router.get('/dependencies', async (req, res) => {
  const dependencies = {
    timestamp: new Date().toISOString(),
    dependencies: {}
  };
  
  // Check Redis if configured
  if (config.redis.host) {
    dependencies.dependencies.redis = {
      name: 'Redis',
      status: 'unknown',
      host: config.redis.host,
      port: config.redis.port
    };
  }
  
  // Check linked repositories
  Object.entries(config.repositories).forEach(([key, repo]) => {
    dependencies.dependencies[key] = {
      name: key,
      status: 'configured',
      endpoint: repo.baseUrl
    };
  });
  
  res.json({
    ...dependencies,
    requestId: req.id || uuidv4()
  });
});

// Helper function to format uptime
function formatUptime(seconds) {
  const days = Math.floor(seconds / 86400);
  const hours = Math.floor((seconds % 86400) / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);
  const secs = Math.floor(seconds % 60);
  
  const parts = [];
  if (days > 0) parts.push(`${days}d`);
  if (hours > 0) parts.push(`${hours}h`);
  if (minutes > 0) parts.push(`${minutes}m`);
  parts.push(`${secs}s`);
  
  return parts.join(' ');
}

module.exports = router;
