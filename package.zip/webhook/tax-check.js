/**
 * Tax Check Webhook
 * Runs federal and state tax validation for loan requests
 * 
 * Usage: node webhook/tax-check.js <tax-check-request.json>
 * 
 * @module tax-check
 */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

// Configuration
const CONFIG = {
  taxDataDir: path.join(__dirname, '..', 'data', 'tax'),
  complianceDir: path.join(__dirname, '..', 'governance'),
  federalTaxTables: 'federal-tax-tables.json',
  stateTaxTables: 'state-tax-tables.json',
  usuryLimits: 'usury-limits.json',
  webhookSecret: process.env.WEBHOOK_SECRET || 'default-secret',
  cacheExpirationMs: 3600000, // 1 hour
  maxRetries: 3,
  retryDelayMs: 1000
};

// Tax cache
const taxCache = new Map();

/**
 * Main tax validation function
 */
async function runTaxCheck(checkRequest) {
  const result = {
    valid: true,
    federal_valid: true,
    state_valid: true,
    findings: [],
    warnings: [],
    metadata: {}
  };

  try {
    // Validate check request
    validateCheckRequest(checkRequest, result);
    
    if (!result.valid) {
      return result;
    }

    // Get cached result if available
    const cacheKey = generateCacheKey(checkRequest);
    const cachedResult = getCachedResult(cacheKey);
    
    if (cachedResult) {
      return { ...cachedResult, cached: true };
    }

    // Run federal tax validation
    await validateFederalTax(checkRequest, result);
    
    // Run state tax validation
    await validateStateTax(checkRequest, result);
    
    // Check usury compliance
    await checkUsuryCompliance(checkRequest, result);
    
    // Calculate tax implications
    await calculateTaxImplications(checkRequest, result);
    
    // Generate metadata
    result.metadata = {
      borrowerId: checkRequest.borrower_id,
      loanId: checkRequest.loan_id,
      loanAmount: checkRequest.loan_amount,
      state: checkRequest.borrower_state,
      federalStatus: result.federal_valid ? 'compliant' : 'non_compliant',
      stateStatus: result.state_valid ? 'compliant' : 'non_compliant',
      usuryStatus: result.usury_compliant ? 'compliant' : 'non_compliant',
      validationTimestamp: new Date().toISOString(),
      validationExpiresAt: new Date(Date.now() + CONFIG.cacheExpirationMs).toISOString()
    };

    // Cache the result
    cacheResult(cacheKey, result);

  } catch (error) {
    result.valid = false;
    result.findings.push({
      code: 'TAX_CHECK_ERROR',
      message: error.message,
      severity: 'high'
    });
  }

  return result;
}

/**
 * Validate check request structure
 */
function validateCheckRequest(request, result) {
  result.valid = true;
  result.findings = [];
  result.warnings = [];

  const requiredFields = ['borrower_id', 'loan_amount', 'loan_purpose'];
  
  for (const field of requiredFields) {
    if (!request[field]) {
      result.valid = false;
      result.findings.push({
        code: 'MISSING_FIELD',
        field: field,
        message: `Required field '${field}' is missing`,
        severity: 'high'
      });
    }
  }

  // Validate loan amount
  if (request.loan_amount !== undefined) {
    if (request.loan_amount < 100) {
      result.valid = false;
      result.findings.push({
        code: 'INVALID_AMOUNT',
        field: 'loan_amount',
        message: 'Loan amount is below minimum threshold',
        severity: 'high'
      });
    }
  }

  // Check for borrower state
  if (!request.borrower_state) {
    result.warnings.push({
      code: 'MISSING_STATE',
      message: 'Borrower state not provided, state tax validation skipped'
    });
  }
}

/**
 * Validate federal tax compliance
 */
async function validateFederalTax(request, result) {
  try {
    // Load federal tax tables
    const federalTables = await loadFederalTaxTables();
    
    if (!federalTables) {
      result.warnings.push({
        code: 'FEDERAL_TABLES_UNAVAILABLE',
        message: 'Federal tax tables unavailable, using default validation'
      });
      return;
    }

    // Check for federal tax liens
    if (request.tax_lien_check !== false) {
      const lienResult = await checkFederalTaxLien(request.borrower_id);
      
      if (lienResult.has_lien) {
        result.federal_valid = false;
        result.findings.push({
          code: 'FEDERAL_TAX_LIEN',
          message: `Federal tax lien found: ${lienResult.lien_amount}`,
          severity: lienResult.lien_amount > 10000 ? 'high' : 'medium',
          details: lienResult
        });
      }
    }

    // Check for tax refund offsets
    if (request.refund_offset_check !== false) {
      const offsetResult = await checkRefundOffset(request.borrower_id);
      
      if (offsetResult.has_offset) {
        result.federal_valid = false;
        result.findings.push({
          code: 'TAX_REFUND_OFFSET',
          message: `Tax refund offset detected: ${offsetResult.offset_amount}`,
          severity: 'medium',
          details: offsetResult
        });
      }
    }

    // Validate withholding requirements
    if (request.withholding_required) {
      const withholdingResult = await validateWithholding(request);
      
      if (!withholdingResult.valid) {
        result.federal_valid = false;
        result.findings.push({
          code: 'INVALID_WITHHOLDING',
          message: 'Federal withholding requirements not met',
          severity: 'high',
          details: withholdingResult
        });
      }
    }

    // Check W-2 / 1099 verification
    if (request.income_verification) {
      const incomeResult = await verifyIncomeDocuments(request);
      
      if (!incomeResult.verified) {
        result.warnings.push({
          code: 'INCOME_VERIFICATION_FAILED',
          message: 'Income documents could not be verified',
          severity: 'low',
          details: incomeResult
        });
      }
    }

  } catch (error) {
    result.warnings.push({
      code: 'FEDERAL_VALIDATION_ERROR',
      message: `Federal tax validation error: ${error.message}`
    });
  }
}

/**
 * Validate state tax compliance
 */
async function validateStateTax(request, result) {
  if (!request.borrower_state) {
    return;
  }

  try {
    // Load state tax tables
    const stateTables = await loadStateTaxTables();
    
    if (!stateTables) {
      result.warnings.push({
        code: 'STATE_TABLES_UNAVAILABLE',
        message: 'State tax tables unavailable, using default validation'
      });
      return;
    }

    // Check state-specific requirements
    const stateRules = stateTables[request.borrower_state];
    
    if (!stateRules) {
      result.warnings.push({
        code: 'STATE_RULES_UNAVAILABLE',
        message: `Tax rules for state ${request.borrower_state} not available`
      });
      return;
    }

    // Check for state tax liens
    if (stateRules.require_lien_check) {
      const stateLienResult = await checkStateTaxLien(
        request.borrower_id, 
        request.borrower_state
      );
      
      if (stateLienResult.has_lien) {
        result.state_valid = false;
        result.findings.push({
          code: 'STATE_TAX_LIEN',
          message: `${request.borrower_state} tax lien found`,
          severity: stateLienResult.lien_amount > 5000 ? 'high' : 'medium',
          details: stateLienResult
        });
      }
    }

    // Check state-specific withholding
    if (stateRules.require_withholding) {
      const stateWithholdingResult = await validateStateWithholding(
        request, 
        stateRules
      );
      
      if (!stateWithholdingResult.valid) {
        result.state_valid = false;
        result.findings.push({
          code: 'STATE_WITHHOLDING_REQUIRED',
          message: `${request.borrower_state} requires state withholding`,
          severity: 'medium',
          details: stateWithholdingResult
        });
      }
    }

    // Check for state-specific income verification
    if (stateRules.require_income_verification) {
      const stateIncomeResult = await verifyStateIncome(
        request,
        stateRules
      );
      
      if (!stateIncomeResult.verified) {
        result.warnings.push({
          code: 'STATE_INCOME_VERIFICATION_FAILED',
          message: `${request.borrower_state} income verification not complete`,
          severity: 'low'
        });
      }
    }

    // Apply state-specific rules
    for (const rule of stateRules.special_rules || []) {
      const ruleResult = await applyStateRule(request, rule);
      
      if (!ruleResult.compliant) {
        result.state_valid = false;
        result.findings.push({
          code: `STATE_RULE_${rule.code}`,
          message: rule.message,
          severity: rule.severity || 'medium',
          details: ruleResult
        });
      }
    }

  } catch (error) {
    result.warnings.push({
      code: 'STATE_VALIDATION_ERROR',
      message: `State tax validation error: ${error.message}`
    });
  }
}

/**
 * Check usury compliance
 */
async function checkUsuryCompliance(request, result) {
  try {
    // Load usury limits
    const usuryLimits = await loadUsuryLimits();
    
    if (!usuryLimits) {
      result.warnings.push({
        code: 'USURY_LIMITS_UNAVAILABLE',
        message: 'Usury limits unavailable, skipping compliance check'
      });
      result.usury_compliant = true; // Assume compliant if data unavailable
      return;
    }

    // Calculate effective interest rate
    const effectiveRate = calculateEffectiveRate(
      request.interest_rate,
      request.loan_term_months,
      request.loan_amount
    );

    // Get applicable usury limit
    const stateLimit = usuryLimits[request.borrower_state] || usuryLimits.default;
    const applicableLimit = Math.min(
      stateLimit.max_rate,
      usuryLimits.federal_max_rate
    );

    result.usury_compliant = effectiveRate <= applicableLimit;

    if (!result.usury_compliant) {
      result.findings.push({
        code: 'USURY_VIOLATION',
        message: `Interest rate exceeds usury limit: ${(applicableLimit * 100).toFixed(2)}%`,
        severity: 'critical',
        details: {
          effectiveRate: effectiveRate,
          applicableLimit: applicableLimit,
          state: request.borrower_state
        }
      });
    }

  } catch (error) {
    result.warnings.push({
      code: 'USURY_CHECK_ERROR',
      message: `Usury compliance check error: ${error.message}`
    });
    result.usury_compliant = true;
  }
}

/**
 * Calculate tax implications
 */
async function calculateTaxImplications(request, result) {
  result.tax_implications = {
    deductible_interest: false,
    deductible_fees: false,
    taxable_forgiveness: false,
    forms_required: []
  };

  try {
    // Determine if interest is deductible
    if (request.loan_purpose === 'business' || 
        request.loan_purpose === 'investment') {
      result.tax_implications.deductible_interest = true;
      result.tax_implications.forms_required.push('1098');
    }

    // Check for deductible fees
    if (request.loan_amount > 5000) {
      result.tax_implications.deductible_fees = true;
    }

    // Check for potential debt forgiveness
    if (request.loan_amount > 100000) {
      result.tax_implications.forms_required.push('1099-C');
      result.tax_implications.taxable_forgiveness = true;
    }

    // Calculate estimated tax impact
    if (request.loan_amount) {
      result.tax_implications.estimated_annual_interest = 
        request.loan_amount * request.interest_rate;
      
      result.tax_implications.estimated_deductible_amount = 
        result.tax_implications.deductible_interest 
          ? result.tax_implications.estimated_annual_interest 
          : 0;
    }

  } catch (error) {
    result.warnings.push({
      code: 'TAX_IMPLICATION_ERROR',
      message: `Tax implication calculation error: ${error.message}`
    });
  }
}

/**
 * Check federal tax lien
 */
async function checkFederalTaxLien(borrowerId) {
  // Simulate API call
  await simulateDelay(100);
  
  // Random chance of lien for demonstration
  const hasLien = Math.random() < 0.02;
  
  return {
    has_lien: hasLien,
    lien_amount: hasLien ? Math.floor(Math.random() * 50000) + 1000 : 0,
    lien_date: hasLien ? new Date(Date.now() - Math.random() * 365 * 24 * 60 * 60 * 1000).toISOString() : null,
    tax_period: hasLien ? '2023' : null
  };
}

/**
 * Check tax refund offset
 */
async function checkRefundOffset(borrowerId) {
  // Simulate API call
  await simulateDelay(100);
  
  const hasOffset = Math.random() < 0.01;
  
  return {
    has_offset: hasOffset,
    offset_amount: hasOffset ? Math.floor(Math.random() * 5000) + 500 : 0,
    offset_reason: hasOffset ? 'Outstanding tax liability' : null
  };
}

/**
 * Validate withholding
 */
async function validateWithholding(request) {
  const requiredRate = 0.10; // Default 10% withholding
  const providedRate = request.withholding_rate || 0;
  
  return {
    valid: providedRate >= requiredRate,
    required_rate: requiredRate,
    provided_rate: providedRate
  };
}

/**
 * Verify income documents
 */
async function verifyIncomeDocuments(request) {
  await simulateDelay(100);
  
  return {
    verified: Math.random() > 0.1,
    documents_reviewed: ['W-2', 'Tax Returns'],
    income_confirmed: true,
    discrepancies: []
  };
}

/**
 * Check state tax lien
 */
async function checkStateTaxLien(borrowerId, state) {
  await simulateDelay(100);
  
  const hasLien = Math.random() < 0.015;
  
  return {
    has_lien: hasLien,
    lien_amount: hasLien ? Math.floor(Math.random() * 30000) + 500 : 0,
    state: state
  };
}

/**
 * Validate state withholding
 */
async function validateStateWithholding(request, stateRules) {
  const requiredRate = stateRules.withholding_rate || 0.05;
  const providedRate = request.state_withholding_rate || 0;
  
  return {
    valid: providedRate >= requiredRate,
    required_rate: requiredRate,
    provided_rate: providedRate
  };
}

/**
 * Verify state income
 */
async function verifyStateIncome(request, stateRules) {
  await simulateDelay(100);
  
  return {
    verified: true,
    state_specific_documents: stateRules.required_documents || []
  };
}

/**
 * Apply state-specific rule
 */
async function applyStateRule(request, rule) {
  await simulateDelay(50);
  
  // In production, this would apply actual rule logic
  const compliant = Math.random() > 0.1;
  
  return {
    compliant: compliant,
    rule_applied: rule.code
  };
}

/**
 * Calculate effective interest rate
 */
function calculateEffectiveRate(nominalRate, termMonths, principal) {
  // Convert annual rate to monthly
  const monthlyRate = nominalRate / 12;
  
  // Calculate total interest over loan term
  const totalInterest = principal * monthlyRate * termMonths;
  
  // Calculate effective annual rate
  const effectiveRate = (1 + monthlyRate) ** 12 - 1;
  
  return effectiveRate;
}

/**
 * Load federal tax tables
 */
async function loadFederalTaxTables() {
  const cacheKey = 'federal_tables';
  
  if (taxCache.has(cacheKey)) {
    const cached = taxCache.get(cacheKey);
    if (Date.now() - cached.timestamp < CONFIG.cacheExpirationMs) {
      return cached.data;
    }
  }

  try {
    const tablesPath = path.join(
      CONFIG.taxDataDir, 
      CONFIG.federalTaxTables
    );
    
    if (fs.existsSync(tablesPath)) {
      const content = fs.readFileSync(tablesPath, 'utf8');
      const data = JSON.parse(content);
      
      taxCache.set(cacheKey, {
        data,
        timestamp: Date.now()
      });
      
      return data;
    }
  } catch (error) {
    console.error('Error loading federal tax tables:', error.message);
  }

  // Return default configuration
  return null;
}

/**
 * Load state tax tables
 */
async function loadStateTaxTables() {
  const cacheKey = 'state_tables';
  
  if (taxCache.has(cacheKey)) {
    const cached = taxCache.get(cacheKey);
    if (Date.now() - cached.timestamp < CONFIG.cacheExpirationMs) {
      return cached.data;
    }
  }

  try {
    const tablesPath = path.join(
      CONFIG.taxDataDir, 
      CONFIG.stateTaxTables
    );
    
    if (fs.existsSync(tablesPath)) {
      const content = fs.readFileSync(tablesPath, 'utf8');
      const data = JSON.parse(content);
      
      taxCache.set(cacheKey, {
        data,
        timestamp: Date.now()
      });
      
      return data;
    }
  } catch (error) {
    console.error('Error loading state tax tables:', error.message);
  }

  return null;
}

/**
 * Load usury limits
 */
async function loadUsuryLimits() {
  const cacheKey = 'usury_limits';
  
  if (taxCache.has(cacheKey)) {
    const cached = taxCache.get(cacheKey);
    if (Date.now() - cached.timestamp < CONFIG.cacheExpirationMs) {
      return cached.data;
    }
  }

  try {
    const limitsPath = path.join(
      CONFIG.complianceDir, 
      CONFIG.usuryLimits
    );
    
    if (fs.existsSync(limitsPath)) {
      const content = fs.readFileSync(limitsPath, 'utf8');
      const data = JSON.parse(content);
      
      taxCache.set(cacheKey, {
        data,
        timestamp: Date.now()
      });
      
      return data;
    }
  } catch (error) {
    console.error('Error loading usury limits:', error.message);
  }

  return null;
}

/**
 * Generate cache key
 */
function generateCacheKey(request) {
  const keyData = {
    borrower_id: request.borrower_id,
    loan_amount: request.loan_amount,
    loan_purpose: request.loan_purpose,
    borrower_state: request.borrower_state
  };
  
  return crypto
    .createHash('md5')
    .update(JSON.stringify(keyData))
    .digest('hex');
}

/**
 * Get cached result
 */
function getCachedResult(cacheKey) {
  if (taxCache.has(cacheKey)) {
    const cached = taxCache.get(cacheKey);
    if (Date.now() - cached.timestamp < CONFIG.cacheExpirationMs) {
      return cached.data;
    }
  }
  return null;
}

/**
 * Cache result
 */
function cacheResult(cacheKey, result) {
  taxCache.set(cacheKey, {
    data: result,
    timestamp: Date.now()
  });
}

/**
 * Simulate async delay
 */
function simulateDelay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * Clear tax cache
 */
function clearCache() {
  taxCache.clear();
}

/**
 * Get cache statistics
 */
function getCacheStats() {
  const now = Date.now();
  let validEntries = 0;
  let expiredEntries = 0;
  
  for (const [key, value] of taxCache) {
    if (now - value.timestamp < CONFIG.cacheExpirationMs) {
      validEntries++;
    } else {
      expiredEntries++;
    }
  }
  
  return {
    totalEntries: taxCache.size,
    validEntries,
    expiredEntries,
    maxAgeMs: CONFIG.cacheExpirationMs
  };
}

// CLI Interface
if (require.main === module) {
  const args = process.argv.slice(2);
  
  if (args.length === 0) {
    console.error('Usage: node tax-check.js <tax-check-request.json>');
    console.error('       or pipe JSON data to stdin');
    process.exit(1);
  }

  let checkRequest;
  
  if (args[0] === '-') {
    // Read from stdin
    const stdin = process.stdin;
    let data = '';
    
    stdin.on('data', chunk => { data += chunk; });
    stdin.on('end', async () => {
      try {
        checkRequest = JSON.parse(data);
        const result = await runTaxCheck(checkRequest);
        console.log(JSON.stringify(result, null, 2));
      } catch (error) {
        console.error('Error:', error.message);
        process.exit(1);
      }
    });
  } else {
    // Read from file
    try {
      const filePath = path.resolve(args[0]);
      const content = fs.readFileSync(filePath, 'utf8');
      checkRequest = JSON.parse(content);
      
      runTaxCheck(checkRequest).then(result => {
        console.log(JSON.stringify(result, null, 2));
      });
    } catch (error) {
      console.error('Error reading file:', error.message);
      process.exit(1);
    }
  }
}

module.exports = {
  runTaxCheck,
  validateFederalTax,
  validateStateTax,
  checkUsuryCompliance,
  calculateTaxImplications,
  clearCache,
  getCacheStats,
  CONFIG
};
