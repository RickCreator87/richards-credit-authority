/**
 * Validate Loan Request Webhook
 * Validates identity, permissions, tax, and governance for loan requests
 * 
 * Usage: node webhook/validate-loan-request.js <loan-request.json>
 * 
 * @module validate-loan-request
 */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

// Configuration
const CONFIG = {
  schemaDir: path.join(__dirname, '..', 'permission'),
  governanceDir: path.join(__dirname, '..', 'governance'),
  maxLoanAmount: 500000,
  minLoanAmount: 100,
  supportedLoanTerms: [6, 12, 24, 36, 48, 60, 120, 180, 240, 360],
  maxInterestRate: 0.36,
  minInterestRate: 0.01
};

/**
 * Main validation function
 */
async function validateLoanRequest(requestData) {
  const result = {
    valid: true,
    errors: [],
    warnings: [],
    metadata: {}
  };

  try {
    // Validate request structure
    validateRequestStructure(requestData, result);
    
    if (!result.valid) {
      return result;
    }

    // Validate identity
    await validateIdentity(requestData.borrower, result);
    
    // Validate permissions
    validatePermissions(requestData, result);
    
    // Validate tax compliance
    await validateTaxCompliance(requestData, result);
    
    // Validate governance requirements
    validateGovernance(requestData, result);
    
    // Calculate risk score
    await calculateRiskScore(requestData, result);
    
    // Generate validation metadata
    result.metadata = generateMetadata(requestData, result);
    
  } catch (error) {
    result.valid = false;
    result.errors.push({
      code: 'INTERNAL_ERROR',
      message: error.message,
      stack: error.stack
    });
  }

  return result;
}

/**
 * Validate request structure
 */
function validateRequestStructure(data, result) {
  const requiredFields = [
    'borrower_id',
    'loan_amount',
    'loan_purpose',
    'loan_term_months',
    'interest_rate',
    'repayment_frequency'
  ];

  for (const field of requiredFields) {
    if (!data[field]) {
      result.valid = false;
      result.errors.push({
        code: 'MISSING_FIELD',
        field: field,
        message: `Required field '${field}' is missing`
      });
    }
  }

  // Validate loan amount
  if (data.loan_amount) {
    if (data.loan_amount < CONFIG.minLoanAmount) {
      result.valid = false;
      result.errors.push({
        code: 'INVALID_AMOUNT',
        field: 'loan_amount',
        message: `Loan amount must be at least ${CONFIG.minLoanAmount}`
      });
    } else if (data.loan_amount > CONFIG.maxLoanAmount) {
      result.valid = false;
      result.errors.push({
        code: 'INVALID_AMOUNT',
        field: 'loan_amount',
        message: `Loan amount cannot exceed ${CONFIG.maxLoanAmount}`
      });
    }
  }

  // Validate loan term
  if (data.loan_term_months) {
    if (!CONFIG.supportedLoanTerms.includes(data.loan_term_months)) {
      result.valid = false;
      result.errors.push({
        code: 'INVALID_TERM',
        field: 'loan_term_months',
        message: `Loan term must be one of: ${CONFIG.supportedLoanTerms.join(', ')}`
      });
    }
  }

  // Validate interest rate
  if (data.interest_rate) {
    if (data.interest_rate < CONFIG.minInterestRate) {
      result.valid = false;
      result.errors.push({
        code: 'INVALID_RATE',
        field: 'interest_rate',
        message: `Interest rate must be at least ${CONFIG.minInterestRate}`
      });
    } else if (data.interest_rate > CONFIG.maxInterestRate) {
      result.valid = false;
      result.errors.push({
        code: 'INVALID_RATE',
        field: 'interest_rate',
        message: `Interest rate cannot exceed ${CONFIG.maxInterestRate}`
      });
    }
  }

  // Validate repayment frequency
  const validFrequencies = ['weekly', 'biweekly', 'monthly', 'quarterly', 'annually'];
  if (data.repayment_frequency && !validFrequencies.includes(data.repayment_frequency)) {
    result.valid = false;
    result.errors.push({
      code: 'INVALID_FREQUENCY',
      field: 'repayment_frequency',
      message: `Repayment frequency must be one of: ${validFrequencies.join(', ')}`
    });
  }
}

/**
 * Validate borrower identity
 */
async function validateIdentity(borrower, result) {
  if (!borrower) {
    result.valid = false;
    result.errors.push({
      code: 'MISSING_BORROWER',
      message: 'Borrower information is required'
    });
    return;
  }

  const requiredIdentityFields = [
    'full_legal_name',
    'date_of_birth',
    'email_address',
    'phone_number'
  ];

  for (const field of requiredIdentityFields) {
    if (!borrower[field]) {
      result.valid = false;
      result.errors.push({
        code: 'MISSING_IDENTITY_FIELD',
        field: field,
        message: `Required identity field '${field}' is missing`
      });
    }
  }

  // Validate email format
  if (borrower.email_address) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(borrower.email_address)) {
      result.valid = false;
      result.errors.push({
        code: 'INVALID_EMAIL',
        field: 'email_address',
        message: 'Invalid email format'
      });
    }
  }

  // Validate phone format
  if (borrower.phone_number) {
    const phoneRegex = /^\+?[1-9]\d{1,14}$/;
    if (!phoneRegex.test(borrower.phone_number.replace(/[\s\-\(\)]/g, ''))) {
      result.warnings.push({
        code: 'PHONE_FORMAT',
        field: 'phone_number',
        message: 'Phone number format may be invalid'
      });
    }
  }

  // Validate date of birth
  if (borrower.date_of_birth) {
    const dob = new Date(borrower.date_of_birth);
    const age = (new Date() - dob) / (365.25 * 24 * 60 * 60 * 1000);
    
    if (age < 18) {
      result.valid = false;
      result.errors.push({
        code: 'MINOR_BORROWER',
        field: 'date_of_birth',
        message: 'Borrower must be at least 18 years old'
      });
    } else if (age > 120) {
      result.valid = false;
      result.errors.push({
        code: 'INVALID_AGE',
        field: 'date_of_birth',
        message: 'Invalid date of birth'
      });
    }
  }

  // Check for identity verification status
  if (borrower.identity_verified !== true) {
    result.warnings.push({
      code: 'IDENTITY_NOT_VERIFIED',
      message: 'Borrower identity has not been verified'
    });
  }
}

/**
 * Validate permissions for the request
 */
function validatePermissions(requestData, result) {
  const permissionMatrix = loadPermissionMatrix();
  
  if (!permissionMatrix) {
    result.errors.push({
      code: 'PERMISSION_MATRIX_ERROR',
      message: 'Unable to load permission matrix'
    });
    return;
  }

  // Determine required authority level based on loan amount
  let requiredAuthority = 60; // Default to officer level
  
  if (requestData.loan_amount <= 10000) {
    requiredAuthority = 60; // Officer
  } else if (requestData.loan_amount <= 50000) {
    requiredAuthority = 80; // Admin
  } else {
    requiredAuthority = 100; // Founder
  }

  result.metadata.requiredAuthority = requiredAuthority;

  // Check for dual approval requirements
  const dualApprovalRequired = permissionMatrix.thresholds
    .filter(t => requestData.loan_amount > t.max_amount && t.requires_dual_approval);

  if (dualApprovalRequired.length > 0) {
    result.metadata.dualApprovalRequired = true;
    result.warnings.push({
      code: 'DUAL_APPROVAL_REQUIRED',
      message: 'This loan requires dual founder approval'
    });
  }

  // Validate against escalation rules
  const escalationRules = permissionMatrix.escalation_rules || [];
  for (const rule of escalationRules) {
    if (evaluateCondition(rule.condition, requestData)) {
      result.metadata.escalationRequired = rule.action;
      result.metadata.escalateTo = rule.escalate_to;
    }
  }
}

/**
 * Validate tax compliance
 */
async function validateTaxCompliance(requestData, result) {
  // Check if tax validation is required
  const taxValidationRequired = requestData.loan_amount >= 10000;
  
  if (!taxValidationRequired) {
    result.metadata.taxValidationStatus = 'not_required';
    return;
  }

  // Simulate tax check (in production, this would call the tax-check webhook)
  result.metadata.taxValidationStatus = 'pending';
  
  try {
    const taxResult = await simulateTaxCheck(requestData);
    
    if (taxResult.federal_valid && taxResult.state_valid) {
      result.metadata.taxValidationStatus = 'passed';
    } else {
      result.valid = false;
      result.errors.push({
        code: 'TAX_COMPLIANCE_FAILED',
        message: 'Tax compliance validation failed',
        details: taxResult.issues
      });
    }
  } catch (error) {
    result.warnings.push({
      code: 'TAX_CHECK_ERROR',
      message: 'Unable to complete tax validation'
    });
  }
}

/**
 * Validate governance requirements
 */
function validateGovernance(requestData, result) {
  const governanceData = loadGovernanceData();
  
  if (!governanceData) {
    result.warnings.push({
      code: 'GOVERNANCE_DATA_ERROR',
      message: 'Unable to load governance data'
    });
    return;
  }

  // Determine approval path
  const approvalPath = determineApprovalPath(requestData, governanceData);
  result.metadata.approvalPath = approvalPath.path;
  result.metadata.requiredApprovers = approvalPath.requiredApprovers;

  // Check milestone requirements
  if (requestData.borrower && requestData.borrower.milestone_level) {
    const milestoneBenefits = getMilestoneBenefits(requestData.borrower.milestone_level);
    result.metadata.milestoneBenefits = milestoneBenefits;
    
    if (milestoneBenefits.expeditedProcessing) {
      result.warnings.push({
        code: 'EXPEDITED_PROCESSING',
        message: 'Borrower qualifies for expedited processing'
      });
    }
  }

  // Validate against risk thresholds
  const riskTier = getRiskTier(result.riskScore);
  result.metadata.riskTier = riskTier;
  
  if (riskTier === 'very_high_risk' && requestData.loan_amount > 5000) {
    result.valid = false;
    result.errors.push({
      code: 'RISK_THRESHOLD_EXCEEDED',
      message: 'Loan cannot be approved due to excessive risk'
    });
  }
}

/**
 * Calculate risk score for the loan request
 */
async function calculateRiskScore(requestData, result) {
  const riskConfig = loadRiskConfiguration();
  
  if (!riskConfig) {
    result.riskScore = 50; // Default score
    result.warnings.push({
      code: 'RISK_CONFIG_ERROR',
      message: 'Unable to load risk configuration, using default'
    });
    return;
  }

  let score = riskConfig.base_score;

  // Credit score factor
  if (requestData.borrower && requestData.borrower.credit_score) {
    const creditScore = requestData.borrower.credit_score;
    const creditFactor = riskConfig.factors.find(f => f.name === 'credit_score');
    
    if (creditFactor) {
      const creditRange = creditFactor.scoring.find(
        r => creditScore >= r.range[0] && creditScore <= r.range[1]
      );
      
      if (creditRange) {
        if (creditFactor.reverse_scale) {
          score += creditFactor.weight * creditRange.score;
        } else {
          score += creditFactor.weight * (100 - creditRange.score);
        }
      }
    }
  } else {
    score += 30; // Penalty for no credit score
  }

  // Debt-to-income factor
  if (requestData.debt_to_income_ratio) {
    const dtiFactor = riskConfig.factors.find(f => f.name === 'debt_to_income_ratio');
    
    if (dtiFactor) {
      const dtiRange = dtiFactor.scoring.find(
        r => requestData.debt_to_income_ratio >= r.range[0] && 
             requestData.debt_to_income_ratio <= r.range[1]
      );
      
      if (dtiRange) {
        score += dtiFactor.weight * dtiRange.score;
      }
    }
  }

  // Loan amount factor
  if (requestData.loan_amount) {
    const amountFactor = Math.min(requestData.loan_amount / CONFIG.maxLoanAmount, 1) * 20;
    score += amountFactor;
  }

  // Cap score at maximum
  result.riskScore = Math.min(Math.max(score, 0), riskConfig.max_score);
}

/**
 * Load permission matrix from file
 */
function loadPermissionMatrix() {
  try {
    const matrixPath = path.join(CONFIG.schemaDir, 'permission-matrix.yaml');
    
    if (fs.existsSync(matrixPath)) {
      const content = fs.readFileSync(matrixPath, 'utf8');
      return parseYaml(content);
    }
    
    // Return default configuration if file doesn't exist
    return {
      thresholds: [
        { max_amount: 10000, required_authority: 60 },
        { max_amount: 50000, required_authority: 80 },
        { max_amount: 100000, required_authority: 100, requires_dual_approval: false },
        { max_amount: 500000, required_authority: 100, requires_dual_approval: true }
      ],
      escalation_rules: []
    };
  } catch (error) {
    console.error('Error loading permission matrix:', error.message);
    return null;
  }
}

/**
 * Load governance data
 */
function loadGovernanceData() {
  try {
    const workflowPath = path.join(CONFIG.governanceDir, 'approval-workflow.yaml');
    
    if (fs.existsSync(workflowPath)) {
      const content = fs.readFileSync(workflowPath, 'utf8');
      return parseYaml(content);
    }
    
    return null;
  } catch (error) {
    console.error('Error loading governance data:', error.message);
    return null;
  }
}

/**
 * Load risk configuration
 */
function loadRiskConfiguration() {
  try {
    const riskPath = path.join(CONFIG.governanceDir, 'risk-controls.yaml');
    
    if (fs.existsSync(riskPath)) {
      const content = fs.readFileSync(riskPath, 'utf8');
      return parseYaml(content);
    }
    
    return null;
  } catch (error) {
    console.error('Error loading risk configuration:', error.message);
    return null;
  }
}

/**
 * Simulate tax check (placeholder for actual tax check)
 */
async function simulateTaxCheck(requestData) {
  // Simulate async operation
  await new Promise(resolve => setTimeout(resolve, 100));
  
  return {
    federal_valid: true,
    state_valid: true,
    issues: []
  };
}

/**
 * Determine approval path based on loan parameters
 */
function determineApprovalPath(requestData, governanceData) {
  const amount = requestData.loan_amount || 0;
  
  let path = 'standard_loan';
  let requiredApprovers = [{ role: 'richard_officer', count: 1 }];
  
  if (amount <= 10000) {
    path = 'standard_loan';
    requiredApprovers = [{ role: 'richard_officer', count: 1 }];
  } else if (amount <= 50000) {
    path = 'moderate_loan';
    requiredApprovers = [{ role: 'richard_admin', count: 1 }];
  } else if (amount <= 100000) {
    path = 'large_loan';
    requiredApprovers = [
      { role: 'richard_founder', count: 1 },
      { role: 'richard_admin', count: 1 }
    ];
  } else {
    path = 'enterprise_loan';
    requiredApprovers = [
      { role: 'richard_founder', count: 2 }
    ];
  }
  
  return { path, requiredApprovers };
}

/**
 * Get milestone benefits for borrower
 */
function getMilestoneBenefits(milestoneLevel) {
  const benefits = {
    0: {},
    1: {},
    2: { expeditedProcessing: false, documentationReduction: 0.25, interestDiscount: 0.0025 },
    3: { expeditedProcessing: true, documentationReduction: 0.5, interestDiscount: 0.005 },
    4: { expeditedProcessing: true, documentationReduction: 0.75, interestDiscount: 0.0075 },
    5: { expeditedProcessing: true, documentationReduction: 0.9, interestDiscount: 0.01 }
  };
  
  return benefits[milestoneLevel] || benefits[0];
}

/**
 * Get risk tier based on score
 */
function getRiskTier(score) {
  if (score <= 30) return 'low_risk';
  if (score <= 50) return 'medium_risk';
  if (score <= 70) return 'high_risk';
  return 'very_high_risk';
}

/**
 * Generate validation metadata
 */
function generateMetadata(requestData, result) {
  return {
    timestamp: new Date().toISOString(),
    requestId: generateRequestId(),
    loanAmount: requestData.loan_amount,
    requiredAuthority: result.metadata.requiredAuthority || 60,
    dualApprovalRequired: result.metadata.dualApprovalRequired || false,
    escalationRequired: result.metadata.escalationRequired || null,
    riskTier: result.metadata.riskTier || 'unknown',
    riskScore: result.riskScore || 50,
    taxValidationStatus: result.metadata.taxValidationStatus || 'not_required',
    approvalPath: result.metadata.approvalPath || 'standard_loan',
    requiredApprovers: result.metadata.requiredApprovers || [],
    milestoneBenefits: result.metadata.milestoneBenefits || {}
  };
}

/**
 * Evaluate condition string against request data
 */
function evaluateCondition(condition, data) {
  try {
    // Simple condition evaluation (expand as needed)
    if (condition.startsWith('loan_amount > ')) {
      const threshold = parseFloat(condition.split('>')[1].trim());
      return (data.loan_amount || 0) > threshold;
    }
    return false;
  } catch (error) {
    return false;
  }
}

/**
 * Simple YAML parser (replace with proper YAML library in production)
 */
function parseYaml(yamlString) {
  try {
    // This is a simplified YAML parser
    // In production, use js-yaml or similar library
    const lines = yamlString.split('\n');
    const result = {};
    let currentKey = null;
    let currentObj = null;
    
    for (const line of lines) {
      const trimmedLine = line.trim();
      if (!trimmedLine || trimmedLine.startsWith('#')) continue;
      
      const indent = line.search(/\S/);
      
      if (trimmedLine.includes(':')) {
        const [key, value] = trimmedLine.split(':').map(s => s.trim());
        
        if (value === '' || value === null || value === undefined) {
          currentObj = {};
          result[key] = currentObj;
          currentKey = key;
        } else {
          currentObj[key] = parseValue(value);
        }
      }
    }
    
    return result;
  } catch (error) {
    console.error('YAML parsing error:', error.message);
    return null;
  }
}

/**
 * Parse YAML value
 */
function parseValue(value) {
  if (value === 'true') return true;
  if (value === 'false') return false;
  if (value === 'null') return null;
  if (/^\d+$/.test(value)) return parseInt(value, 10);
  if (/^\d+\.\d+$/.test(value)) return parseFloat(value);
  return value.replace(/['"]/g, '');
}

/**
 * Generate unique request ID
 */
function generateRequestId() {
  return `REQ-${Date.now()}-${crypto.randomBytes(4).toString('hex')}`;
}

// CLI Interface
if (require.main === module) {
  const args = process.argv.slice(2);
  
  if (args.length === 0) {
    console.error('Usage: node validate-loan-request.js <loan-request.json>');
    console.error('       or pipe JSON data to stdin');
    process.exit(1);
  }

  let requestData;
  
  if (args[0] === '-') {
    // Read from stdin
    const stdin = process.stdin;
    let data = '';
    
    stdin.on('data', chunk => { data += chunk; });
    stdin.on('end', async () => {
      try {
        requestData = JSON.parse(data);
        const result = await validateLoanRequest(requestData);
        console.log(JSON.stringify(result, null, 2));
      } catch (error) {
        console.error('Error:', error.message);
        process.exit(1);
      }
    });
  } else {
    // Read from file
    try {
      const filePath = path.resolve(args[0]);
      const content = fs.readFileSync(filePath, 'utf8');
      requestData = JSON.parse(content);
      
      validateLoanRequest(requestData).then(result => {
        console.log(JSON.stringify(result, null, 2));
      });
    } catch (error) {
      console.error('Error reading file:', error.message);
      process.exit(1);
    }
  }
}

module.exports = {
  validateLoanRequest,
  CONFIG
};
