/**
 * Update Authority Status Webhook
 * Updates authority levels based on milestones or audits
 * 
 * Usage: node webhook/update-authority-status.js <status-update-request.json>
 * 
 * @module update-authority-status
 */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

// Configuration
const CONFIG = {
  permissionDir: path.join(__dirname, '..', 'permission'),
  governanceDir: path.join(__dirname, '..', 'governance'),
  auditDir: path.join(__dirname, '..', 'governance'),
  maxAuthorityLevel: 100,
  minAuthorityLevel: 1,
  milestoneBonus: 5, // Authority points per milestone
  milestoneMaxBonus: 25, // Maximum milestone bonus
  auditPenalty: 10, // Penalty points per audit finding
  auditPenaltyMax: 50, // Maximum audit penalty
  webhookSecret: process.env.WEBHOOK_SECRET || 'default-secret',
  requireDualApproval: true
};

// Authority state storage
let authorityState = {};

/**
 * Main function to update authority status
 */
async function updateAuthorityStatus(updateRequest) {
  const result = {
    success: false,
    updates: [],
    errors: [],
    metadata: {}
  };

  try {
    // Validate update request
    validateUpdateRequest(updateRequest, result);
    
    if (!result.success) {
      return result;
    }

    // Check for dual approval requirement
    if (CONFIG.requireDualApproval && !updateRequest.dual_approval_confirmed) {
      result.errors.push({
        code: 'DUAL_APPROVAL_REQUIRED',
        message: 'Authority status updates require dual founder approval'
      });
      return result;
    }

    // Process the update based on type
    let updateResult;
    
    switch (updateRequest.update_type) {
      case 'milestone_based':
        updateResult = await processMilestoneUpdate(updateRequest);
        break;
        
      case 'audit_based':
        updateResult = await processAuditUpdate(updateRequest);
        break;
        
      case 'manual_override':
        updateResult = await processManualOverride(updateRequest);
        break;
        
      case 'risk_based':
        updateResult = await processRiskBasedUpdate(updateRequest);
        break;
        
      default:
        result.errors.push({
          code: 'INVALID_UPDATE_TYPE',
          message: `Unknown update type: ${updateRequest.update_type}`
        });
        return result;
    }

    result.success = updateResult.success;
    result.updates = updateResult.updates;
    result.errors = result.errors.concat(updateResult.errors);
    result.metadata = {
      updateType: updateRequest.update_type,
      targetEntity: updateRequest.target_entity,
      previousLevel: updateResult.previousLevel,
      newLevel: updateResult.newLevel,
      effectiveDate: updateResult.effectiveDate,
      reason: updateRequest.reason,
      approvedBy: updateRequest.approved_by,
      timestamp: new Date().toISOString()
    };

    // Log the update
    await logAuthorityUpdate(result.metadata);

  } catch (error) {
    result.errors.push({
      code: 'UPDATE_ERROR',
      message: error.message,
      stack: error.stack
    });
  }

  return result;
}

/**
 * Validate update request
 */
function validateUpdateRequest(request, result) {
  result.success = true;
  result.errors = [];
  result.updates = [];

  const requiredFields = ['update_type', 'target_entity', 'target_id', 'reason', 'approved_by'];
  
  for (const field of requiredFields) {
    if (!request[field]) {
      result.success = false;
      result.errors.push({
        code: 'MISSING_FIELD',
        field: field,
        message: `Required field '${field}' is missing`
      });
    }
  }

  // Validate update type
  const validUpdateTypes = ['milestone_based', 'audit_based', 'manual_override', 'risk_based'];
  if (request.update_type && !validUpdateTypes.includes(request.update_type)) {
    result.success = false;
    result.errors.push({
      code: 'INVALID_UPDATE_TYPE',
      field: 'update_type',
      message: `Update type must be one of: ${validUpdateTypes.join(', ')}`
    });
  }

  // Validate authority level if provided
  if (request.new_authority_level !== undefined) {
    if (request.new_authority_level < CONFIG.minAuthorityLevel || 
        request.new_authority_level > CONFIG.maxAuthorityLevel) {
      result.success = false;
      result.errors.push({
        code: 'INVALID_AUTHORITY_LEVEL',
        field: 'new_authority_level',
        message: `Authority level must be between ${CONFIG.minAuthorityLevel} and ${CONFIG.maxAuthorityLevel}`
      });
    }
  }

  // Validate target entity
  const validEntities = ['borrower', 'officer', 'admin', 'system'];
  if (request.target_entity && !validEntities.includes(request.target_entity)) {
    result.success = false;
    result.errors.push({
      code: 'INVALID_TARGET_ENTITY',
      field: 'target_entity',
      message: `Target entity must be one of: ${validEntities.join(', ')}`
    });
  }
}

/**
 * Process milestone-based authority update
 */
async function processMilestoneUpdate(request) {
  const result = { success: true, updates: [], errors: [], previousLevel: 0, newLevel: 0 };
  
  try {
    // Get current state
    const currentState = await getEntityState(request.target_entity, request.target_id);
    result.previousLevel = currentState.authority_level || getDefaultAuthority(request.target_entity);

    // Calculate new level based on milestone
    const milestoneLevel = request.milestone_level || currentState.milestone_level || 0;
    const milestoneBonus = Math.min(milestoneLevel * CONFIG.milestoneBonus, CONFIG.milestoneMaxBonus);
    const baseLevel = getDefaultAuthority(request.target_entity);
    
    result.newLevel = Math.min(baseLevel + milestoneBonus, CONFIG.maxAuthorityLevel);

    // Apply any additional adjustments
    if (request.adjustments) {
      for (const adjustment of request.adjustments) {
        result.newLevel = applyAdjustment(result.newLevel, adjustment);
      }
    }

    // Create update record
    const update = {
      field: 'authority_level',
      previousValue: result.previousLevel,
      newValue: result.newLevel,
      reason: 'milestone_based',
      milestoneLevel: milestoneLevel,
      effectiveDate: new Date().toISOString()
    };
    
    result.updates.push(update);

    // Apply the update
    await applyUpdate(request.target_entity, request.target_id, update);

  } catch (error) {
    result.success = false;
    result.errors.push({
      code: 'MILESTONE_UPDATE_ERROR',
      message: error.message
    });
  }

  return result;
}

/**
 * Process audit-based authority update
 */
async function processAuditUpdate(request) {
  const result = { success: true, updates: [], errors: [], previousLevel: 0, newLevel: 0 };
  
  try {
    // Get current state
    const currentState = await getEntityState(request.target_entity, request.target_id);
    result.previousLevel = currentState.authority_level || getDefaultAuthority(request.target_entity);

    // Calculate penalty based on audit findings
    let penalty = 0;
    
    if (request.audit_findings) {
      for (const finding of request.audit_findings) {
        penalty += finding.severity_score || 1;
      }
    }
    
    // Apply penalty limits
    penalty = Math.min(penalty, CONFIG.auditPenaltyMax);

    // Calculate new level
    result.newLevel = Math.max(result.previousLevel - penalty, CONFIG.minAuthorityLevel);

    // Create update record
    const update = {
      field: 'authority_level',
      previousValue: result.previousLevel,
      newValue: result.newLevel,
      reason: 'audit_based',
      auditFindings: request.audit_findings,
      penaltyApplied: penalty,
      effectiveDate: new Date().toISOString()
    };
    
    result.updates.push(update);

    // Apply the update
    await applyUpdate(request.target_entity, request.target_id, update);

    // Log audit finding
    await logAuditFinding(request.audit_findings, request.target_id);

  } catch (error) {
    result.success = false;
    result.errors.push({
      code: 'AUDIT_UPDATE_ERROR',
      message: error.message
    });
  }

  return result;
}

/**
 * Process manual override of authority level
 */
async function processManualOverride(request) {
  const result = { success: true, updates: [], errors: [], previousLevel: 0, newLevel: 0 };
  
  try {
    // Get current state
    const currentState = await getEntityState(request.target_entity, request.target_id);
    result.previousLevel = currentState.authority_level || getDefaultAuthority(request.target_entity);

    // Validate override request
    if (!request.new_authority_level && !request.adjustments) {
      result.success = false;
      result.errors.push({
        code: 'MISSING_OVERRIDE_VALUE',
        message: 'Manual override requires new_authority_level or adjustments'
      });
      return result;
    }

    // Apply override
    if (request.new_authority_level !== undefined) {
      result.newLevel = request.new_authority_level;
    } else if (request.adjustments) {
      result.newLevel = result.previousLevel;
      for (const adjustment of request.adjustments) {
        result.newLevel = applyAdjustment(result.newLevel, adjustment);
      }
    }

    // Validate bounds
    result.newLevel = Math.max(
      CONFIG.minAuthorityLevel, 
      Math.min(CONFIG.maxAuthorityLevel, result.newLevel)
    );

    // Create update record
    const update = {
      field: 'authority_level',
      previousValue: result.previousLevel,
      newValue: result.newLevel,
      reason: 'manual_override',
      overrideJustification: request.override_justification,
      overrideApprover: request.approved_by,
      effectiveDate: new Date().toISOString(),
      expiresAt: request.expires_at || null
    };
    
    result.updates.push(update);

    // Apply the update
    await applyUpdate(request.target_entity, request.target_id, update);

  } catch (error) {
    result.success = false;
    result.errors.push({
      code: 'MANUAL_OVERRIDE_ERROR',
      message: error.message
    });
  }

  return result;
}

/**
 * Process risk-based authority update
 */
async function processRiskBasedUpdate(request) {
  const result = { success: true, updates: [], errors: [], previousLevel: 0, newLevel: 0 };
  
  try {
    // Get current state
    const currentState = await getEntityState(request.target_entity, request.target_id);
    result.previousLevel = currentState.authority_level || getDefaultAuthority(request.target_entity);

    // Calculate risk adjustment
    const riskScore = request.risk_score || 50;
    const baseLevel = getDefaultAuthority(request.target_entity);
    
    // Calculate level based on risk
    let riskAdjustment = 0;
    
    if (riskScore <= 30) {
      riskAdjustment = 10; // Boost for low risk
    } else if (riskScore <= 50) {
      riskAdjustment = 0; // No adjustment
    } else if (riskScore <= 70) {
      riskAdjustment = -10; // Penalty for medium risk
    } else {
      riskAdjustment = -20; // Significant penalty for high risk
    }

    result.newLevel = Math.max(
      CONFIG.minAuthorityLevel,
      Math.min(CONFIG.maxAuthorityLevel, baseLevel + riskAdjustment)
    );

    // Apply any additional adjustments
    if (request.additional_factors) {
      for (const factor of request.additional_factors) {
        result.newLevel = applyAdjustment(result.newLevel, factor);
      }
    }

    // Create update record
    const update = {
      field: 'authority_level',
      previousValue: result.previousLevel,
      newValue: result.newLevel,
      reason: 'risk_based',
      riskScore: riskScore,
      riskAdjustment: riskAdjustment,
      effectiveDate: new Date().toISOString()
    };
    
    result.updates.push(update);

    // Apply the update
    await applyUpdate(request.target_entity, request.target_id, update);

  } catch (error) {
    result.success = false;
    result.errors.push({
      code: 'RISK_UPDATE_ERROR',
      message: error.message
    });
  }

  return result;
}

/**
 * Get entity state from storage
 */
async function getEntityState(entityType, entityId) {
  const stateKey = `${entityType}:${entityId}`;
  
  if (authorityState[stateKey]) {
    return authorityState[stateKey];
  }

  // Try to load from file
  const stateFile = path.join(CONFIG.permissionDir, 'authority-state.json');
  
  try {
    if (fs.existsSync(stateFile)) {
      const content = fs.readFileSync(stateFile, 'utf8');
      const states = JSON.parse(content);
      return states[stateKey] || {};
    }
  } catch (error) {
    console.error('Error loading entity state:', error.message);
  }

  return {};
}

/**
 * Apply update to entity state
 */
async function applyUpdate(entityType, entityId, update) {
  const stateKey = `${entityType}:${entityId}`;
  
  // Update in-memory state
  if (!authorityState[stateKey]) {
    authorityState[stateKey] = {};
  }
  
  authorityState[stateKey][update.field] = update.newValue;
  authorityState[stateKey].last_updated = new Date().toISOString();
  authorityState[stateKey].last_update_reason = update.reason;

  // Persist to file
  const stateFile = path.join(CONFIG.permissionDir, 'authority-state.json');
  
  try {
    let states = {};
    
    if (fs.existsSync(stateFile)) {
      const content = fs.readFileSync(stateFile, 'utf8');
      states = JSON.parse(content);
    }
    
    states[stateKey] = authorityState[stateKey];
    fs.writeFileSync(stateFile, JSON.stringify(states, null, 2));
    
  } catch (error) {
    console.error('Error persisting entity state:', error.message);
  }
}

/**
 * Get default authority level for entity type
 */
function getDefaultAuthority(entityType) {
  const defaults = {
    borrower: 30,
    officer: 60,
    admin: 80,
    system: 30
  };
  
  return defaults[entityType] || 30;
}

/**
 * Apply adjustment to authority level
 */
function applyAdjustment(currentLevel, adjustment) {
  switch (adjustment.type) {
    case 'add':
      return Math.min(CONFIG.maxAuthorityLevel, currentLevel + adjustment.value);
    case 'subtract':
      return Math.max(CONFIG.minAuthorityLevel, currentLevel - adjustment.value);
    case 'multiply':
      return Math.min(CONFIG.maxAuthorityLevel, currentLevel * adjustment.value);
    case 'set':
      return adjustment.value;
    default:
      return currentLevel;
  }
}

/**
 * Log authority update for audit
 */
async function logAuthorityUpdate(metadata) {
  const logEntry = {
    ...metadata,
    logId: generateLogId(),
    timestamp: new Date().toISOString()
  };

  // In production, this would write to audit log
  console.log('Authority Update Log:', JSON.stringify(logEntry, null, 2));
  
  return logEntry;
}

/**
 * Log audit finding
 */
async function logAuditFinding(findings, entityId) {
  for (const finding of findings) {
    console.log('Audit Finding:', JSON.stringify({
      entityId,
      finding: finding,
      timestamp: new Date().toISOString()
    }, null, 2));
  }
}

/**
 * Generate unique log ID
 */
function generateLogId() {
  return `LOG-${Date.now()}-${crypto.randomBytes(4).toString('hex')}`;
}

/**
 * Get current authority status for an entity
 */
async function getAuthorityStatus(entityType, entityId) {
  const state = await getEntityState(entityType, entityId);
  
  return {
    entityType,
    entityId,
    authorityLevel: state.authority_level || getDefaultAuthority(entityType),
    milestoneLevel: state.milestone_level || 0,
    lastUpdated: state.last_updated || null,
    lastUpdateReason: state.last_update_reason || null
  };
}

/**
 * Batch update authority status
 */
async function batchUpdateAuthorityStatus(updates) {
  const results = [];
  
  for (const update of updates) {
    const result = await updateAuthorityStatus(update);
    results.push({
      target_id: update.target_id,
      success: result.success,
      newLevel: result.metadata?.newLevel,
      errors: result.errors
    });
  }

  return {
    totalUpdates: updates.length,
    successfulUpdates: results.filter(r => r.success).length,
    failedUpdates: results.filter(r => !r.success).length,
    results: results
  };
}

// CLI Interface
if (require.main === module) {
  const args = process.argv.slice(2);
  
  if (args.length === 0) {
    console.error('Usage: node update-authority-status.js <status-update-request.json>');
    console.error('       or pipe JSON data to stdin');
    process.exit(1);
  }

  let updateRequest;
  
  if (args[0] === '-') {
    // Read from stdin
    const stdin = process.stdin;
    let data = '';
    
    stdin.on('data', chunk => { data += chunk; });
    stdin.on('end', async () => {
      try {
        updateRequest = JSON.parse(data);
        const result = await updateAuthorityStatus(updateRequest);
        console.log(JSON.stringify(result, null, 2));
      } catch (error) {
        console.error('Error:', error.message);
        process.exit(1);
      }
    });
  } else {
    // Read from file
    try {
      const filePath = path.resolve(args[0]);
      const content = fs.readFileSync(filePath, 'utf8');
      updateRequest = JSON.parse(content);
      
      updateAuthorityStatus(updateRequest).then(result => {
        console.log(JSON.stringify(result, null, 2));
      });
    } catch (error) {
      console.error('Error reading file:', error.message);
      process.exit(1);
    }
  }
}

module.exports = {
  updateAuthorityStatus,
  getAuthorityStatus,
  batchUpdateAuthorityStatus,
  CONFIG
};
