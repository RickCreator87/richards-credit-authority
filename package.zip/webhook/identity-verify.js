/**
 * Identity Verify Webhook
 * Verifies identity before any authority action
 * 
 * Usage: node webhook/identity-verify.js <identity-verification-request.json>
 * 
 * @module identity-verify
 */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

// Configuration
const CONFIG = {
  identityDataDir: path.join(__dirname, '..', 'data', 'identity'),
  documentStorageDir: path.join(__dirname, '..', 'data', 'documents'),
  verificationServices: {
    knowledgeBased: true,
    documentVerification: true,
    biometricVerification: false
  },
  minVerificationScore: 75,
  webhookSecret: process.env.WEBHOOK_SECRET || 'default-secret',
  cacheExpirationMs: 86400000, // 24 hours
  maxRetries: 3,
  retryDelayMs: 1000
};

// Identity cache
const identityCache = new Map();

/**
 * Main identity verification function
 */
async function verifyIdentity(verificationRequest) {
  const result = {
    verified: false,
    verification_score: 0,
    verification_level: 'none',
    findings: [],
    warnings: [],
    metadata: {}
  };

  try {
    // Validate verification request
    validateVerificationRequest(verificationRequest, result);
    
    if (!result.valid) {
      return result;
    }

    // Check cache
    const cacheKey = generateCacheKey(verificationRequest);
    const cachedResult = getCachedResult(cacheKey);
    
    if (cachedResult) {
      return { ...cachedResult, cached: true };
    }

    // Get current verification status
    const currentStatus = await getIdentityStatus(verificationRequest.identity_id);
    
    if (currentStatus.verified && 
        Date.now() - currentStatus.last_verified < CONFIG.cacheExpirationMs) {
      // Return cached result if still valid
      return {
        verified: true,
        verification_score: currentStatus.verification_score,
        verification_level: currentStatus.verification_level,
        cached: true,
        metadata: {
          identity_id: verificationRequest.identity_id,
          verification_timestamp: currentStatus.last_verified,
          cache_expires_at: new Date(currentStatus.last_verified + CONFIG.cacheExpirationMs).toISOString()
        }
      };
    }

    // Run verification checks
    let totalScore = 0;
    let maxPossibleScore = 0;

    // Knowledge-based verification
    if (CONFIG.verificationServices.knowledgeBased) {
      const kbResult = await runKnowledgeBasedVerification(verificationRequest);
      totalScore += kbResult.score;
      maxPossibleScore += kbResult.maxScore;
      
      if (!kbResult.passed) {
        result.findings.push(...kbResult.findings);
      }
    }

    // Document verification
    if (CONFIG.verificationServices.documentVerification) {
      const docResult = await runDocumentVerification(verificationRequest);
      totalScore += docResult.score;
      maxPossibleScore += docResult.maxScore;
      
      if (!docResult.passed) {
        result.findings.push(...docResult.findings);
      }
    }

    // Biometric verification (if requested and available)
    if (CONFIG.verificationServices.biometricVerification && 
        verificationRequest.include_biometric) {
      const bioResult = await runBiometricVerification(verificationRequest);
      totalScore += bioResult.score;
      maxPossibleScore += bioResult.maxScore;
      
      if (!bioResult.passed) {
        result.findings.push(...bioResult.findings);
      }
    }

    // Calculate final verification score
    result.verification_score = maxPossibleScore > 0 
      ? Math.round((totalScore / maxPossibleScore) * 100) 
      : 0;
    
    result.verified = result.verification_score >= CONFIG.minVerificationScore;
    
    // Determine verification level
    result.verification_level = determineVerificationLevel(result.verification_score);

    // Update identity status
    await updateIdentityStatus(
      verificationRequest.identity_id,
      result.verified,
      result.verification_score,
      result.verification_level
    );

    // Generate metadata
    result.metadata = {
      identity_id: verificationRequest.identity_id,
      verification_timestamp: new Date().toISOString(),
      cache_expires_at: new Date(Date.now() + CONFIG.cacheExpirationMs).toISOString(),
      methods_used: getMethodsUsed(verificationRequest),
      data_sources: ['internal_records', 'public_records'],
      verification_version: '1.0.0'
    };

    // Cache the result
    cacheResult(cacheKey, result);

  } catch (error) {
    result.findings.push({
      code: 'VERIFICATION_ERROR',
      message: error.message,
      severity: 'high'
    });
  }

  return result;
}

/**
 * Validate verification request
 */
function validateVerificationRequest(request, result) {
  result.valid = true;
  result.findings = [];
  result.warnings = [];

  const requiredFields = ['identity_id', 'verification_purpose'];
  
  for (const field of requiredFields) {
    if (!request[field]) {
      result.valid = false;
      result.findings.push({
        code: 'MISSING_FIELD',
        field: field,
        message: `Required field '${field}' is missing`,
        severity: 'high'
      });
    }
  }

  // Validate verification purpose
  const validPurposes = [
    'loan_application',
    'account_creation',
    'loan_disbursement',
    'payment_processing',
    'general_verification'
  ];
  
  if (request.verification_purpose && 
      !validPurposes.includes(request.verification_purpose)) {
    result.warnings.push({
      code: 'UNUSUAL_PURPOSE',
      message: `Verification purpose '${request.verification_purpose}' may require additional scrutiny`
    });
  }

  // Check for required identity data
  if (!request.identity_data && !request.document_references) {
    result.valid = false;
    result.findings.push({
      code: 'MISSING_IDENTITY_DATA',
      message: 'No identity data or document references provided',
      severity: 'high'
    });
  }
}

/**
 * Run knowledge-based verification
 */
async function runKnowledgeBasedVerification(request) {
  const result = {
    passed: true,
    score: 40,
    maxScore: 40,
    findings: []
  };

  try {
    // Load identity data
    const identityData = await loadIdentityData(request.identity_id);
    
    if (!identityData) {
      result.passed = false;
      result.score = 0;
      result.findings.push({
        code: 'IDENTITY_DATA_NOT_FOUND',
        message: 'Identity data not found in records',
        severity: 'high'
      });
      return result;
    }

    // Verify name match
    const nameMatch = compareNames(
      request.identity_data?.full_legal_name,
      identityData.full_legal_name
    );
    
    if (!nameMatch.exact && !nameMatch.similar) {
      result.passed = false;
      result.findings.push({
        code: 'NAME_MISMATCH',
        message: 'Provided name does not match records',
        severity: 'high',
        details: {
          provided: request.identity_data?.full_legal_name,
          recorded: identityData.full_legal_name
        }
      });
    } else if (nameMatch.similar) {
      result.score -= 5;
      result.warnings = result.warnings || [];
      result.warnings.push({
        code: 'NAME_PARTIAL_MATCH',
        message: 'Name partially matches records'
      });
    }

    // Verify date of birth
    const dobMatch = compareDates(
      request.identity_data?.date_of_birth,
      identityData.date_of_birth
    );
    
    if (!dobMatch) {
      result.passed = false;
      result.findings.push({
        code: 'DOB_MISMATCH',
        message: 'Date of birth does not match records',
        severity: 'high'
      });
    }

    // Verify address
    if (request.identity_data?.current_address) {
      const addressMatch = compareAddresses(
        request.identity_data.current_address,
        identityData.current_address
      );
      
      if (!addressMatch.match) {
        result.score -= 10;
        result.warnings = result.warnings || [];
        result.warnings.push({
          code: 'ADDRESS_MISMATCH',
          message: 'Current address differs from records'
        });
      }
    }

    // Verify phone
    if (request.identity_data?.phone_number && identityData.phone_number) {
      const phoneMatch = normalizePhone(request.identity_data.phone_number) === 
                         normalizePhone(identityData.phone_number);
      
      if (!phoneMatch) {
        result.score -= 5;
        result.warnings = result.warnings || [];
        result.warnings.push({
          code: 'PHONE_MISMATCH',
          message: 'Phone number differs from records'
        });
      }
    }

    // Verify email
    if (request.identity_data?.email_address && identityData.email_address) {
      const emailMatch = request.identity_data.email_address.toLowerCase() === 
                         identityData.email_address.toLowerCase();
      
      if (!emailMatch) {
        result.score -= 5;
        result.warnings = result.warnings || [];
        result.warnings.push({
          code: 'EMAIL_MISMATCH',
          message: 'Email address differs from records'
        });
      }
    }

    // Check for address changes
    if (identityData.address_history?.length > 1) {
      const recentMove = identityData.address_history.some(
        addr => Date.now() - new Date(addr.moved_in) < 90 * 24 * 60 * 60 * 1000
      );
      
      if (recentMove) {
        result.score -= 5;
        result.warnings.push({
          code: 'RECENT_MOVE',
          message: 'Address change within last 90 days'
        });
      }
    }

  } catch (error) {
    result.passed = false;
    result.findings.push({
      code: 'KB_VERIFICATION_ERROR',
      message: `Knowledge-based verification error: ${error.message}`,
      severity: 'medium'
    });
  }

  return result;
}

/**
 * Run document verification
 */
async function runDocumentVerification(request) {
  const result = {
    passed: true,
    score: 50,
    maxScore: 50,
    findings: []
  };

  try {
    // Check for document references
    if (!request.document_references || request.document_references.length === 0) {
      result.passed = false;
      result.findings.push({
        code: 'NO_DOCUMENTS',
        message: 'No documents provided for verification',
        severity: 'high'
      });
      return result;
    }

    // Verify each document
    for (const docRef of request.document_references) {
      const docResult = await verifyDocument(docRef);
      
      if (!docResult.valid) {
        result.passed = false;
        result.score -= docResult.score_penalty;
        result.findings.push({
          code: `DOCUMENT_INVALID_${docRef.type}`,
          message: `${docRef.type} document verification failed`,
          severity: docResult.severity || 'medium',
          details: docResult
        });
      } else {
        // Document is valid
        result.score += docResult.score_contribution || 10;
      }
    }

    // Ensure score doesn't exceed max
    result.score = Math.min(result.score, result.maxScore);

  } catch (error) {
    result.passed = false;
    result.findings.push({
      code: 'DOCUMENT_VERIFICATION_ERROR',
      message: `Document verification error: ${error.message}`,
      severity: 'medium'
    });
  }

  return result;
}

/**
 * Run biometric verification
 */
async function runBiometricVerification(request) {
  const result = {
    passed: true,
    score: 10,
    maxScore: 10,
    findings: []
  };

  // Check if biometric data is provided
  if (!request.biometric_data) {
    result.score = 0;
    result.warnings.push({
      code: 'NO_BIOMETRIC_DATA',
      message: 'No biometric data provided, skipping biometric verification'
    });
    return result;
  }

  try {
    // Verify biometric data
    const bioMatch = await compareBiometricData(
      request.biometric_data,
      request.identity_id
    );

    if (!bioMatch.match) {
      result.passed = false;
      result.score = 0;
      result.findings.push({
        code: 'BIOMETRIC_MISMATCH',
        message: 'Biometric data does not match records',
        severity: 'high',
        details: bioMatch
      });
    } else if (bioMatch.confidence < 0.95) {
      result.score = 5;
      result.warnings.push({
        code: 'LOW_BIOMETRIC_CONFIDENCE',
        message: 'Biometric match confidence below threshold'
      });
    }

  } catch (error) {
    result.warnings.push({
      code: 'BIOMETRIC_ERROR',
      message: `Biometric verification error: ${error.message}`
    });
  }

  return result;
}

/**
 * Verify a single document
 */
async function verifyDocument(docRef) {
  const result = {
    valid: false,
    score_penalty: 15,
    score_contribution: 0,
    severity: 'medium'
  };

  try {
    // Check document type
    const validTypes = ['passport', 'drivers_license', 'state_id', 'military_id'];
    
    if (!validTypes.includes(docRef.type)) {
      result.findings = result.findings || [];
      result.findings.push({
        code: 'UNKNOWN_DOCUMENT_TYPE',
        message: `Unknown document type: ${docRef.type}`
      });
      return result;
    }

    // Check document exists
    const docPath = path.join(
      CONFIG.documentStorageDir,
      docRef.storage_path || `${docRef.type}-${docRef.id}.json`
    );
    
    if (!fs.existsSync(docPath)) {
      result.valid = false;
      result.severity = 'high';
      return result;
    }

    // Load and validate document
    const content = fs.readFileSync(docPath, 'utf8');
    const document = JSON.parse(content);

    // Check expiration
    if (document.expiry_date) {
      const expiryDate = new Date(document.expiry_date);
      if (expiryDate < new Date()) {
        result.valid = false;
        result.severity = 'high';
        result.findings = result.findings || [];
        result.findings.push({
          code: 'DOCUMENT_EXPIRED',
          message: `${docRef.type} has expired`,
          details: { expiry_date: document.expiry_date }
        });
        return result;
      }

      // Check if expiring soon
      const daysUntilExpiry = (expiryDate - new Date()) / (24 * 60 * 60 * 1000);
      if (daysUntilExpiry < 90) {
        result.score_penalty = 5;
        result.findings = result.findings || [];
        result.findings.push({
          code: 'DOCUMENT_EXPIRING',
          message: `${docRef.type} expires soon`,
          details: { expires_in_days: Math.round(daysUntilExpiry) }
        });
      }
    }

    // Verify document is not revoked
    if (document.revoked) {
      result.valid = false;
      result.severity = 'critical';
      result.findings = result.findings || [];
      result.findings.push({
        code: 'DOCUMENT_REVOKED',
        message: `${docRef.type} has been revoked`
      });
      return result;
    }

    // Document is valid
    result.valid = true;
    result.score_contribution = 25;

  } catch (error) {
    result.valid = false;
    result.findings = result.findings || [];
    result.findings.push({
      code: 'DOCUMENT_VERIFICATION_FAILED',
      message: `Document verification failed: ${error.message}`
    });
  }

  return result;
}

/**
 * Compare biometric data
 */
async function compareBiometricData(biometricData, identityId) {
  // Simulate biometric comparison
  await new Promise(resolve => setTimeout(resolve, 100));
  
  // In production, this would use actual biometric comparison
  const match = Math.random() > 0.05;
  
  return {
    match: match,
    confidence: match ? 0.95 + Math.random() * 0.05 : 0.7 + Math.random() * 0.2,
    method: biometricData.type || 'face'
  };
}

/**
 * Load identity data
 */
async function loadIdentityData(identityId) {
  try {
    const identityPath = path.join(
      CONFIG.identityDataDir,
      `${identityId}.json`
    );
    
    if (fs.existsSync(identityPath)) {
      const content = fs.readFileSync(identityPath, 'utf8');
      return JSON.parse(content);
    }
  } catch (error) {
    console.error('Error loading identity data:', error.message);
  }
  
  return null;
}

/**
 * Get current identity status
 */
async function getIdentityStatus(identityId) {
  const cacheKey = `status:${identityId}`;
  
  if (identityCache.has(cacheKey)) {
    return identityCache.get(cacheKey);
  }
  
  return {
    verified: false,
    verification_score: 0,
    verification_level: 'none',
    last_verified: null
  };
}

/**
 * Update identity status
 */
async function updateIdentityStatus(identityId, verified, score, level) {
  const cacheKey = `status:${identityId}`;
  
  const status = {
    verified,
    verification_score: score,
    verification_level: level,
    last_verified: Date.now()
  };
  
  identityCache.set(cacheKey, status);
  
  // Persist to file
  try {
    const statusPath = path.join(
      CONFIG.identityDataDir,
      'verification-status.json'
    );
    
    let statuses = {};
    
    if (fs.existsSync(statusPath)) {
      const content = fs.readFileSync(statusPath, 'utf8');
      statuses = JSON.parse(content);
    }
    
    statuses[identityId] = status;
    fs.writeFileSync(statusPath, JSON.stringify(statuses, null, 2));
    
  } catch (error) {
    console.error('Error persisting identity status:', error.message);
  }
}

/**
 * Compare names
 */
function compareNames(provided, recorded) {
  if (!provided || !recorded) {
    return { exact: false, similar: false };
  }
  
  const normalizedProvided = provided.toLowerCase().trim();
  const normalizedRecorded = recorded.toLowerCase().trim();
  
  if (normalizedProvided === normalizedRecorded) {
    return { exact: true, similar: true };
  }
  
  // Check for similarity using Levenshtein distance
  const distance = levenshteinDistance(normalizedProvided, normalizedRecorded);
  const maxLength = Math.max(normalizedProvided.length, normalizedRecorded.length);
  const similarity = 1 - (distance / maxLength);
  
  return {
    exact: false,
    similar: similarity > 0.8
  };
}

/**
 * Compare dates
 */
function compareDates(provided, recorded) {
  if (!provided || !recorded) {
    return false;
  }
  
  const providedDate = new Date(provided);
  const recordedDate = new Date(recorded);
  
  return providedDate.toISOString().split('T')[0] === 
         recordedDate.toISOString().split('T')[0];
}

/**
 * Compare addresses
 */
function compareAddresses(provided, recorded) {
  if (!provided || !recorded) {
    return { match: false };
  }
  
  const providedNormalized = normalizeAddress(provided);
  const recordedNormalized = normalizeAddress(recorded);
  
  return {
    match: providedNormalized === recordedNormalized,
    similarity: calculateSimilarity(providedNormalized, recordedNormalized)
  };
}

/**
 * Normalize address
 */
function normalizeAddress(address) {
  return [
    address.street || '',
    address.city || '',
    address.state || '',
    address.zip || ''
  ].join(',').toLowerCase().trim();
}

/**
 * Normalize phone number
 */
function normalizePhone(phone) {
  return phone.replace(/[\s\-\(\)]/g, '');
}

/**
 * Calculate Levenshtein distance
 */
function levenshteinDistance(str1, str2) {
  const m = str1.length;
  const n = str2.length;
  
  const dp = Array(m + 1).fill(null).map(() => Array(n + 1).fill(0));
  
  for (let i = 0; i <= m; i++) dp[i][0] = i;
  for (let j = 0; j <= n; j++) dp[0][j] = j;
  
  for (let i = 1; i <= m; i++) {
    for (let j = 1; j <= n; j++) {
      if (str1[i - 1] === str2[j - 1]) {
        dp[i][j] = dp[i - 1][j - 1];
      } else {
        dp[i][j] = Math.min(
          dp[i - 1][j] + 1,
          dp[i][j - 1] + 1,
          dp[i - 1][j - 1] + 1
        );
      }
    }
  }
  
  return dp[m][n];
}

/**
 * Calculate similarity
 */
function calculateSimilarity(str1, str2) {
  const distance = levenshteinDistance(str1, str2);
  const maxLength = Math.max(str1.length, str2.length);
  return 1 - (distance / maxLength);
}

/**
 * Determine verification level
 */
function determineVerificationLevel(score) {
  if (score >= 95) return 'premium';
  if (score >= 85) return 'standard_plus';
  if (score >= 75) return 'standard';
  if (score >= 50) return 'limited';
  return 'none';
}

/**
 * Get methods used for verification
 */
function getMethodsUsed(request) {
  const methods = ['knowledge_based'];
  
  if (request.document_references?.length > 0) {
    methods.push('document_verification');
  }
  
  if (request.include_biometric) {
    methods.push('biometric');
  }
  
  return methods;
}

/**
 * Generate cache key
 */
function generateCacheKey(request) {
  const keyData = {
    identity_id: request.identity_id,
    verification_purpose: request.verification_purpose,
    document_refs: request.document_references?.length || 0,
    biometric: request.include_biometric || false
  };
  
  return crypto
    .createHash('md5')
    .update(JSON.stringify(keyData))
    .digest('hex');
}

/**
 * Get cached result
 */
function getCachedResult(cacheKey) {
  if (identityCache.has(cacheKey)) {
    const cached = identityCache.get(cacheKey);
    if (Date.now() - cached.timestamp < CONFIG.cacheExpirationMs) {
      return cached.data;
    }
  }
  return null;
}

/**
 * Cache result
 */
function cacheResult(cacheKey, result) {
  identityCache.set(cacheKey, {
    data: result,
    timestamp: Date.now()
  });
}

/**
 * Clear identity cache
 */
function clearCache() {
  identityCache.clear();
}

/**
 * Get cache statistics
 */
function getCacheStats() {
  const now = Date.now();
  let validEntries = 0;
  
  for (const [key, value] of identityCache) {
    if (now - value.timestamp < CONFIG.cacheExpirationMs) {
      validEntries++;
    }
  }
  
  return {
    totalEntries: identityCache.size,
    validEntries,
    maxAgeMs: CONFIG.cacheExpirationMs
  };
}

// CLI Interface
if (require.main === module) {
  const args = process.argv.slice(2);
  
  if (args.length === 0) {
    console.error('Usage: node identity-verify.js <identity-verification-request.json>');
    console.error('       or pipe JSON data to stdin');
    process.exit(1);
  }

  let verificationRequest;
  
  if (args[0] === '-') {
    // Read from stdin
    const stdin = process.stdin;
    let data = '';
    
    stdin.on('data', chunk => { data += chunk; });
    stdin.on('end', async () => {
      try {
        verificationRequest = JSON.parse(data);
        const result = await verifyIdentity(verificationRequest);
        console.log(JSON.stringify(result, null, 2));
      } catch (error) {
        console.error('Error:', error.message);
        process.exit(1);
      }
    });
  } else {
    // Read from file
    try {
      const filePath = path.resolve(args[0]);
      const content = fs.readFileSync(filePath, 'utf8');
      verificationRequest = JSON.parse(content);
      
      verifyIdentity(verificationRequest).then(result => {
        console.log(JSON.stringify(result, null, 2));
      });
    } catch (error) {
      console.error('Error reading file:', error.message);
      process.exit(1);
    }
  }
}

module.exports = {
  verifyIdentity,
  runKnowledgeBasedVerification,
  runDocumentVerification,
  runBiometricVerification,
  clearCache,
  getCacheStats,
  CONFIG
};
