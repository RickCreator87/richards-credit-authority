/**
 * Sync Ledger Webhook
 * Syncs loan data with richard-loaner-ledger repository
 * 
 * Usage: node webhook/sync-ledger.js <sync-request.json>
 * 
 * @module sync-ledger
 */

const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { exec } = require('child_process');
const { promisify } = require('util');

const execAsync = promisify(exec);

// Configuration
const CONFIG = {
  ledgerRepoUrl: 'https://github.com/RickCreator87/richard-loaner-ledger',
  repoPath: process.env.LEDGER_REPO_PATH || path.join(__dirname, '..', '..', 'richard-loaner-ledger'),
  syncToken: process.env.SYNC_TOKEN || '',
  maxRetries: 3,
  retryDelayMs: 5000,
  rateLimit: {
    maxRequestsPerHour: 100,
    burstLimit: 10
  },
  webhookSecret: process.env.WEBHOOK_SECRET || 'default-secret'
};

// Rate limiting state
const rateLimitState = {
  requests: [],
  maxRequests: CONFIG.rateLimit.maxRequestsPerHour
};

/**
 * Main sync function
 */
async function syncLedger(syncRequest) {
  const result = {
    success: false,
    syncedRecords: 0,
    failedRecords: 0,
    errors: [],
    metadata: {}
  };

  try {
    // Validate sync request
    validateSyncRequest(syncRequest, result);
    
    if (!result.success) {
      return result;
    }

    // Check rate limits
    if (!checkRateLimit()) {
      result.errors.push({
        code: 'RATE_LIMIT_EXCEEDED',
        message: 'Rate limit exceeded, please try again later'
      });
      return result;
    }

    // Authenticate and authorize
    const authResult = await authenticateRequest(syncRequest);
    if (!authResult.authorized) {
      result.errors.push({
        code: 'UNAUTHORIZED',
        message: authResult.message
      });
      return result;
    }

    // Perform the sync
    const syncResult = await performSync(syncRequest);
    
    result.success = syncResult.success;
    result.syncedRecords = syncResult.syncedCount;
    result.failedRecords = syncResult.failedCount;
    result.errors = result.errors.concat(syncResult.errors);
    result.metadata = {
      syncType: syncRequest.sync_type,
      direction: syncRequest.direction,
      timestamp: new Date().toISOString(),
      recordsProcessed: syncResult.processedCount,
      duration: syncResult.duration
    };

  } catch (error) {
    result.errors.push({
      code: 'SYNC_ERROR',
      message: error.message,
      stack: error.stack
    });
  }

  return result;
}

/**
 * Validate sync request
 */
function validateSyncRequest(request, result) {
  result.success = true;
  result.errors = [];
  result.syncedRecords = 0;
  result.failedRecords = 0;

  const requiredFields = ['sync_type', 'direction', 'records'];
  
  for (const field of requiredFields) {
    if (!request[field]) {
      result.success = false;
      result.errors.push({
        code: 'MISSING_FIELD',
        field: field,
        message: `Required field '${field}' is missing`
      });
    }
  }

  // Validate sync type
  const validSyncTypes = ['full', 'incremental', 'delta'];
  if (request.sync_type && !validSyncTypes.includes(request.sync_type)) {
    result.success = false;
    result.errors.push({
      code: 'INVALID_SYNC_TYPE',
      field: 'sync_type',
      message: `Sync type must be one of: ${validSyncTypes.join(', ')}`
    });
  }

  // Validate direction
  const validDirections = ['push', 'pull', 'bidirectional'];
  if (request.direction && !validDirections.includes(request.direction)) {
    result.success = false;
    result.errors.push({
      code: 'INVALID_DIRECTION',
      field: 'direction',
      message: `Sync direction must be one of: ${validDirections.join(', ')}`
    });
  }

  // Validate records
  if (request.records && !Array.isArray(request.records)) {
    result.success = false;
    result.errors.push({
      code: 'INVALID_RECORDS',
      field: 'records',
      message: 'Records must be an array'
    });
  }

  // Check record count limits
  if (request.records && request.records.length > CONFIG.rateLimit.burstLimit) {
    result.warnings = result.warnings || [];
    result.warnings.push({
      code: 'HIGH_VOLUME_SYNC',
      message: `Large sync of ${request.records.length} records may take time`
    });
  }
}

/**
 * Check rate limits
 */
function checkRateLimit() {
  const now = Date.now();
  const oneHourAgo = now - (60 * 60 * 1000);
  
  // Remove old entries
  rateLimitState.requests = rateLimitState.requests.filter(
    t => t > oneHourAgo
  );
  
  // Check if under limit
  if (rateLimitState.requests.length >= rateLimitState.maxRequests) {
    return false;
  }
  
  // Record this request
  rateLimitState.requests.push(now);
  return true;
}

/**
 * Authenticate incoming request
 */
async function authenticateRequest(request) {
  try {
    // Check for valid authentication token
    if (!request.auth_token && !CONFIG.syncToken) {
      return { authorized: false, message: 'Authentication token required' };
    }

    const token = request.auth_token || CONFIG.syncToken;
    
    // In production, validate token properly
    if (token.length < 8) {
      return { authorized: false, message: 'Invalid authentication token' };
    }

    // Verify webhook signature if present
    if (request.signature) {
      const payload = JSON.stringify({
        sync_type: request.sync_type,
        direction: request.direction,
        timestamp: request.timestamp
      });
      
      const expectedSignature = crypto
        .createHmac('sha256', CONFIG.webhookSecret)
        .update(payload)
        .digest('hex');
      
      if (request.signature !== expectedSignature) {
        return { authorized: false, message: 'Invalid webhook signature' };
      }
    }

    return { authorized: true, message: 'Authentication successful' };
  } catch (error) {
    return { authorized: false, message: error.message };
  }
}

/**
 * Perform the actual sync operation
 */
async function performSync(request) {
  const startTime = Date.now();
  let syncedCount = 0;
  let failedCount = 0;
  const errors = [];
  let processedCount = 0;

  try {
    // Determine sync strategy based on type
    switch (request.sync_type) {
      case 'full':
        const fullResult = await performFullSync(request);
        syncedCount = fullResult.synced;
        failedCount = fullResult.failed;
        errors.push(...fullResult.errors);
        processedCount = request.records?.length || 0;
        break;
        
      case 'incremental':
        const incrementalResult = await performIncrementalSync(request);
        syncedCount = incrementalResult.synced;
        failedCount = incrementalResult.failed;
        errors.push(...incrementalResult.errors);
        processedCount = request.records?.length || 0;
        break;
        
      case 'delta':
        const deltaResult = await performDeltaSync(request);
        syncedCount = deltaResult.synced;
        failedCount = deltaResult.failed;
        errors.push(...deltaResult.errors);
        processedCount = deltaResult.processed;
        break;
        
      default:
        throw new Error(`Unknown sync type: ${request.sync_type}`);
    }

    return {
      success: failedCount === 0,
      syncedCount,
      failedCount,
      errors,
      processedCount,
      duration: Date.now() - startTime
    };

  } catch (error) {
    return {
      success: false,
      syncedCount: 0,
      failedCount: request.records?.length || 0,
      errors: [{ code: 'SYNC_FAILED', message: error.message }],
      processedCount: 0,
      duration: Date.now() - startTime
    };
  }
}

/**
 * Perform full sync
 */
async function performFullSync(request) {
  const result = { synced: 0, failed: 0, errors: [] };
  
  if (!request.records || request.records.length === 0) {
    return result;
  }

  for (const record of request.records) {
    try {
      await syncRecord(record, request.direction);
      result.synced++;
    } catch (error) {
      result.failed++;
      result.errors.push({
        record_id: record.id,
        error: error.message
      });
    }
  }

  return result;
}

/**
 * Perform incremental sync
 */
async function performIncrementalSync(request) {
  const result = { synced: 0, failed: 0, errors: [] };
  
  if (!request.records || request.records.length === 0) {
    return result;
  }

  // Filter for records modified since last sync
  const lastSync = request.last_sync_timestamp || new Date(0);
  const incrementalRecords = request.records.filter(
    r => new Date(r.updated_at) > new Date(lastSync)
  );

  for (const record of incrementalRecords) {
    try {
      await syncRecord(record, request.direction);
      result.synced++;
    } catch (error) {
      result.failed++;
      result.errors.push({
        record_id: record.id,
        error: error.message
      });
    }
  }

  return result;
}

/**
 * Perform delta sync (changes only)
 */
async function performDeltaSync(request) {
  const result = { synced: 0, failed: 0, errors: [], processed: 0 };
  
  if (!request.records || request.records.length === 0) {
    return result;
  }

  for (const record of request.records) {
    result.processed++;
    
    // Determine operation based on record state
    try {
      const operation = determineDeltaOperation(record);
      
      switch (operation) {
        case 'create':
          await createRecord(record);
          result.synced++;
          break;
          
        case 'update':
          await updateRecord(record);
          result.synced++;
          break;
          
        case 'delete':
          await deleteRecord(record);
          result.synced++;
          break;
          
        case 'none':
          // No changes needed
          break;
      }
    } catch (error) {
      result.failed++;
      result.errors.push({
        record_id: record.id,
        operation: operation,
        error: error.message
      });
    }
  }

  return result;
}

/**
 * Determine delta operation for a record
 */
function determineDeltaOperation(record) {
  if (record._deleted) {
    return 'delete';
  }
  
  if (!record._existing) {
    return 'create';
  }
  
  if (record._changed && record._changed.length > 0) {
    return 'update';
  }
  
  return 'none';
}

/**
 * Sync a single record
 */
async function syncRecord(record, direction) {
  // Validate record structure
  validateRecordStructure(record);
  
  switch (direction) {
    case 'push':
      await pushRecord(record);
      break;
    case 'pull':
      await pullRecord(record);
      break;
    case 'bidirectional':
      await bidirectionalSync(record);
      break;
    default:
      throw new Error(`Invalid direction: ${direction}`);
  }
}

/**
 * Validate record structure
 */
function validateRecordStructure(record) {
  const requiredFields = ['id', 'type', 'data'];
  
  for (const field of requiredFields) {
    if (!record[field]) {
      throw new Error(`Record missing required field: ${field}`);
    }
  }

  // Validate record type
  const validTypes = ['loan', 'payment', 'borrower', 'account'];
  if (!validTypes.includes(record.type)) {
    throw new Error(`Invalid record type: ${record.type}`);
  }
}

/**
 * Push record to ledger
 */
async function pushRecord(record) {
  // Simulate push operation
  await simulateOperation('push', record);
  
  // In production, this would:
  // 1. Update the ledger repository
  // 2. Create a commit with the record
  // 3. Push changes to remote
  // 4. Verify sync completion
  
  return { success: true, recordId: record.id };
}

/**
 * Pull record from ledger
 */
async function pullRecord(record) {
  // Simulate pull operation
  await simulateOperation('pull', record);
  
  // In production, this would:
  // 1. Fetch latest from ledger repository
  // 2. Merge changes if needed
  // 3. Update local state
  
  return { success: true, recordId: record.id };
}

/**
 * Bidirectional sync
 */
async function bidirectionalSync(record) {
  // Simulate bidirectional sync
  await simulateOperation('bidirectional', record);
  
  // In production, this would:
  // 1. Fetch latest from both sources
  // 2. Detect conflicts
  // 3. Apply conflict resolution
  // 4. Push updates to both sources
  
  return { success: true, recordId: record.id };
}

/**
 * Create a new record
 */
async function createRecord(record) {
  await simulateOperation('create', record);
  return { success: true, recordId: record.id };
}

/**
 * Update an existing record
 */
async function updateRecord(record) {
  await simulateOperation('update', record);
  return { success: true, recordId: record.id };
}

/**
 * Delete a record
 */
async function deleteRecord(record) {
  await simulateOperation('delete', record);
  return { success: true, recordId: record.id };
}

/**
 * Simulate async operation with retry logic
 */
async function simulateOperation(operation, record) {
  let lastError;
  
  for (let attempt = 1; attempt <= CONFIG.maxRetries; attempt++) {
    try {
      // Simulate network delay
      await new Promise(resolve => 
        setTimeout(resolve, Math.random() * 100 + 50)
      );
      
      // Simulate occasional failures for testing
      if (Math.random() < 0.05) {
        throw new Error(`Simulated ${operation} failure`);
      }
      
      return;
    } catch (error) {
      lastError = error;
      
      if (attempt < CONFIG.maxRetries) {
        const delay = CONFIG.retryDelayMs * Math.pow(2, attempt - 1);
        await new Promise(resolve => setTimeout(resolve, delay));
      }
    }
  }
  
  throw lastError;
}

/**
 * Generate sync report
 */
function generateSyncReport(syncResult) {
  return {
    summary: {
      success: syncResult.success,
      totalRecords: syncResult.syncedRecords + syncResult.failedRecords,
      syncedRecords: syncResult.syncedRecords,
      failedRecords: syncResult.failedRecords,
      duration: syncResult.metadata.duration
    },
    errors: syncResult.errors.slice(0, 10), // Limit error details
    timestamp: new Date().toISOString()
  };
}

/**
 * Webhook handler for incoming sync requests
 */
async function handleWebhook(request, response) {
  const result = await syncLedger(request);
  
  // Generate and send response
  const responseData = {
    ...result,
    report: generateSyncReport(result)
  };
  
  return responseData;
}

// CLI Interface
if (require.main === module) {
  const args = process.argv.slice(2);
  
  if (args.length === 0) {
    console.error('Usage: node sync-ledger.js <sync-request.json>');
    console.error('       or pipe JSON data to stdin');
    process.exit(1);
  }

  let syncRequest;
  
  if (args[0] === '-') {
    // Read from stdin
    const stdin = process.stdin;
    let data = '';
    
    stdin.on('data', chunk => { data += chunk; });
    stdin.on('end', async () => {
      try {
        syncRequest = JSON.parse(data);
        const result = await syncLedger(syncRequest);
        console.log(JSON.stringify(result, null, 2));
      } catch (error) {
        console.error('Error:', error.message);
        process.exit(1);
      }
    });
  } else {
    // Read from file
    try {
      const filePath = path.resolve(args[0]);
      const content = fs.readFileSync(filePath, 'utf8');
      syncRequest = JSON.parse(content);
      
      syncLedger(syncRequest).then(result => {
        console.log(JSON.stringify(result, null, 2));
      });
    } catch (error) {
      console.error('Error reading file:', error.message);
      process.exit(1);
    }
  }
}

module.exports = {
  syncLedger,
  handleWebhook,
  CONFIG
};
