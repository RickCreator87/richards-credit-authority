/**
 * Tax Tests
 * Tests for federal and state tax rules
 * 
 * @module tax-tests
 */

const fs = require('fs');
const path = require('path');
const yaml = require('js-yaml');
const assert = require('assert');

// Configuration
const CONFIG = {
  governanceDir: path.join(__dirname, '..', 'governance'),
  permissionDir: path.join(__dirname, '..', 'permission'),
  taxDataDir: path.join(__dirname, '..', 'data', 'tax')
};

// Test utilities
function loadTaxFile(filename) {
  const filePath = path.join(CONFIG.taxDataDir, filename);
  if (!fs.existsSync(filePath)) {
    return null;
  }
  const content = fs.readFileSync(filePath, 'utf8');
  const ext = path.extname(filename).toLowerCase();
  
  if (ext === '.json') {
    return JSON.parse(content);
  } else if (ext === '.yaml' || ext === '.yml') {
    return yaml.load(content);
  }
  return null;
}

function loadValidationRules() {
  const filePath = path.join(CONFIG.permissionDir, 'validation-rules.yaml');
  if (!fs.existsSync(filePath)) {
    return null;
  }
  const content = fs.readFileSync(filePath, 'utf8');
  return yaml.load(content);
}

// Test Suite
describe('Tax Tests', function() {
  this.timeout(10000);
  
  describe('Tax Validation Rules', function() {
    let validationRules;
    
    before(function() {
      validationRules = loadValidationRules();
    });
    
    it('should have tax validation section', function() {
      assert(validationRules, 'Validation rules file should exist');
      assert(validationRules.tax_validation, 'Should have tax validation section');
    });
    
    it('should define federal tax requirements', function() {
      const federalTax = validationRules.tax_validation.federal_tax_requirements;
      
      assert(federalTax, 'Should have federal tax requirements');
      assert(Array.isArray(federalTax), 'Federal tax requirements should be array');
      
      // Check for common requirements
      const requiredRequirements = [
        'w2_verification',
        'tax_lien_check',
        'tax_refund_offset_check'
      ];
      
      for (const req of federalTax) {
        assert(req.requirement, 'Each requirement should have a name');
      }
    });
    
    it('should define state tax requirements', function() {
      const stateTax = validationRules.tax_validation.state_tax_requirements;
      
      assert(stateTax, 'Should have state tax requirements');
      assert(Array.isArray(stateTax), 'State tax requirements should be array');
    });
    
    it('should define withholding requirements', function() {
      const withholding = validationRules.tax_validation.withholding_requirements;
      
      assert(withholding, 'Should have withholding requirements');
      assert(Array.isArray(withholding), 'Withholding requirements should be array');
      
      for (const req of withholding) {
        assert(req.requirement, 'Each requirement should have a name');
        if (req.rate_range) {
          assert(
            req.rate_range.min >= 0 && req.rate_range.max <= 1,
            'Rate range should be between 0 and 1'
          );
        }
      }
    });
  });
  
  describe('Usury Limits', function() {
    let usuryLimits;
    
    before(function() {
      usuryLimits = loadTaxFile('usury-limits.json');
    });
    
    it('should exist or be defined in governance', function() {
      // If file doesn't exist, check governance folder
      if (!usuryLimits) {
        const riskControls = loadRiskControls();
        assert(
          riskControls?.risk_tiers,
          'Usury limits should be defined in risk controls'
        );
        return;
      }
      
      assert(usuryLimits, 'Usury limits file should exist');
    });
    
    it('should have federal max rate', function() {
      if (usuryLimits) {
        assert(
          usuryLimits.federal_max_rate !== undefined,
          'Should have federal max rate'
        );
        assert(
          usuryLimits.federal_max_rate > 0,
          'Federal max rate should be positive'
        );
      }
    });
    
    it('should define state-specific limits', function() {
      if (usuryLimits) {
        assert(
          usuryLimits.states,
          'Should have state-specific limits'
        );
        
        for (const [state, limit] of Object.entries(usuryLimits.states)) {
          assert(
            typeof limit === 'number' || limit.max_rate !== undefined,
            `State ${state} should have valid limit`
          );
        }
      }
    });
  });
  
  describe('Tax Calculations', function() {
    it('should calculate interest correctly', function() {
      const principal = 10000;
      const annualRate = 0.12;
      const termMonths = 36;
      
      const monthlyRate = annualRate / 12;
      const totalInterest = principal * monthlyRate * termMonths;
      
      assert.strictEqual(totalInterest, 3600, 'Interest calculation should be correct');
    });
    
    it('should calculate APR correctly', function() {
      const loanAmount = 10000;
      const totalInterest = 2000;
      const termYears = 3;
      
      const apr = (totalInterest / loanAmount) / termYears;
      
      assert.strictEqual(apr, 0.0667, 'APR calculation should be approximately correct');
    });
    
    it('should calculate loan-to-value ratio', function() {
      const loanAmount = 80000;
      const collateralValue = 100000;
      
      const ltv = loanAmount / collateralValue;
      
      assert.strictEqual(ltv, 0.8, 'LTV calculation should be correct');
    });
  });
  
  describe('Tax Compliance', function() {
    it('should validate federal tax compliance', function() {
      const borrower = {
        has_federal_lien: false,
        has_refund_offset: false,
        w2_verified: true,
        tax_returns_filed: true
      };
      
      const isCompliant = 
        !borrower.has_federal_lien &&
        !borrower.has_refund_offset &&
        borrower.w2_verified &&
        borrower.tax_returns_filed;
      
      assert.strictEqual(isCompliant, true, 'Borrower should be federally compliant');
    });
    
    it('should detect federal tax liens', function() {
      const borrowerWithLien = {
        has_federal_lien: true,
        lien_amount: 5000
      };
      
      const isCompliant = !borrowerWithLien.has_federal_lien;
      
      assert.strictEqual(isCompliant, false, 'Borrower with lien should not be compliant');
    });
    
    it('should validate state tax compliance', function() {
      const borrower = {
        state: 'CA',
        has_state_lien: false,
        state_tax_compliant: true
      };
      
      const isCompliant = 
        !borrower.has_state_lien && 
        borrower.state_tax_compliant;
      
      assert.strictEqual(isCompliant, true, 'Borrower should be state compliant');
    });
    
    it('should check withholding requirements', function() {
      const loanAmount = 25000;
      const requiredWithholdingRate = 0.10;
      
      const minWithholding = loanAmount * requiredWithholdingRate;
      
      assert.strictEqual(minWithholding, 2500, 'Minimum withholding should be calculated correctly');
    });
  });
  
  describe('Tax Document Requirements', function() {
    it('should require W-2 for employees', function() {
      const borrower = {
        employment_type: 'w2_employee',
        documents: ['W-2', 'Pay Stubs']
      };
      
      const hasW2 = borrower.documents.some(d => d === 'W-2');
      
      assert.strictEqual(hasW2, true, 'Employee should have W-2');
    });
    
    it('should require 1099 for contractors', function() {
      const borrower = {
        employment_type: 'contractor',
        documents: ['1099', 'Bank Statements']
      };
      
      const has1099 = borrower.documents.some(d => d === '1099');
      
      assert.strictEqual(has1099, true, 'Contractor should have 1099');
    });
    
    it('should require tax returns for self-employed', function() {
      const borrower = {
        employment_type: 'self_employed',
        documents: ['Tax Returns', 'Business Financials']
      };
      
      const hasTaxReturns = borrower.documents.some(d => d === 'Tax Returns');
      
      assert.strictEqual(hasTaxReturns, true, 'Self-employed should have tax returns');
    });
  });
  
  describe('Tax Validation Logic', function() {
    it('should pass validation with complete documents', function() {
      const validationResult = {
        w2_verified: true,
        tax_lien_check_passed: true,
        refund_offset_check_passed: true,
        state_compliance_verified: true,
        withholding_calculated: true
      };
      
      const isValid = 
        validationResult.w2_verified &&
        validationResult.tax_lien_check_passed &&
        validationResult.refund_offset_check_passed &&
        validationResult.state_compliance_verified &&
        validationResult.withholding_calculated;
      
      assert.strictEqual(isValid, true, 'Complete validation should pass');
    });
    
    it('should fail validation with missing W-2', function() {
      const validationResult = {
        w2_verified: false,
        tax_lien_check_passed: true,
        refund_offset_check_passed: true,
        state_compliance_verified: true,
        withholding_calculated: true
      };
      
      const isValid = validationResult.w2_verified;
      
      assert.strictEqual(isValid, false, 'Missing W-2 should fail validation');
    });
    
    it('should fail validation with tax lien', function() {
      const validationResult = {
        w2_verified: true,
        tax_lien_check_passed: false,
        refund_offset_check_passed: true,
        state_compliance_verified: true,
        withholding_calculated: true
      };
      
      const isValid = validationResult.tax_lien_check_passed;
      
      assert.strictEqual(isValid, false, 'Tax lien should fail validation');
    });
    
    it('should flag high-risk tax situations', function() {
      const borrower = {
        has_federal_lien: true,
        lien_amount: 50000,
        has_state_lien: true,
        state: 'CA',
        complex_tax_situation: true
      };
      
      const riskLevel = 
        (borrower.has_federal_lien ? 30 : 0) +
        (borrower.lien_amount > 10000 ? 20 : 0) +
        (borrower.has_state_lien ? 15 : 0) +
        (borrower.complex_tax_situation ? 25 : 0);
      
      assert.strictEqual(riskLevel, 90, 'High-risk tax situation should have high score');
    });
  });
  
  describe('State-Specific Rules', function() {
    it('should have different rules for different states', function() {
      const stateRules = {
        'CA': { require_withholding: true, withholding_rate: 0.072 },
        'NY': { require_withholding: true, withholding_rate: 0.0685 },
        'TX': { require_withholding: false, withholding_rate: 0 },
        'FL': { require_withholding: false, withholding_rate: 0 }
      };
      
      // California requires withholding
      assert.strictEqual(
        stateRules.CA.require_withholding, 
        true, 
        'California should require withholding'
      );
      
      // Texas does not require state withholding
      assert.strictEqual(
        stateRules.TX.require_withholding, 
        false, 
        'Texas should not require withholding'
      );
    });
    
    it('should have state-specific usury limits', function() {
      const usuryLimits = {
        'CA': 0.10,  // 10% max
        'NY': 0.16,  // 16% max
        'TX': 0.10,  // 10% max
        'FL': 0.18,  // 18% max (predatory lending limit)
        'default': 0.10
      };
      
      for (const [state, limit] of Object.entries(usuryLimits)) {
        assert(
          limit > 0 && limit <= 0.25,
          `${state} usury limit should be between 0% and 25%`
        );
      }
    });
  });
  
  describe('Tax Implications', function() {
    it('should calculate deductible interest', function() {
      const loan = {
        purpose: 'business',
        annual_interest: 1200,
        loan_amount: 10000
      };
      
      const isDeductible = loan.purpose === 'business';
      const deductibleAmount = isDeductible ? loan.annual_interest : 0;
      
      assert.strictEqual(isDeductible, true, 'Business loan interest should be deductible');
      assert.strictEqual(deductibleAmount, 1200, 'Deductible amount should be calculated correctly');
    });
    
    it('should identify taxable forgiveness', function() {
      const forgivenLoan = {
        original_amount: 25000,
        forgiven_amount: 25000,
        discharge_date: '2024-06-15'
      };
      
      const isTaxable = forgivenLoan.forgiven_amount > 0;
      
      assert.strictEqual(isTaxable, true, 'Forgiven loans may be taxable');
    });
    
    it('should track forms required', function() {
      const loan = {
        amount: 25000,
        purpose: 'business',
        requires_1098: true,
        requires_1099_c: false
      };
      
      const forms = [];
      if (loan.requires_1098) forms.push('1098');
      if (loan.requires_1099_c) forms.push('1099-C');
      
      assert.deepStrictEqual(forms, ['1098'], 'Should track required tax forms');
    });
  });
});

// Helper function
function loadRiskControls() {
  const filePath = path.join(CONFIG.governanceDir, 'risk-controls.yaml');
  if (!fs.existsSync(filePath)) {
    return null;
  }
  const content = fs.readFileSync(filePath, 'utf8');
  return yaml.load(content);
}

// Export for use in other test files
module.exports = {
  CONFIG,
  loadTaxFile,
  loadValidationRules
};
