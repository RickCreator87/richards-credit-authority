/**
 * Schema Validation Tests
 * 
 * Ensures all YAML and JSON files match their defined schemas:
 * - permission/*.yaml files validated against permission-schema.json
 * - governance/*.yaml files validated against governance-schema.json
 * - registry.json validated against registry.schema.json
 */

const fs = require('fs');
const path = require('path');
const Ajv = require('ajv');

// Initialize AJV for JSON Schema validation
const ajv = new Ajv({ allErrors: true, strict: false });

// Schema paths
const SCHEMAS = {
  permission: path.join(__dirname, '..', 'permission', 'permission-schema.json'),
  governance: path.join(__dirname, '..', 'governance', 'governance-schema.json'),
  registry: path.join(__dirname, '..', 'registry.schema.json')
};

// File directories to validate
const VALIDATION_TARGETS = {
  permission: {
    dir: path.join(__dirname, '..', 'permission'),
    schemaKey: 'permission',
    extensions: ['.yaml', '.yml']
  },
  governance: {
    dir: path.join(__dirname, '..', 'governance'),
    schemaKey: 'governance',
    extensions: ['.yaml', '.yml']
  },
  registry: {
    dir: path.join(__dirname, '..'),
    schemaKey: 'registry',
    extensions: ['.json']
  }
};

// YAML parser (simple implementation for validation tests)
const YAML = {
  parse: (str) => {
    const result = {};
    const lines = str.split('\n');
    let currentKey = null;
    let arrayBuffer = [];
    
    lines.forEach((line, index) => {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith('#')) return;
      
      const indent = line.search(/\S/);
      
      if (trimmed.startsWith('- ')) {
        const value = trimmed.substring(2).trim();
        if (value) {
          arrayBuffer.push(value);
        }
      } else if (trimmed.includes(':')) {
        // Save previous array if exists
        if (arrayBuffer.length > 0 && currentKey) {
          result[currentKey] = arrayBuffer;
          arrayBuffer = [];
        }
        
        const parts = trimmed.split(':');
        const key = parts[0].trim();
        const value = parts.slice(1).join(':').trim();
        
        if (value === '') {
          currentKey = key;
        } else {
          currentKey = null;
          // Try to parse numbers and booleans
          if (value === 'true') result[key] = true;
          else if (value === 'false') result[key] = false;
          else if (!isNaN(value)) result[key] = Number(value);
          else result[key] = value;
        }
      }
    });
    
    // Save any remaining array
    if (arrayBuffer.length > 0 && currentKey) {
      result[currentKey] = arrayBuffer;
    }
    
    return result;
  }
};

describe('Schema Validation Tests', () => {
  let schemas = {};
  let validateFunctions = {};

  // Load all schemas before tests
  beforeAll(() => {
    Object.keys(SCHEMAS).forEach(key => {
      const schemaPath = SCHEMAS[key];
      if (fs.existsSync(schemaPath)) {
        const schemaContent = fs.readFileSync(schemaPath, 'utf8');
        schemas[key] = JSON.parse(schemaContent);
        validateFunctions[key] = ajv.compile(schemas[key]);
      }
    });
  });

  describe('Schema File Availability', () => {
    test('should have permission-schema.json available', () => {
      expect(fs.existsSync(SCHEMAS.permission)).toBe(true);
      expect(schemas.permission).toBeDefined();
    });

    test('should have governance-schema.json available', () => {
      expect(fs.existsSync(SCHEMAS.governance)).toBe(true);
      expect(schemas.governance).toBeDefined();
    });

    test('should have registry.schema.json available', () => {
      expect(fs.existsSync(SCHEMAS.registry)).toBe(true);
      expect(schemas.registry).toBeDefined();
    });

    test('should have valid JSON in all schema files', () => {
      Object.keys(SCHEMAS).forEach(key => {
        const schemaPath = SCHEMAS[key];
        const content = fs.readFileSync(schemaPath, 'utf8');
        expect(() => JSON.parse(content)).not.toThrow();
      });
    });

    test('should have valid JSON Schema structure', () => {
      Object.keys(schemas).forEach(key => {
        const schema = schemas[key];
        expect(schema).toHaveProperty('$schema');
        expect(schema.$schema).toBe('http://json-schema.org/draft-07/schema#');
        expect(schema).toHaveProperty('type');
        expect(['object', 'array']).toContain(schema.type);
      });
    });
  });

  describe('Permission Files Validation', () => {
    const permissionFiles = [
      'permission-matrix.yaml',
      'allowed-actions.yaml',
      'restricted-actions.yaml',
      'cross-repo-permissions.yaml',
      'validation-rules.yaml'
    ];

    test('should validate permission-matrix.yaml against schema', () => {
      const filePath = path.join(VALIDATION_TARGETS.permission.dir, 'permission-matrix.yaml');
      expect(fs.existsSync(filePath)).toBe(true);
      
      const content = fs.readFileSync(filePath, 'utf8');
      const data = YAML.parse(content);
      
      const valid = validateFunctions.permission(data);
      if (!valid) {
        console.error('Permission matrix validation errors:', ajv.errors);
      }
      expect(valid).toBe(true);
    });

    test('should validate allowed-actions.yaml against schema', () => {
      const filePath = path.join(VALIDATION_TARGETS.permission.dir, 'allowed-actions.yaml');
      expect(fs.existsSync(filePath)).toBe(true);
      
      const content = fs.readFileSync(filePath, 'utf8');
      const data = YAML.parse(content);
      
      const valid = validateFunctions.permission(data);
      expect(valid).toBe(true);
    });

    test('should validate restricted-actions.yaml against schema', () => {
      const filePath = path.join(VALIDATION_TARGETS.permission.dir, 'restricted-actions.yaml');
      expect(fs.existsSync(filePath)).toBe(true);
      
      const content = fs.readFileSync(filePath, 'utf8');
      const data = YAML.parse(content);
      
      const valid = validateFunctions.permission(data);
      expect(valid).toBe(true);
    });

    test('should validate cross-repo-permissions.yaml against schema', () => {
      const filePath = path.join(VALIDATION_TARGETS.permission.dir, 'cross-repo-permissions.yaml');
      expect(fs.existsSync(filePath)).toBe(true);
      
      const content = fs.readFileSync(filePath, 'utf8');
      const data = YAML.parse(content);
      
      const valid = validateFunctions.permission(data);
      expect(valid).toBe(true);
    });

    test('should validate validation-rules.yaml against schema', () => {
      const filePath = path.join(VALIDATION_TARGETS.permission.dir, 'validation-rules.yaml');
      expect(fs.existsSync(filePath)).toBe(true);
      
      const content = fs.readFileSync(filePath, 'utf8');
      const data = YAML.parse(content);
      
      const valid = validateFunctions.permission(data);
      expect(valid).toBe(true);
    });

    test('should validate all permission files have required structure', () => {
      const permissionDir = VALIDATION_TARGETS.permission.dir;
      const files = fs.readdirSync(permissionDir)
        .filter(f => VALIDATION_TARGETS.permission.extensions.includes(path.extname(f)));
      
      files.forEach(file => {
        const filePath = path.join(permissionDir, file);
        const content = fs.readFileSync(filePath, 'utf8');
        const data = YAML.parse(content);
        
        // Basic structure validation
        expect(typeof data).toBe('object');
        expect(Object.keys(data).length).toBeGreaterThan(0);
      });
    });
  });

  describe('Governance Files Validation', () => {
    const governanceFiles = [
      'governance-model.md',
      'approval-workflow.yaml',
      'milestone-rules.yaml',
      'audit-rules.yaml',
      'risk-controls.yaml'
    ];

    test('should validate approval-workflow.yaml against schema', () => {
      const filePath = path.join(VALIDATION_TARGETS.governance.dir, 'approval-workflow.yaml');
      expect(fs.existsSync(filePath)).toBe(true);
      
      const content = fs.readFileSync(filePath, 'utf8');
      const data = YAML.parse(content);
      
      const valid = validateFunctions.governance(data);
      expect(valid).toBe(true);
    });

    test('should validate milestone-rules.yaml against schema', () => {
      const filePath = path.join(VALIDATION_TARGETS.governance.dir, 'milestone-rules.yaml');
      expect(fs.existsSync(filePath)).toBe(true);
      
      const content = fs.readFileSync(filePath, 'utf8');
      const data = YAML.parse(content);
      
      const valid = validateFunctions.governance(data);
      expect(valid).toBe(true);
    });

    test('should validate audit-rules.yaml against schema', () => {
      const filePath = path.join(VALIDATION_TARGETS.governance.dir, 'audit-rules.yaml');
      expect(fs.existsSync(filePath)).toBe(true);
      
      const content = fs.readFileSync(filePath, 'utf8');
      const data = YAML.parse(content);
      
      const valid = validateFunctions.governance(data);
      expect(valid).toBe(true);
    });

    test('should validate risk-controls.yaml against schema', () => {
      const filePath = path.join(VALIDATION_TARGETS.governance.dir, 'risk-controls.yaml');
      expect(fs.existsSync(filePath)).toBe(true);
      
      const content = fs.readFileSync(filePath, 'utf8');
      const data = YAML.parse(content);
      
      const valid = validateFunctions.governance(data);
      expect(valid).toBe(true);
    });

    test('should validate all governance YAML files have required structure', () => {
      const governanceDir = VALIDATION_TARGETS.governance.dir;
      const files = fs.readdirSync(governanceDir)
        .filter(f => VALIDATION_TARGETS.governance.extensions.includes(path.extname(f)));
      
      files.forEach(file => {
        const filePath = path.join(governanceDir, file);
        const content = fs.readFileSync(filePath, 'utf8');
        const data = YAML.parse(content);
        
        // Basic structure validation
        expect(typeof data).toBe('object');
        expect(Object.keys(data).length).toBeGreaterThan(0);
      });
    });
  });

  describe('Registry File Validation', () => {
    test('should validate registry.json exists', () => {
      const registryPath = path.join(VALIDATION_TARGETS.registry.dir, 'registry.json');
      expect(fs.existsSync(registryPath)).toBe(true);
    });

    test('should validate registry.json against schema', () => {
      const registryPath = path.join(VALIDATION_TARGETS.registry.dir, 'registry.json');
      const content = fs.readFileSync(registryPath, 'utf8');
      const data = JSON.parse(content);
      
      const valid = validateFunctions.registry(data);
      expect(valid).toBe(true);
    });

    test('should validate registry.json has required fields', () => {
      const registryPath = path.join(VALIDATION_TARGETS.registry.dir, 'registry.json');
      const content = fs.readFileSync(registryPath, 'utf8');
      const data = JSON.parse(content);
      
      expect(data).toHaveProperty('version');
      expect(data).toHaveProperty('lastUpdated');
      expect(data).toHaveProperty('authorities');
    });
  });

  describe('Schema Compliance Verification', () => {
    test('should validate permission schema has required properties', () => {
      const schema = schemas.permission;
      
      // Check for common required properties in permission schema
      expect(schema).toHaveProperty('properties');
      expect(schema.properties).toHaveProperty('actions');
      expect(schema.properties).toHaveProperty('roles');
    });

    test('should validate governance schema has required properties', () => {
      const schema = schemas.governance;
      
      expect(schema).toHaveProperty('properties');
      expect(schema.properties).toHaveProperty('workflows');
      expect(schema.properties).toHaveProperty('rules');
    });

    test('should validate registry schema has required properties', () => {
      const schema = schemas.registry;
      
      expect(schema).toHaveProperty('properties');
      expect(schema.properties).toHaveProperty('version');
      expect(schema.properties).toHaveProperty('authorities');
    });

    test('should validate all schemas define proper types', () => {
      Object.keys(schemas).forEach(key => {
        const schema = schemas[key];
        
        if (schema.properties) {
          Object.values(schema.properties).forEach(prop => {
            expect(prop).toHaveProperty('type');
            expect(['string', 'number', 'boolean', 'array', 'object']).toContain(prop.type);
          });
        }
        
        if (schema.items) {
          expect(schema.items).toHaveProperty('type');
        }
      });
    });
  });

  describe('File Consistency Checks', () => {
    test('should ensure permission files reference valid roles', () => {
      const permissionDir = VALIDATION_TARGETS.permission.dir;
      const matrixPath = path.join(permissionDir, 'permission-matrix.yaml');
      
      const matrixContent = fs.readFileSync(matrixPath, 'utf8');
      const matrix = YAML.parse(matrixContent);
      
      // Check that roles referenced in matrix are defined
      if (matrix.roles) {
        matrix.roles.forEach(role => {
          expect(typeof role).toBe('string');
          expect(role.length).toBeGreaterThan(0);
        });
      }
    });

    test('should ensure governance files reference valid authorities', () => {
      const governanceDir = VALIDATION_TARGETS.governance.dir;
      const workflowPath = path.join(governanceDir, 'approval-workflow.yaml');
      
      const workflowContent = fs.readFileSync(workflowPath, 'utf8');
      const workflow = YAML.parse(workflowContent);
      
      // Check that workflows have required steps
      if (workflow.workflows) {
        workflow.workflows.forEach(wf => {
          expect(wf).toHaveProperty('name');
          expect(wf).toHaveProperty('steps');
          expect(Array.isArray(wf.steps)).toBe(true);
          expect(wf.steps.length).toBeGreaterThan(0);
        });
      }
    });

    test('should ensure cross-repo permissions are consistent', () => {
      const crossRepoPath = path.join(VALIDATION_TARGETS.permission.dir, 'cross-repo-permissions.yaml');
      const crossRepoContent = fs.readFileSync(crossRepoPath, 'utf8');
      const crossRepo = YAML.parse(crossRepoContent);
      
      if (crossRepo.repositories) {
        crossRepo.repositories.forEach(repo => {
          expect(repo).toHaveProperty('name');
          expect(repo).toHaveProperty('actions');
          expect(Array.isArray(repo.actions)).toBe(true);
          expect(repo.name.length).toBeGreaterThan(0);
        });
      }
    });

    test('should ensure audit rules align with governance model', () => {
      const auditPath = path.join(VALIDATION_TARGETS.governance.dir, 'audit-rules.yaml');
      const auditContent = fs.readFileSync(auditPath, 'utf8');
      const audit = YAML.parse(auditContent);
      
      if (audit.rules) {
        audit.rules.forEach(rule => {
          expect(rule).toHaveProperty('event');
          expect(rule).toHaveProperty('logging');
          expect(typeof rule.logging).toBe('boolean');
        });
      }
    });
  });

  describe('Validation Scripts Verification', () => {
    test('should validate permission script exists and works', () => {
      const scriptPath = path.join(__dirname, '..', 'scripts', 'validate-permissions.js');
      expect(fs.existsSync(scriptPath)).toBe(true);
      
      const scriptModule = require(scriptPath);
      expect(typeof scriptModule.validatePermissions).toBe('function');
    });

    test('should validate governance script exists and works', () => {
      const scriptPath = path.join(__dirname, '..', 'scripts', 'validate-governance.js');
      expect(fs.existsSync(scriptPath)).toBe(true);
      
      const scriptModule = require(scriptPath);
      expect(typeof scriptModule.validateGovernance).toBe('function');
    });

    test('should validate validation scripts return proper results', () => {
      const validatePermsScript = path.join(__dirname, '..', 'scripts', 'validate-permissions.js');
      const validateGovScript = path.join(__dirname, '..', 'scripts', 'validate-governance.js');
      
      const permsModule = require(validatePermsScript);
      const govModule = require(validateGovScript);
      
      // Test that functions return expected structure
      expect(permsModule.validatePermissions).toBeInstanceOf(Function);
      expect(govModule.validateGovernance).toBeInstanceOf(Function);
    });
  });

  describe('Error Handling in Validation', () => {
    test('should handle invalid YAML gracefully', () => {
      const invalidYaml = `
        invalid:
          - line
          broken
        structure:
          - incomplete
      `;
      
      expect(() => YAML.parse(invalidYaml)).not.toThrow();
      const result = YAML.parse(invalidYaml);
      expect(typeof result).toBe('object');
    });

    test('should handle invalid JSON gracefully', () => {
      const invalidJson = '{ invalid json }';
      
      expect(() => JSON.parse(invalidJson)).toThrow();
    });

    test('should report schema validation errors correctly', () => {
      const schema = {
        type: 'object',
        properties: {
          name: { type: 'string' },
          age: { type: 'number' }
        },
        required: ['name']
      };
      
      const validate = ajv.compile(schema);
      const invalidData = { age: 'not a number' };
      
      const valid = validate(invalidData);
      expect(valid).toBe(false);
      expect(validate.errors).toBeDefined();
      expect(Array.isArray(validate.errors)).toBe(true);
    });

    test('should validate required fields in permission files', () => {
      const schema = {
        type: 'object',
        properties: {
          actions: { type: 'array' },
          roles: { type: 'array' }
        },
        required: ['actions']
      };
      
      const validate = ajv.compile(schema);
      const validData = { actions: ['read', 'write'] };
      const invalidData = { roles: ['admin'] };
      
      expect(validate(validData)).toBe(true);
      expect(validate(invalidData)).toBe(false);
    });
  });
});
