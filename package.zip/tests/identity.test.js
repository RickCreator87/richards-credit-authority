/**
 * Identity Tests
 * Tests for identity file validity
 * 
 * @module identity-tests
 */

const fs = require('fs');
const path = require('path');
const assert = require('assert');

// Configuration
const CONFIG = {
  identityDataDir: path.join(__dirname, '..', 'data', 'identity'),
  documentStorageDir: path.join(__dirname, '..', 'data', 'documents')
};

// Test utilities
function getIdentityFilePath(identityId) {
  return path.join(CONFIG.identityDataDir, `${identityId}.json`);
}

function loadIdentityFile(identityId) {
  const filePath = getIdentityFilePath(identityId);
  if (!fs.existsSync(filePath)) {
    return null;
  }
  const content = fs.readFileSync(filePath, 'utf8');
  return JSON.parse(content);
}

function createTestIdentity(overrides = {}) {
  return {
    identity_id: 'test-identity-001',
    full_legal_name: 'John Doe',
    date_of_birth: '1990-01-15',
    social_security_number: '***-**-1234',
    current_address: {
      street: '123 Test Street',
      city: 'Test City',
      state: 'TS',
      zip: '12345'
    },
    email_address: 'john.doe@test.com',
    phone_number: '+1-555-123-4567',
    identity_verified: true,
    verification_date: '2024-01-15T10:00:00Z',
    documents: [
      {
        type: 'drivers_license',
        id: 'DL-001',
        state: 'TS',
        expiry_date: '2028-01-15',
        verified: true
      }
    ],
    address_history: [],
    created_at: '2024-01-01T00:00:00Z',
    updated_at: '2024-01-15T10:00:00Z',
    ...overrides
  };
}

// Test Suite
describe('Identity Tests', function() {
  this.timeout(10000);
  
  beforeEach(function() {
    // Ensure test directories exist
    if (!fs.existsSync(CONFIG.identityDataDir)) {
      fs.mkdirSync(CONFIG.identityDataDir, { recursive: true });
    }
  });
  
  afterEach(function() {
    // Clean up test files
    const testFile = getIdentityFilePath('test-identity-001');
    if (fs.existsSync(testFile)) {
      fs.unlinkSync(testFile);
    }
  });
  
  describe('Identity File Structure', function() {
    it('should create valid identity file', function() {
      const identity = createTestIdentity();
      
      // Save to file
      const filePath = getIdentityFilePath(identity.identity_id);
      fs.writeFileSync(filePath, JSON.stringify(identity, null, 2));
      
      // Verify file exists and can be loaded
      assert(fs.existsSync(filePath), 'Identity file should exist');
      
      const loaded = loadIdentityFile(identity.identity_id);
      assert(loaded, 'Identity file should be loadable');
      assert.strictEqual(loaded.identity_id, identity.identity_id);
    });
    
    it('should have all required fields', function() {
      const identity = createTestIdentity();
      
      const requiredFields = [
        'identity_id',
        'full_legal_name',
        'date_of_birth',
        'current_address',
        'email_address',
        'phone_number'
      ];
      
      for (const field of requiredFields) {
        assert(identity[field], `Identity should have ${field}`);
      }
    });
    
    it('should validate address structure', function() {
      const identity = createTestIdentity();
      
      const address = identity.current_address;
      assert(address, 'Should have current address');
      assert(address.street, 'Address should have street');
      assert(address.city, 'Address should have city');
      assert(address.state, 'Address should have state');
      assert(address.zip, 'Address should have zip');
    });
  });
  
  describe('Identity Verification', function() {
    it('should track verification status', function() {
      const identity = createTestIdentity({
        identity_verified: true,
        verification_date: '2024-01-15T10:00:00Z'
      });
      
      assert.strictEqual(identity.identity_verified, true);
      assert(identity.verification_date, 'Should have verification date');
    });
    
    it('should track verification methods', function() {
      const identity = createTestIdentity({
        verification_methods: [
          {
            method: 'knowledge_based',
            passed: true,
            score: 95
          },
          {
            method: 'document_verification',
            passed: true,
            document_type: 'drivers_license'
          }
        ]
      });
      
      assert(Array.isArray(identity.verification_methods));
      assert.strictEqual(identity.verification_methods.length, 2);
    });
    
    it('should validate identity score', function() {
      const identity = createTestIdentity({
        identity_score: 85
      });
      
      assert(identity.identity_score >= 0 && identity.identity_score <= 100);
    });
  });
  
  describe('Document Management', function() {
    it('should have document references', function() {
      const identity = createTestIdentity();
      
      assert(Array.isArray(identity.documents));
      assert(identity.documents.length > 0, 'Should have at least one document');
    });
    
    it('should validate document structure', function() {
      const identity = createTestIdentity();
      const document = identity.documents[0];
      
      const requiredDocFields = ['type', 'id', 'state', 'expiry_date', 'verified'];
      
      for (const field of requiredDocFields) {
        assert(document[field], `Document should have ${field}`);
      }
    });
    
    it('should track document expiry', function() {
      const identity = createTestIdentity({
        documents: [
          {
            type: 'passport',
            id: 'P-001',
            country: 'US',
            expiry_date: '2030-06-15',
            verified: true
          }
        ]
      });
      
      const document = identity.documents[0];
      const expiryDate = new Date(document.expiry_date);
      const now = new Date();
      
      assert(expiryDate > now, 'Document should not be expired');
    });
  });
  
  describe('Address History', function() {
    it('should track address history', function() {
      const identity = createTestIdentity({
        address_history: [
          {
            street: '456 Old Street',
            city: 'Old City',
            state: 'OS',
            zip: '54321',
            moved_in: '2020-01-01',
            moved_out: '2023-06-30'
          },
          {
            ...identity.current_address,
            moved_in: '2023-07-01'
          }
        ]
      });
      
      assert(Array.isArray(identity.address_history));
      assert.strictEqual(identity.address_history.length, 2);
    });
    
    it('should validate address history dates', function() {
      const identity = createTestIdentity({
        address_history: [
          {
            street: '456 Old Street',
            city: 'Old City',
            state: 'OS',
            zip: '54321',
            moved_in: '2020-01-01',
            moved_out: '2023-06-30'
          }
        ]
      });
      
      const history = identity.address_history[0];
      const movedIn = new Date(history.moved_in);
      const movedOut = new Date(history.moved_out);
      
      assert(movedOut > movedIn, 'Move out date should be after move in date');
    });
  });
  
  describe('Identity Validation Rules', function() {
    it('should validate email format', function() {
      const validEmails = [
        'test@example.com',
        'john.doe@company.org',
        'user+tag@domain.co.uk'
      ];
      
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      
      for (const email of validEmails) {
        assert(emailRegex.test(email), `${email} should be valid`);
      }
    });
    
    it('should validate phone format', function() {
      const validPhones = [
        '+1-555-123-4567',
        '(555) 123-4567',
        '5551234567'
      ];
      
      const phoneRegex = /^\+?[1-9]\d{1,14}$/;
      
      for (const phone of validPhones) {
        const normalized = phone.replace(/[\s\-\(\)]/g, '');
        assert(phoneRegex.test(normalized), `${phone} should be valid`);
      }
    });
    
    it('should validate date of birth', function() {
      const dob = '1990-01-15';
      const dobDate = new Date(dob);
      const age = (new Date() - dobDate) / (365.25 * 24 * 60 * 60 * 1000);
      
      assert(age > 18, 'Person should be at least 18 years old');
      assert(age < 120, 'Date of birth should be reasonable');
    });
  });
  
  describe('Identity File Operations', function() {
    it('should update identity file', function() {
      const identity = createTestIdentity();
      const filePath = getIdentityFilePath(identity.identity_id);
      
      // Create initial file
      fs.writeFileSync(filePath, JSON.stringify(identity, null, 2));
      
      // Update
      identity.email_address = 'new.email@test.com';
      identity.updated_at = new Date().toISOString();
      fs.writeFileSync(filePath, JSON.stringify(identity, null, 2));
      
      // Verify update
      const loaded = loadIdentityFile(identity.identity_id);
      assert.strictEqual(loaded.email_address, 'new.email@test.com');
    });
    
    it('should handle missing identity file', function() {
      const loaded = loadIdentityFile('non-existent-id');
      assert.strictEqual(loaded, null, 'Missing file should return null');
    });
    
    it('should validate JSON structure on load', function() {
      const identity = createTestIdentity();
      const filePath = getIdentityFilePath(identity.identity_id);
      
      // Write invalid JSON
      fs.writeFileSync(filePath, '{ invalid json }');
      
      let error = null;
      try {
        loadIdentityFile(identity.identity_id);
      } catch (e) {
        error = e;
      }
      
      assert(error, 'Should throw error for invalid JSON');
    });
  });
});

// Export for use in other test files
module.exports = {
  CONFIG,
  getIdentityFilePath,
  loadIdentityFile,
  createTestIdentity
};
