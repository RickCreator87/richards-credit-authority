/**
 * Workflow Tests
 * Tests for approval workflows
 * 
 * @module workflow-tests
 */

const fs = require('fs');
const path = require('path');
const yaml = require('js-yaml');
const assert = require('assert');

// Configuration
const CONFIG = {
  governanceDir: path.join(__dirname, '..', 'governance')
};

// Test utilities
function loadGovernanceFile(filename) {
  const filePath = path.join(CONFIG.governanceDir, filename);
  if (!fs.existsSync(filePath)) {
    return null;
  }
  const content = fs.readFileSync(filePath, 'utf8');
  const ext = path.extname(filename).toLowerCase();
  
  if (ext === '.json') {
    return JSON.parse(content);
  } else if (ext === '.yaml' || ext === '.yml') {
    return yaml.load(content);
  }
  return null;
}

// Mock loan request for testing
function createMockLoanRequest(overrides = {}) {
  return {
    loan_id: 'LOAN-001',
    borrower_id: 'BORROWER-001',
    loan_amount: 25000,
    loan_purpose: 'debt_consolidation',
    interest_rate: 0.12,
    loan_term_months: 36,
    repayment_frequency: 'monthly',
    borrower_credit_score: 720,
    debt_to_income_ratio: 0.35,
    collateral_required: false,
    ...overrides
  };
}

// Workflow state machine simulator
class WorkflowSimulator {
  constructor(workflow) {
    this.workflow = workflow;
    this.currentState = workflow.initial_state;
    this.history = [this.currentState];
  }
  
  canTransition(event) {
    const state = this.workflow.states.find(s => s.state === this.currentState);
    if (!state || !state.transitions) return false;
    
    return state.transitions.some(t => t.event === event);
  }
  
  transition(event) {
    if (!this.canTransition(event)) {
      throw new Error(`Cannot transition from ${this.currentState} via ${event}`);
    }
    
    const state = this.workflow.states.find(s => s.state === this.currentState);
    const transition = state.transitions.find(t => t.event === event);
    
    this.currentState = transition.target;
    this.history.push(this.currentState);
    
    return this.currentState;
  }
  
  getState() {
    return this.currentState;
  }
  
  getHistory() {
    return this.history;
  }
}

// Test Suite
describe('Workflow Tests', function() {
  this.timeout(10000);
  
  let approvalWorkflow;
  
  before(function() {
    approvalWorkflow = loadGovernanceFile('approval-workflow.yaml');
  });
  
  describe('Loan Request Workflow', function() {
    let loanWorkflow;
    
    before(function() {
      loanWorkflow = approvalWorkflow?.workflows?.loan_request;
    });
    
    it('should exist with valid structure', function() {
      assert(loanWorkflow, 'Loan request workflow should exist');
      assert(loanWorkflow.initial_state, 'Should have initial state');
      assert(loanWorkflow.states, 'Should have states');
    });
    
    it('should simulate from draft to approved', function() {
      const simulator = new WorkflowSimulator(loanWorkflow);
      
      // Initial state should be draft
      assert.strictEqual(simulator.getState(), 'draft');
      
      // Submit loan
      simulator.transition('submit');
      assert.strictEqual(simulator.getState(), 'submitted');
      
      // Pass validation
      simulator.transition('validation_pass');
      assert.strictEqual(simulator.getState(), 'in_review');
      
      // Recommend approval
      simulator.transition('recommend_approval');
      assert.strictEqual(simulator.getState(), 'pending_approval');
      
      // Final approval
      simulator.transition('approve');
      assert.strictEqual(simulator.getState(), 'approved');
      
      // Verify history
      const history = simulator.getHistory();
      assert.deepStrictEqual(history, ['draft', 'submitted', 'in_review', 'pending_approval', 'approved']);
    });
    
    it('should simulate draft to denied', function() {
      const simulator = new WorkflowSimulator(loanWorkflow);
      
      // Submit and fail validation
      simulator.transition('submit');
      simulator.transition('validation_fail');
      assert.strictEqual(simulator.getState(), 'draft');
      
      // Try again and get denied
      simulator.transition('submit');
      simulator.transition('validation_pass');
      simulator.transition('recommend_deny');
      assert.strictEqual(simulator.getState(), 'denied');
    });
    
    it('should handle enhanced review path', function() {
      const simulator = new WorkflowSimulator(loanWorkflow);
      
      // Go to in review
      simulator.transition('submit');
      simulator.transition('validation_pass');
      
      // Flag for enhanced review (high risk)
      simulator.transition('flag_for_enhanced_review');
      assert.strictEqual(simulator.getState(), 'enhanced_review');
      
      // Approve with conditions
      simulator.transition('approve_with_conditions');
      assert.strictEqual(simulator.getState(), 'pending_approval');
    });
    
    it('should handle withdrawn state', function() {
      const simulator = new WorkflowSimulator(loanWorkflow);
      
      simulator.transition('submit');
      simulator.transition('validation_pass');
      simulator.transition('withdraw');
      
      assert.strictEqual(simulator.getState(), 'withdrawn');
      assert(simulator.getHistory().includes('withdrawn'));
    });
    
    it('should transition to active after disbursement', function() {
      const simulator = new WorkflowSimulator(loanWorkflow);
      
      // Go to approved
      simulator.transition('submit');
      simulator.transition('validation_pass');
      simulator.transition('recommend_approval');
      simulator.transition('approve');
      
      // Disburse funds
      simulator.transition('disburse');
      assert.strictEqual(simulator.getState(), 'active');
    });
  });
  
  describe('Disbursement Workflow', function() {
    let disbursementWorkflow;
    
    before(function() {
      disbursementWorkflow = approvalWorkflow?.workflows?.disbursement;
    });
    
    it('should exist with valid structure', function() {
      assert(disbursementWorkflow, 'Disbursement workflow should exist');
    });
    
    it('should simulate successful disbursement', function() {
      const simulator = new WorkflowSimulator(disbursementWorkflow);
      
      assert.strictEqual(simulator.getState(), 'pending_disbursement');
      
      simulator.transition('proceed');
      assert.strictEqual(simulator.getState(), 'processing');
      
      simulator.transition('confirmation_received');
      assert.strictEqual(simulator.getState(), 'disbursed');
    });
    
    it('should handle disbursement failure', function() {
      const simulator = new WorkflowSimulator(disbursementWorkflow);
      
      simulator.transition('proceed');
      simulator.transition('transfer_failed');
      assert.strictEqual(simulator.getState(), 'failed');
      
      // Can retry
      simulator.transition('retry');
      assert.strictEqual(simulator.getState(), 'pending_disbursement');
    });
    
    it('should allow cancellation', function() {
      const simulator = new WorkflowSimulator(disbursementWorkflow);
      
      simulator.transition('proceed');
      simulator.transition('cancel');
      assert.strictEqual(simulator.getState(), 'cancelled');
    });
  });
  
  describe('Amendment Workflow', function() {
    let amendmentWorkflow;
    
    before(function() {
      amendmentWorkflow = approvalWorkflow?.workflows?.amendment;
    });
    
    it('should exist with valid structure', function() {
      assert(amendmentWorkflow, 'Amendment workflow should exist');
    });
    
    it('should simulate amendment process', function() {
      const simulator = new WorkflowSimulator(amendmentWorkflow);
      
      assert.strictEqual(simulator.getState(), 'amendment_requested');
      
      simulator.transition('submit_for_review');
      assert.strictEqual(simulator.getState(), 'amendment_review');
      
      simulator.transition('recommend_approval');
      assert.strictEqual(simulator.getState(), 'amendment_pending_approval');
      
      simulator.transition('approve');
      assert.strictEqual(simulator.getState(), 'amendment_approved');
    });
  });
  
  describe('Tax Event Workflow', function() {
    let taxEventWorkflow;
    
    before(function() {
      taxEventWorkflow = approvalWorkflow?.workflows?.tax_event;
    });
    
    it('should exist with valid structure', function() {
      assert(taxEventWorkflow, 'Tax event workflow should exist');
    });
    
    it('should simulate successful tax validation', function() {
      const simulator = new WorkflowSimulator(taxEventWorkflow);
      
      assert.strictEqual(simulator.getState(), 'tax_validation_pending');
      
      simulator.transition('validation_pass');
      assert.strictEqual(simulator.getState(), 'tax_validated');
    });
    
    it('should handle federal tax issues', function() {
      const simulator = new WorkflowSimulator(taxEventWorkflow);
      
      simulator.transition('federal_issue');
      assert.strictEqual(simulator.getState(), 'tax_compliance_issue');
    });
    
    it('should handle state tax issues', function() {
      const simulator = new WorkflowSimulator(taxEventWorkflow);
      
      simulator.transition('state_issue');
      assert.strictEqual(simulator.getState(), 'tax_compliance_issue');
    });
    
    it('should allow issue resolution', function() {
      const simulator = new WorkflowSimulator(taxEventWorkflow);
      
      simulator.transition('federal_issue');
      simulator.transition('issue_resolved');
      assert.strictEqual(simulator.getState(), 'tax_validation_pending');
    });
    
    it('should allow waiver', function() {
      const simulator = new WorkflowSimulator(taxEventWorkflow);
      
      simulator.transition('federal_issue');
      simulator.transition('waiver_granted');
      assert.strictEqual(simulator.getState(), 'tax_validated');
    });
  });
  
  describe('Approval Path Determination', function() {
    it('should determine standard loan path', function() {
      const loanRequest = createMockLoanRequest({ loan_amount: 5000 });
      
      let path;
      if (loanRequest.loan_amount <= 10000) {
        path = 'standard_loan';
      } else if (loanRequest.loan_amount <= 50000) {
        path = 'moderate_loan';
      } else {
        path = 'large_loan';
      }
      
      assert.strictEqual(path, 'standard_loan');
    });
    
    it('should determine moderate loan path', function() {
      const loanRequest = createMockLoanRequest({ loan_amount: 25000 });
      
      let path;
      if (loanRequest.loan_amount <= 10000) {
        path = 'standard_loan';
      } else if (loanRequest.loan_amount <= 50000) {
        path = 'moderate_loan';
      } else {
        path = 'large_loan';
      }
      
      assert.strictEqual(path, 'moderate_loan');
    });
    
    it('should determine large loan path', function() {
      const loanRequest = createMockLoanRequest({ loan_amount: 75000 });
      
      let path;
      if (loanRequest.loan_amount <= 10000) {
        path = 'standard_loan';
      } else if (loanRequest.loan_amount <= 50000) {
        path = 'moderate_loan';
      } else {
        path = 'large_loan';
      }
      
      assert.strictEqual(path, 'large_loan');
    });
    
    it('should require dual approval for enterprise loans', function() {
      const loanRequest = createMockLoanRequest({ loan_amount: 150000 });
      
      let requiredApprovers = 1;
      if (loanRequest.loan_amount > 100000) {
        requiredApprovers = 2;
      }
      
      assert.strictEqual(requiredApprovers, 2);
    });
  });
  
  describe('Risk-Based Routing', function() {
    it('should route low risk to expedited path', function() {
      const loanRequest = createMockLoanRequest({
        borrower_credit_score: 800,
        debt_to_income_ratio: 0.20
      });
      
      const riskScore = calculateRiskScore(loanRequest);
      assert(riskScore < 30, 'Low credit and DTI should result in low risk score');
    });
    
    it('should route high risk to enhanced review', function() {
      const loanRequest = createMockLoanRequest({
        borrower_credit_score: 580,
        debt_to_income_ratio: 0.50
      });
      
      const riskScore = calculateRiskScore(loanRequest);
      assert(riskScore > 50, 'Poor credit and high DTI should result in high risk score');
    });
    
    it('should require additional documentation for high risk', function() {
      const loanRequest = createMockLoanRequest({
        borrower_credit_score: 580,
        loan_amount: 50000
      });
      
      const requiresAdditionalDocs = loanRequest.borrower_credit_score < 600;
      assert.strictEqual(requiresAdditionalDocs, true);
    });
  });
  
  describe('Workflow State Validation', function() {
    it('should have valid initial states', function() {
      for (const [workflowName, workflow] of Object.entries(approvalWorkflow.workflows)) {
        assert(
          workflow.states.some(s => s.state === workflow.initial_state),
          `${workflowName} initial state should exist in states`
        );
      }
    });
    
    it('should have valid final states', function() {
      for (const [workflowName, workflow] of Object.entries(approvalWorkflow.workflows)) {
        for (const finalState of workflow.final_states) {
          assert(
            workflow.states.some(s => s.state === finalState),
            `${workflowName} final state '${finalState}' should exist in states`
          );
        }
      }
    });
    
    it('should have no unreachable states', function() {
      // Check that all states are reachable from initial state
      for (const [workflowName, workflow] of Object.entries(approvalWorkflow.workflows)) {
        const reachableStates = new Set([workflow.initial_state]);
        let added;
        
        do {
          added = false;
          for (const state of workflow.states) {
            if (reachableStates.has(state.state)) {
              if (state.transitions) {
                for (const transition of state.transitions) {
                  if (!reachableStates.has(transition.target)) {
                    reachableStates.add(transition.target);
                    added = true;
                  }
                }
              }
            }
          }
        } while (added);
        
        for (const state of workflow.states) {
          assert(
            reachableStates.has(state.state),
            `${workflowName} state '${state.state}' should be reachable`
          );
        }
      }
    });
  });
  
  describe('Notification Configuration', function() {
    it('should have notification for loan submission', function() {
      const notifications = approvalWorkflow.notifications;
      
      assert(notifications.loan_submitted, 'Should have loan submitted notification');
      assert(Array.isArray(notifications.loan_submitted.recipients), 'Should have recipients');
      assert(Array.isArray(notifications.loan_submitted.channels), 'Should have channels');
    });
    
    it('should have notification for approval', function() {
      const notifications = approvalWorkflow.notifications;
      
      assert(notifications.loan_approved, 'Should have loan approved notification');
      assert(notifications.loan_approved.recipients.includes('borrower'), 'Should notify borrower');
    });
    
    it('should have notification for denial', function() {
      const notifications = approvalWorkflow.notifications;
      
      assert(notifications.loan_denied, 'Should have loan denied notification');
      assert(notifications.loan_denied.recipients.includes('borrower'), 'Should notify borrower');
    });
  });
  
  describe('Timeout Configuration', function() {
    it('should have timeout for pending approval', function() {
      const timeouts = approvalWorkflow.timeouts;
      
      assert(timeouts.pending_approval_timeout_hours, 'Should have pending approval timeout');
      assert(
        timeouts.pending_approval_timeout_hours > 0,
        'Pending approval timeout should be positive'
      );
    });
    
    it('should have escalation timeouts', function() {
      const escalations = approvalWorkflow.escalation_timeouts;
      
      assert(escalations.pending_approval, 'Should have pending approval escalation');
      assert(
        escalations.pending_approval.escalation_after_hours > 0,
        'Escalation timeout should be positive'
      );
    });
  });
});

// Helper function to calculate risk score
function calculateRiskScore(loanRequest) {
  let score = 50; // Base score
  
  // Credit score factor (lower is worse, so we add to score)
  if (loanRequest.borrower_credit_score < 600) score += 30;
  else if (loanRequest.borrower_credit_score < 650) score += 20;
  else if (loanRequest.borrower_credit_score < 700) score += 10;
  else if (loanRequest.borrower_credit_score >= 750) score -= 10;
  
  // DTI factor (higher is worse)
  if (loanRequest.debt_to_income_ratio > 0.43) score += 25;
  else if (loanRequest.debt_to_income_ratio > 0.36) score += 15;
  else if (loanRequest.debt_to_income_ratio > 0.28) score += 5;
  
  return Math.max(0, Math.min(100, score));
}

// Export for use in other test files
module.exports = {
  CONFIG,
  loadGovernanceFile,
  createMockLoanRequest,
  WorkflowSimulator,
  calculateRiskScore
};
