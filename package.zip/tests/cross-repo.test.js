/**
 * Cross-Repository Integration Tests
 * 
 * Tests the integration between richards-credit-authority and linked repositories:
 * - loaner-ledger
 * - agreements
 * - credit-tools
 * - loan-disbursement
 */

const axios = require('axios');
const fs = require('fs');
const path = require('path');

// Mock configuration for linked repositories
const REPO_CONFIG = {
  'loaner-ledger': {
    baseUrl: process.env.LEDGER_API_URL || 'http://localhost:3001',
    apiVersion: 'v1',
    timeout: 10000
  },
  'agreements': {
    baseUrl: process.env.AGREEMENTS_API_URL || 'http://localhost:3002',
    apiVersion: 'v1',
    timeout: 10000
  },
  'credit-tools': {
    baseUrl: process.env.CREDIT_TOOLS_API_URL || 'http://localhost:3003',
    apiVersion: 'v1',
    timeout: 10000
  },
  'loan-disbursement': {
    baseUrl: process.env.DISBURSEMENT_API_URL || 'http://localhost:3004',
    apiVersion: 'v1',
    timeout: 10000
  }
};

// Test data
const TEST_DATA = {
  borrowerId: 'test-borrower-001',
  loanId: 'test-loan-001',
  agreementId: 'test-agreement-001',
  disbursementId: 'test-disbursement-001',
  authorityLevel: 3
};

describe('Cross-Repository Integration Tests', () => {
  // Setup and teardown
  beforeAll(async () => {
    // Initialize test environment
    process.env.NODE_ENV = 'test';
  });

  afterAll(async () => {
    // Cleanup test environment
    delete process.env.NODE_ENV;
  });

  describe('Repository Configuration Validation', () => {
    test('should have valid configuration for all linked repositories', () => {
      expect(REPO_CONFIG).toHaveProperty('loaner-ledger');
      expect(REPO_CONFIG).toHaveProperty('agreements');
      expect(REPO_CONFIG).toHaveProperty('credit-tools');
      expect(REPO_CONFIG).toHaveProperty('loan-disbursement');
    });

    test('should have required endpoints configured', () => {
      Object.values(REPO_CONFIG).forEach(config => {
        expect(config).toHaveProperty('baseUrl');
        expect(config).toHaveProperty('apiVersion');
        expect(config).toHaveProperty('timeout');
        expect(typeof config.baseUrl).toBe('string');
        expect(typeof config.apiVersion).toBe('string');
        expect(typeof config.timeout).toBe('number');
      });
    });

    test('should have cross-repo permissions defined', () => {
      const crossRepoPermsPath = path.join(__dirname, '..', 'permission', 'cross-repo-permissions.yaml');
      
      expect(fs.existsSync(crossRepoPermsPath)).toBe(true);
      
      const crossRepoPerms = YAML.parse(fs.readFileSync(crossRepoPermsPath, 'utf8'));
      expect(crossRepoPerms).toHaveProperty('repositories');
      expect(Array.isArray(crossRepoPerms.repositories)).toBe(true);
      expect(crossRepoPerms.repositories.length).toBeGreaterThan(0);
    });
  });

  describe('Loaner Ledger Integration', () => {
    test('should validate loaner-ledger endpoint accessibility', async () => {
      const config = REPO_CONFIG['loaner-ledger'];
      const endpoint = `${config.baseUrl}/health`;
      
      try {
        const response = await axios.get(endpoint, { timeout: config.timeout });
        expect([200, 503]).toContain(response.status);
      } catch (error) {
        // Service may not be available in test environment
        expect(error.message).toContain('ECONNREFUSED');
      }
    });

    test('should verify loan request sync functionality', () => {
      const syncFunctionPath = path.join(__dirname, '..', 'webhook', 'sync-ledger.js');
      expect(fs.existsSync(syncFunctionPath)).toBe(true);
      
      const syncModule = require(syncFunctionPath);
      expect(typeof syncModule.syncLoanRequest).toBe('function');
    });

    test('should validate loan data structure before sync', () => {
      const loanData = {
        loanId: TEST_DATA.loanId,
        borrowerId: TEST_DATA.borrowerId,
        amount: 50000,
        status: 'pending',
        authorityRequired: TEST_DATA.authorityLevel
      };

      expect(loanData).toHaveProperty('loanId');
      expect(loanData).toHaveProperty('borrowerId');
      expect(loanData).toHaveProperty('amount');
      expect(loanData).toHaveProperty('status');
      expect(loanData).toHaveProperty('authorityRequired');
      expect(typeof loanData.amount).toBe('number');
      expect(loanData.amount).toBeGreaterThan(0);
    });

    test('should validate cross-repo permissions for ledger access', () => {
      const crossRepoPermsPath = path.join(__dirname, '..', 'permission', 'cross-repo-permissions.yaml');
      const crossRepoPerms = YAML.parse(fs.readFileSync(crossRepoPermsPath, 'utf8'));
      
      const ledgerPermissions = crossRepoPerms.repositories.find(r => r.name === 'loaner-ledger');
      
      expect(ledgerPermissions).toBeDefined();
      expect(ledgerPermissions).toHaveProperty('actions');
      expect(Array.isArray(ledgerPermissions.actions)).toBe(true);
      expect(ledgerPermissions.actions).toContain('read');
      expect(ledgerPermissions.actions).toContain('write');
    });
  });

  describe('Agreements Integration', () => {
    test('should validate agreements endpoint accessibility', async () => {
      const config = REPO_CONFIG['agreements'];
      const endpoint = `${config.baseUrl}/health`;
      
      try {
        const response = await axios.get(endpoint, { timeout: config.timeout });
        expect([200, 503]).toContain(response.status);
      } catch (error) {
        expect(error.message).toContain('ECONNREFUSED');
      }
    });

    test('should validate agreement data structure', () => {
      const agreementData = {
        agreementId: TEST_DATA.agreementId,
        borrowerId: TEST_DATA.borrowerId,
        loanId: TEST_DATA.loanId,
        terms: {
          interestRate: 0.05,
          termMonths: 60,
          monthlyPayment: 943.87
        },
        status: 'pending_signature',
        authorityRequired: TEST_DATA.authorityLevel
      };

      expect(agreementData).toHaveProperty('agreementId');
      expect(agreementData).toHaveProperty('borrowerId');
      expect(agreementData).toHaveProperty('loanId');
      expect(agreementData).toHaveProperty('terms');
      expect(agreementData.terms).toHaveProperty('interestRate');
      expect(agreementData.terms).toHaveProperty('termMonths');
      expect(agreementData.terms).toHaveProperty('monthlyPayment');
    });

    test('should validate cross-repo permissions for agreements access', () => {
      const crossRepoPermsPath = path.join(__dirname, '..', 'permission', 'cross-repo-permissions.yaml');
      const crossRepoPerms = YAML.parse(fs.readFileSync(crossRepoPermsPath, 'utf8'));
      
      const agreementsPermissions = crossRepoPerms.repositories.find(r => r.name === 'agreements');
      
      expect(agreementsPermissions).toBeDefined();
      expect(agreementsPermissions).toHaveProperty('actions');
      expect(agreementsPermissions.actions).toContain('read');
      expect(agreementsPermissions.actions).toContain('create');
    });
  });

  describe('Credit Tools Integration', () => {
    test('should validate credit-tools endpoint accessibility', async () => {
      const config = REPO_CONFIG['credit-tools'];
      const endpoint = `${config.baseUrl}/health`;
      
      try {
        const response = await axios.get(endpoint, { timeout: config.timeout });
        expect([200, 503]).toContain(response.status);
      } catch (error) {
        expect(error.message).toContain('ECONNREFUSED');
      }
    });

    test('should validate credit assessment data structure', () => {
      const creditAssessment = {
        borrowerId: TEST_DATA.borrowerId,
        creditScore: 720,
        debtToIncomeRatio: 0.35,
        maxLoanAmount: 100000,
        riskCategory: 'low',
        authorityRequired: TEST_DATA.authorityLevel
      };

      expect(creditAssessment).toHaveProperty('borrowerId');
      expect(creditAssessment).toHaveProperty('creditScore');
      expect(creditAssessment.creditScore).toBeGreaterThanOrEqual(300);
      expect(creditAssessment.creditScore).toBeLessThanOrEqual(850);
      expect(creditAssessment).toHaveProperty('debtToIncomeRatio');
      expect(creditAssessment.debtToIncomeRatio).toBeLessThanOrEqual(1);
    });

    test('should validate cross-repo permissions for credit-tools access', () => {
      const crossRepoPermsPath = path.join(__dirname, '..', 'permission', 'cross-repo-permissions.yaml');
      const crossRepoPerms = YAML.parse(fs.readFileSync(crossRepoPermsPath, 'utf8'));
      
      const creditToolsPermissions = crossRepoPerms.repositories.find(r => r.name === 'credit-tools');
      
      expect(creditToolsPermissions).toBeDefined();
      expect(creditToolsPermissions).toHaveProperty('actions');
      expect(creditToolsPermissions.actions).toContain('read');
      expect(creditToolsPermissions.actions).toContain('execute');
    });
  });

  describe('Loan Disbursement Integration', () => {
    test('should validate loan-disbursement endpoint accessibility', async () => {
      const config = REPO_CONFIG['loan-disbursement'];
      const endpoint = `${config.baseUrl}/health`;
      
      try {
        const response = await axios.get(endpoint, { timeout: config.timeout });
        expect([200, 503]).toContain(response.status);
      } catch (error) {
        expect(error.message).toContain('ECONNREFUSED');
      }
    });

    test('should validate disbursement data structure', () => {
      const disbursementData = {
        disbursementId: TEST_DATA.disbursementId,
        loanId: TEST_DATA.loanId,
        borrowerId: TEST_DATA.borrowerId,
        amount: 50000,
        method: 'ach',
        status: 'pending',
        authorityRequired: TEST_DATA.authorityLevel
      };

      expect(disbursementData).toHaveProperty('disbursementId');
      expect(disbursementData).toHaveProperty('loanId');
      expect(disbursementData).toHaveProperty('borrowerId');
      expect(disbursementData).toHaveProperty('amount');
      expect(disbursementData.amount).toBeGreaterThan(0);
      expect(disbursementData).toHaveProperty('method');
      expect(['ach', 'wire', 'check']).toContain(disbursementData.method);
    });

    test('should validate cross-repo permissions for disbursement access', () => {
      const crossRepoPermsPath = path.join(__dirname, '..', 'permission', 'cross-repo-permissions.yaml');
      const crossRepoPerms = YAML.parse(fs.readFileSync(crossRepoPermsPath, 'utf8'));
      
      const disbursementPermissions = crossRepoPerms.repositories.find(r => r.name === 'loan-disbursement');
      
      expect(disbursementPermissions).toBeDefined();
      expect(disbursementPermissions).toHaveProperty('actions');
      expect(disbursementPermissions.actions).toContain('read');
      expect(disbursementPermissions.actions).toContain('execute');
      expect(disbursementPermissions.actions).toContain('approve');
    });
  });

  describe('Cross-Repository Workflow Validation', () => {
    test('should validate complete loan workflow integration', () => {
      const workflowSteps = [
        { step: 1, repo: 'credit-tools', action: 'credit-assessment' },
        { step: 2, repo: 'loaner-ledger', action: 'create-loan' },
        { step: 3, repo: 'agreements', action: 'generate-agreement' },
        { step: 4, repo: 'loan-disbursement', action: 'disburse-funds' }
      ];

      expect(workflowSteps.length).toBe(4);
      
      workflowSteps.forEach((step, index) => {
        expect(step.step).toBe(index + 1);
        expect(REPO_CONFIG).toHaveProperty(step.repo);
      });
    });

    test('should validate authority level requirements for cross-repo operations', () => {
      const crossRepoPermsPath = path.join(__dirname, '..', 'permission', 'cross-repo-permissions.yaml');
      const crossRepoPerms = YAML.parse(fs.readFileSync(crossRepoPermsPath, 'utf8'));
      
      crossRepoPerms.repositories.forEach(repo => {
        expect(repo).toHaveProperty('minAuthorityLevel');
        expect(typeof repo.minAuthorityLevel).toBe('number');
        expect(repo.minAuthorityLevel).toBeGreaterThanOrEqual(1);
        expect(repo.minAuthorityLevel).toBeLessThanOrEqual(5);
      });
    });

    test('should validate audit trail requirements for cross-repo actions', () => {
      const crossRepoPermsPath = path.join(__dirname, '..', 'permission', 'cross-repo-permissions.yaml');
      const crossRepoPerms = YAML.parse(fs.readFileSync(crossRepoPermsPath, 'utf8'));
      
      crossRepoPerms.repositories.forEach(repo => {
        expect(repo).toHaveProperty('auditRequired');
        expect(typeof repo.auditRequired).toBe('boolean');
      });
    });

    test('should validate sync script exists and is functional', () => {
      const syncScriptPath = path.join(__dirname, '..', 'scripts', 'sync-cross-repo.js');
      expect(fs.existsSync(syncScriptPath)).toBe(true);
      
      const syncModule = require(syncScriptPath);
      expect(typeof syncModule.syncAllRepositories).toBe('function');
      expect(typeof syncModule.syncRepository).toBe('function');
    });
  });

  describe('Error Handling and Fallbacks', () => {
    test('should handle repository unavailability gracefully', async () => {
      const unavailableConfig = {
        baseUrl: 'http://unavailable-service:9999',
        apiVersion: 'v1',
        timeout: 100
      };

      try {
        await axios.get(`${unavailableConfig.baseUrl}/health`, { 
          timeout: unavailableConfig.timeout 
        });
      } catch (error) {
        expect(error.code).toBe('ECONNREFUSED');
      }
    });

    test('should validate fallback mechanisms for critical operations', () => {
      const fallbackConfig = {
        retryAttempts: 3,
        retryDelay: 1000,
        circuitBreakerThreshold: 5
      };

      expect(fallbackConfig.retryAttempts).toBeGreaterThan(0);
      expect(fallbackConfig.retryDelay).toBeGreaterThan(0);
      expect(fallbackConfig.circuitBreakerThreshold).toBeGreaterThan(0);
    });

    test('should validate notification requirements for cross-repo failures', () => {
      const crossRepoPermsPath = path.join(__dirname, '..', 'permission', 'cross-repo-permissions.yaml');
      const crossRepoPerms = YAML.parse(fs.readFileSync(crossRepoPermsPath, 'utf8'));
      
      crossRepoPerms.repositories.forEach(repo => {
        if (repo.critical) {
          expect(repo).toHaveProperty('failureNotification');
          expect(repo.failureNotification).toHaveProperty('recipients');
          expect(Array.isArray(repo.failureNotification.recipients)).toBe(true);
        }
      });
    });
  });

  describe('Security and Compliance', () => {
    test('should validate API key requirements for external repositories', () => {
      const requiredEnvVars = [
        'LEDGER_API_KEY',
        'AGREEMENTS_API_KEY',
        'CREDIT_TOOLS_API_KEY',
        'DISBURSEMENT_API_KEY'
      ];

      // Check if environment variables are configured (may not be in test environment)
      requiredEnvVars.forEach(envVar => {
        if (process.env[envVar]) {
          expect(process.env[envVar].length).toBeGreaterThan(0);
        }
      });
    });

    test('should validate TLS/SSL requirements for external communications', () => {
      Object.values(REPO_CONFIG).forEach(config => {
        const baseUrl = config.baseUrl;
        expect(baseUrl.startsWith('https://')).toBe(true);
      });
    });

    test('should validate rate limiting configuration', () => {
      const rateLimitConfig = {
        loanerledger: { requestsPerMinute: 100 },
        agreements: { requestsPerMinute: 60 },
        credittools: { requestsPerMinute: 30 },
        loandisbursement: { requestsPerMinute: 20 }
      };

      Object.values(rateLimitConfig).forEach(limit => {
        expect(limit.requestsPerMinute).toBeGreaterThan(0);
        expect(limit.requestsPerMinute).toBeLessThanOrEqual(1000);
      });
    });
  });
});

// Helper function for YAML parsing (simple implementation for tests)
const YAML = {
  parse: (str) => {
    // Simple YAML to JSON conversion for testing
    const result = {};
    const lines = str.split('\n');
    let currentSection = null;
    
    lines.forEach(line => {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith('#')) return;
      
      if (trimmed.startsWith('- ')) {
        if (currentSection) {
          if (!result[currentSection]) result[currentSection] = [];
          result[currentSection].push(trimmed.substring(2));
        }
      } else if (trimmed.includes(':')) {
        const [key, value] = trimmed.split(':').map(s => s.trim());
        if (value === '') {
          currentSection = key;
        } else {
          currentSection = null;
          result[key] = value;
        }
      }
    });
    
    return result;
  }
};
