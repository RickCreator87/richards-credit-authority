/**
 * Governance Tests
 * Tests for governance workflows
 * 
 * @module governance-tests
 */

const fs = require('fs');
const path = require('path');
const yaml = require('js-yaml');
const assert = require('assert');

// Configuration
const CONFIG = {
  governanceDir: path.join(__dirname, '..', 'governance'),
  schemaFile: path.join(__dirname, '..', 'governance', 'governance-schema.json')
};

// Test utilities
function loadGovernanceFile(filename) {
  const filePath = path.join(CONFIG.governanceDir, filename);
  if (!fs.existsSync(filePath)) {
    return null;
  }
  const content = fs.readFileSync(filePath, 'utf8');
  const ext = path.extname(filename).toLowerCase();
  
  if (ext === '.json') {
    return JSON.parse(content);
  } else if (ext === '.yaml' || ext === '.yml') {
    return yaml.load(content);
  }
  return null;
}

function loadSchema() {
  if (!fs.existsSync(CONFIG.schemaFile)) {
    return null;
  }
  const content = fs.readFileSync(CONFIG.schemaFile, 'utf8');
  return JSON.parse(content);
}

// Test Suite
describe('Governance Tests', function() {
  this.timeout(10000);
  
  describe('Governance Model', function() {
    let governanceModel;
    
    before(function() {
      governanceModel = loadGovernanceFile('governance-model.md');
    });
    
    it('should exist', function() {
      assert(governanceModel !== null, 'Governance model file should exist');
    });
    
    it('should contain governance principles', function() {
      const content = governanceModel;
      assert(content.includes('Authority Proportionality'), 
        'Should contain Authority Proportionality principle');
      assert(content.includes('Separation of Duties'), 
        'Should contain Separation of Duties principle');
      assert(content.includes('Transparency and Traceability'), 
        'Should contain Transparency principle');
    });
    
    it('should define role hierarchy', function() {
      const roles = [
        'Richard Founder',
        'Richard Admin',
        'Richard Officer',
        'Auditor',
        'System Service'
      ];
      
      for (const role of roles) {
        assert(content.includes(role), 
          `Should contain ${role} definition`);
      }
    });
  });
  
  describe('Approval Workflow', function() {
    let approvalWorkflow;
    
    before(function() {
      approvalWorkflow = loadGovernanceFile('approval-workflow.yaml');
    });
    
    it('should have valid structure', function() {
      assert(approvalWorkflow, 'Approval workflow file should exist');
      assert(approvalWorkflow.workflows, 'Should have workflows');
    });
    
    it('should define required workflows', function() {
      const requiredWorkflows = [
        'loan_request',
        'disbursement',
        'amendment',
        'tax_event'
      ];
      
      for (const workflow of requiredWorkflows) {
        assert(
          approvalWorkflow.workflows[workflow],
          `Workflow ${workflow} should be defined`
        );
      }
    });
    
    it('should have valid state machines', function() {
      for (const [workflowName, workflow] of Object.entries(approvalWorkflow.workflows)) {
        assert(workflow.initial_state, `${workflowName} should have initial state`);
        assert(workflow.final_states, `${workflowName} should have final states`);
        assert(Array.isArray(workflow.final_states), `${workflowName} final_states should be array`);
        assert(workflow.states, `${workflowName} should have states`);
        assert(Array.isArray(workflow.states), `${workflowName} states should be array`);
      }
    });
    
    it('should have valid state transitions', function() {
      for (const [workflowName, workflow] of Object.entries(approvalWorkflow.workflows)) {
        const stateNames = new Set(workflow.states.map(s => s.state));
        
        for (const state of workflow.states) {
          if (state.transitions) {
            for (const transition of state.transitions) {
              assert(
                stateNames.has(transition.target),
                `${workflowName}: Transition target '${transition.target}' should be valid state`
              );
            }
          }
        }
      }
    });
    
    it('should define approval paths', function() {
      assert(
        approvalWorkflow.approval_paths,
        'Should have approval paths'
      );
      
      const requiredPaths = [
        'standard_loan',
        'moderate_loan',
        'large_loan',
        'enterprise_loan'
      ];
      
      for (const path of requiredPaths) {
        assert(
          approvalWorkflow.approval_paths[path],
          `Approval path ${path} should be defined`
        );
      }
    });
    
    it('should have valid amount ranges', function() {
      for (const [pathName, pathData] of Object.entries(approvalWorkflow.approval_paths)) {
        assert(pathData.amount_range, `${pathName} should have amount range`);
        assert(
          pathData.amount_range.min >= 0,
          `${pathName} min amount should be non-negative`
        );
        assert(
          pathData.amount_range.max > pathData.amount_range.min,
          `${pathName} max amount should be greater than min`
        );
      }
    });
    
    it('should have required approvers for each path', function() {
      for (const [pathName, pathData] of Object.entries(approvalWorkflow.approval_paths)) {
        assert(
          pathData.required_approvers,
          `${pathName} should have required approvers`
        );
        assert(
          Array.isArray(pathData.required_approvers),
          `${pathName} required_approvers should be array`
        );
        assert(
          pathData.required_approvers.length > 0,
          `${pathName} should have at least one approver`
        );
      }
    });
    
    it('should have notification configurations', function() {
      assert(
        approvalWorkflow.notifications,
        'Should have notification configurations'
      );
    });
    
    it('should have timeout configurations', function() {
      assert(
        approvalWorkflow.timeouts,
        'Should have timeout configurations'
      );
    });
  });
  
  describe('Milestone Rules', function() {
    let milestoneRules;
    
    before(function() {
      milestoneRules = loadGovernanceFile('milestone-rules.yaml');
    });
    
    it('should have valid structure', function() {
      assert(milestoneRules, 'Milestone rules file should exist');
      assert(milestoneRules.milestones, 'Should have milestones');
    });
    
    it('should define all milestone levels', function() {
      const requiredMilestones = [
        'milestone_0',
        'milestone_1',
        'milestone_2',
        'milestone_3',
        'milestone_4',
        'milestone_5'
      ];
      
      for (const milestone of requiredMilestones) {
        assert(
          milestoneRules.milestones[milestone],
          `Milestone ${milestone} should be defined`
        );
      }
    });
    
    it('should have sequential levels', function() {
      for (let i = 0; i < 5; i++) {
        const current = milestoneRules.milestones[`milestone_${i}`];
        const next = milestoneRules.milestones[`milestone_${i + 1}`];
        
        assert(
          current.level < next.level,
          `milestone_${i} should have lower level than milestone_${i + 1}`
        );
      }
    });
    
    it('should have requirements for each milestone', function() {
      for (const [name, milestone] of Object.entries(milestoneRules.milestones)) {
        assert(
          milestone.requirements,
          `${name} should have requirements`
        );
        assert(
          Array.isArray(milestone.requirements),
          `${name} requirements should be array`
        );
        assert(
          milestone.requirements.length > 0,
          `${name} should have at least one requirement`
        );
      }
    });
    
    it('should define progression rules', function() {
      assert(
        milestoneRules.progression_rules,
        'Should have progression rules'
      );
      assert(
        milestoneRules.progression_rules.advancement_criteria,
        'Should have advancement criteria'
      );
    });
    
    it('should define retention rules', function() {
      assert(
        milestoneRules.progression_rules.milestone_retention,
        'Should have milestone retention rules'
      );
    });
    
    it('should define demotion rules', function() {
      assert(
        milestoneRules.progression_rules.milestone_demotion,
        'Should have milestone demotion rules'
      );
    });
    
    it('should have approval benefits', function() {
      assert(
        milestoneRules.approval_benefits,
        'Should have approval benefits'
      );
      assert(
        Array.isArray(milestoneRules.approval_benefits),
        'Approval benefits should be array'
      );
    });
  });
  
  describe('Audit Rules', function() {
    let auditRules;
    
    before(function() {
      auditRules = loadGovernanceFile('audit-rules.yaml');
    });
    
    it('should have valid structure', function() {
      assert(auditRules, 'Audit rules file should exist');
      assert(auditRules.event_categories, 'Should have event categories');
    });
    
    it('should define event categories', function() {
      const requiredCategories = [
        'authentication',
        'authorization',
        'loan_operations',
        'disbursement',
        'security_events'
      ];
      
      for (const category of requiredCategories) {
        assert(
          auditRules.event_categories[category],
          `Event category ${category} should be defined`
        );
      }
    });
    
    it('should have required audit fields', function() {
      assert(
        auditRules.audit_fields,
        'Should have audit fields'
      );
      assert(
        auditRules.audit_fields.required_fields,
        'Should have required fields'
      );
      
      const requiredFields = [
        'timestamp',
        'actor_id',
        'action_type',
        'outcome'
      ];
      
      for (const field of requiredFields) {
        assert(
          auditRules.audit_fields.required_fields.includes(field),
          `Required field ${field} should be defined`
        );
      }
    });
    
    it('should define event specifications', function() {
      assert(
        auditRules.event_specifications,
        'Should have event specifications'
      );
    });
    
    it('should have retention policies', function() {
      assert(
        auditRules.retention,
        'Should have retention policies'
      );
    });
    
    it('should define access control', function() {
      assert(
        auditRules.access_control,
        'Should have access control'
      );
    });
    
    it('should have integrity protections', function() {
      assert(
        auditRules.integrity,
        'Should have integrity protections'
      );
    });
  });
  
  describe('Risk Controls', function() {
    let riskControls;
    
    before(function() {
      riskControls = loadGovernanceFile('risk-controls.yaml');
    });
    
    it('should have valid structure', function() {
      assert(riskControls, 'Risk controls file should exist');
      assert(riskControls.risk_calculation, 'Should have risk calculation');
    });
    
    it('should define risk factors', function() {
      assert(
        riskControls.risk_calculation.factors,
        'Should have risk factors'
      );
      assert(
        riskControls.risk_calculation.factors.length > 0,
        'Should have at least one risk factor'
      );
    });
    
    it('should have valid factor weights', function() {
      for (const factor of riskControls.risk_calculation.factors) {
        assert(
          factor.weight >= 0 && factor.weight <= 1,
          `${factor.name} weight should be between 0 and 1`
        );
      }
    });
    
    it('should have risk tiers', function() {
      assert(
        riskControls.risk_tiers,
        'Should have risk tiers'
      );
      assert(
        riskControls.risk_tiers.length > 0,
        'Should have at least one risk tier'
      );
    });
    
    it('should have non-overlapping tier ranges', function() {
      const ranges = [];
      for (const tier of riskControls.risk_tiers) {
        ranges.push({ min: tier.min_score, max: tier.max_score, name: tier.tier });
      }
      
      for (let i = 0; i < ranges.length; i++) {
        for (let j = i + 1; j < ranges.length; j++) {
          assert(
            ranges[i].max < ranges[j].min || ranges[j].max < ranges[i].min,
            `Ranges for ${ranges[i].name} and ${ranges[j].name} should not overlap`
          );
        }
      }
    });
    
    it('should define concentration limits', function() {
      assert(
        riskControls.concentration_limits,
        'Should have concentration limits'
      );
    });
    
    it('should define transaction limits', function() {
      assert(
        riskControls.transaction_limits,
        'Should have transaction limits'
      );
    });
    
    it('should have override rules', function() {
      assert(
        riskControls.overrides,
        'Should have override rules'
      );
    });
    
    it('should define escalation rules', function() {
      assert(
        riskControls.escalation_rules,
        'Should have escalation rules'
      );
      assert(
        Array.isArray(riskControls.escalation_rules),
        'Escalation rules should be array'
      );
    });
    
    it('should have velocity controls', function() {
      assert(
        riskControls.velocity_controls,
        'Should have velocity controls'
      );
    });
    
    it('should have fraud detection rules', function() {
      assert(
        riskControls.fraud_detection,
        'Should have fraud detection rules'
      );
    });
  });
  
  describe('Governance Schema', function() {
    let schema;
    
    before(function() {
      schema = loadSchema();
    });
    
    it('should have valid schema structure', function() {
      assert(schema, 'Schema should exist');
      assert(schema.$schema, 'Should have $schema');
      assert(schema.$id, 'Should have $id');
      assert(schema.definitions, 'Should have definitions');
    });
    
    it('should define workflow structures', function() {
      assert(
        schema.definitions.workflow_definition,
        'Should have workflow definition'
      );
      assert(
        schema.definitions.workflow_state,
        'Should have workflow state definition'
      );
    });
    
    it('should define approval structures', function() {
      assert(
        schema.definitions.approval_requirement,
        'Should have approval requirement definition'
      );
      assert(
        schema.definitions.approval_path,
        'Should have approval path definition'
      );
    });
    
    it('should define milestone structures', function() {
      assert(
        schema.definitions.milestone_definition,
        'Should have milestone definition'
      );
    });
    
    it('should define risk structures', function() {
      assert(
        schema.definitions.risk_factor,
        'Should have risk factor definition'
      );
      assert(
        schema.definitions.risk_tier,
        'Should have risk tier definition'
      );
    });
  });
});

// Export for use in other test files
module.exports = {
  CONFIG,
  loadGovernanceFile,
  loadSchema
};
