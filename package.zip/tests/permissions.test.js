/**
 * Permission Tests
 * Tests for permission matrix and rules
 * 
 * @module permission-tests
 */

const fs = require('fs');
const path = require('path');
const yaml = require('js-yaml');
const assert = require('assert');

// Configuration
const CONFIG = {
  permissionDir: path.join(__dirname, '..', 'permission'),
  schemaFile: path.join(__dirname, '..', 'permission', 'permission-schema.json')
};

// Test utilities
function loadPermissionFile(filename) {
  const filePath = path.join(CONFIG.permissionDir, filename);
  if (!fs.existsSync(filePath)) {
    return null;
  }
  const content = fs.readFileSync(filePath, 'utf8');
  const ext = path.extname(filename).toLowerCase();
  
  if (ext === '.json') {
    return JSON.parse(content);
  } else if (ext === '.yaml' || ext === '.yml') {
    return yaml.load(content);
  }
  return null;
}

function loadSchema() {
  if (!fs.existsSync(CONFIG.schemaFile)) {
    return null;
  }
  const content = fs.readFileSync(CONFIG.schemaFile, 'utf8');
  return JSON.parse(content);
}

// Test Suite
describe('Permission Tests', function() {
  this.timeout(10000);
  
  describe('Permission Matrix', function() {
    let permissionMatrix;
    
    before(function() {
      permissionMatrix = loadPermissionFile('permission-matrix.yaml');
    });
    
    it('should have valid structure', function() {
      assert(permissionMatrix, 'Permission matrix should exist');
      assert(permissionMatrix.roles, 'Should have roles');
      assert(permissionMatrix.actions, 'Should have actions');
    });
    
    it('should define all required roles', function() {
      const requiredRoles = [
        'richard_founder',
        'richard_admin',
        'richard_officer',
        'auditor',
        'system_service'
      ];
      
      for (const role of requiredRoles) {
        assert(permissionMatrix.roles[role], `Role ${role} should be defined`);
      }
    });
    
    it('should have valid authority levels', function() {
      for (const [roleName, role] of Object.entries(permissionMatrix.roles)) {
        assert(
          role.authority_level >= 1 && role.authority_level <= 100,
          `${roleName} should have valid authority level`
        );
      }
    });
    
    it('should have unique authority levels', function() {
      const levels = Object.values(permissionMatrix.roles)
        .map(r => r.authority_level);
      
      const uniqueLevels = new Set(levels);
      assert.strictEqual(
        levels.length,
        uniqueLevels.size,
        'Authority levels should be unique'
      );
    });
    
    it('should define required permissions for each role', function() {
      for (const [roleName, role] of Object.entries(permissionMatrix.roles)) {
        assert(
          Array.isArray(role.permissions),
          `${roleName} should have permissions array`
        );
        assert(
          role.permissions.length > 0,
          `${roleName} should have at least one permission`
        );
      }
    });
    
    it('should have required actions defined', function() {
      const requiredActions = [
        'approve_loan',
        'deny_loan',
        'audit_transactions',
        'verify_identity'
      ];
      
      for (const action of requiredActions) {
        assert(
          permissionMatrix.actions[action],
          `Action ${action} should be defined`
        );
      }
    });
    
    it('should have valid action authority requirements', function() {
      for (const [actionName, action] of Object.entries(permissionMatrix.actions)) {
        assert(
          action.requires_authority_level >= 1 && 
          action.requires_authority_level <= 100,
          `${actionName} should have valid authority requirement`
        );
      }
    });
    
    it('should define thresholds', function() {
      assert(
        permissionMatrix.thresholds,
        'Should have thresholds defined'
      );
      assert(
        Array.isArray(permissionMatrix.thresholds),
        'Thresholds should be an array'
      );
      assert(
        permissionMatrix.thresholds.length > 0,
        'Should have at least one threshold'
      );
    });
    
    it('should have valid escalation rules', function() {
      if (permissionMatrix.escalation_rules) {
        assert(
          Array.isArray(permissionMatrix.escalation_rules),
          'Escalation rules should be an array'
        );
        
        for (const rule of permissionMatrix.escalation_rules) {
          assert(rule.condition, 'Rule should have condition');
          assert(rule.action, 'Rule should have action');
        }
      }
    });
  });
  
  describe('Allowed Actions', function() {
    let allowedActions;
    
    before(function() {
      allowedActions = loadPermissionFile('allowed-actions.yaml');
    });
    
    it('should have valid structure', function() {
      assert(allowedActions, 'Allowed actions file should exist');
    });
    
    it('should define actions for all roles', function() {
      const roleActions = [
        'founder_allowed_actions',
        'admin_allowed_actions',
        'officer_allowed_actions',
        'auditor_allowed_actions',
        'system_service_allowed_actions'
      ];
      
      for (const roleAction of roleActions) {
        assert(
          allowedActions[roleAction],
          `${roleAction} should be defined`
        );
        assert(
          Array.isArray(allowedActions[roleAction]),
          `${roleAction} should be an array`
        );
      }
    });
    
    it('should have conditions for each action', function() {
      for (const [roleAction, actions] of Object.entries(allowedActions)) {
        if (Array.isArray(actions)) {
          for (const action of actions) {
            assert(
              action.conditions,
              `Action in ${roleAction} should have conditions`
            );
            assert(
              Array.isArray(action.conditions),
              `Conditions should be an array`
            );
          }
        }
      }
    });
    
    it('should have time restrictions', function() {
      if (allowedActions.time_restrictions) {
        assert(
          Array.isArray(allowedActions.time_restrictions),
          'Time restrictions should be an array'
        );
        
        for (const restriction of allowedActions.time_restrictions) {
          assert(restriction.action, 'Should have action');
          assert(restriction.allowed_hours, 'Should have allowed hours');
        }
      }
    });
  });
  
  describe('Restricted Actions', function() {
    let restrictedActions;
    
    before(function() {
      restrictedActions = loadPermissionFile('restricted-actions.yaml');
    });
    
    it('should have valid structure', function() {
      assert(restrictedActions, 'Restricted actions file should exist');
    });
    
    it('should define dual approval requirements', function() {
      assert(
        restrictedActions.dual_approval_required,
        'Should have dual approval requirements'
      );
      assert(
        Array.isArray(restrictedActions.dual_approval_required),
        'Dual approval requirements should be an array'
      );
    });
    
    it('should require documentation for restricted actions', function() {
      for (const action of restrictedActions.dual_approval_required) {
        assert(
          action.documentation_required,
          `${action.action} should require documentation`
        );
        assert(
          Array.isArray(action.documentation_required),
          'Documentation requirements should be an array'
        );
      }
    });
    
    it('should define tax validation requirements', function() {
      assert(
        restrictedActions.tax_validation_required,
        'Should have tax validation requirements'
      );
      assert(
        Array.isArray(restrictedActions.tax_validation_required),
        'Tax validation requirements should be an array'
      );
    });
    
    it('should have prohibited actions', function() {
      assert(
        restrictedActions.prohibited_actions,
        'Should have prohibited actions'
      );
      assert(
        Array.isArray(restrictedActions.prohibited_actions),
        'Prohibited actions should be an array'
      );
    });
  });
  
  describe('Cross-Repository Permissions', function() {
    let crossRepoPermissions;
    
    before(function() {
      crossRepoPermissions = loadPermissionFile('cross-repo-permissions.yaml');
    });
    
    it('should have valid structure', function() {
      assert(crossRepoPermissions, 'Cross-repo permissions file should exist');
    });
    
    it('should define all required repositories', function() {
      const requiredRepos = [
        'loaner-ledger',
        'agreements',
        'credit-tools',
        'loan-disbursement'
      ];
      
      for (const repo of requiredRepos) {
        assert(
          crossRepoPermissions.repositories[repo],
          `Repository ${repo} should be defined`
        );
      }
    });
    
    it('should have valid repository URLs', function() {
      for (const [repoName, repo] of Object.entries(crossRepoPermissions.repositories)) {
        assert(
          repo.repository_url.startsWith('https://'),
          `${repoName} should have valid URL`
        );
      }
    });
    
    it('should define sync directions', function() {
      for (const [repoName, repo] of Object.entries(crossRepoPermissions.repositories)) {
        assert(
          repo.sync_direction,
          `${repoName} should have sync direction`
        );
        assert(
          ['unidirectional', 'bidirectional', 'outbound'].includes(repo.sync_direction),
          `${repoName} should have valid sync direction`
        );
      }
    });
    
    it('should define cross-repo actions', function() {
      assert(
        crossRepoPermissions.cross_repo_actions,
        'Should have cross-repo actions'
      );
      assert(
        Array.isArray(crossRepoPermissions.cross_repo_actions),
        'Cross-repo actions should be an array'
      );
    });
    
    it('should have security configuration', function() {
      assert(
        crossRepoPermissions.security_config,
        'Should have security configuration'
      );
    });
  });
  
  describe('Validation Rules', function() {
    let validationRules;
    
    before(function() {
      validationRules = loadPermissionFile('validation-rules.yaml');
    });
    
    it('should have valid structure', function() {
      assert(validationRules, 'Validation rules file should exist');
    });
    
    it('should define identity validation rules', function() {
      assert(
        validationRules.identity_validation,
        'Should have identity validation rules'
      );
      assert(
        validationRules.identity_validation.required_fields,
        'Should have required identity fields'
      );
    });
    
    it('should define loan request validation', function() {
      assert(
        validationRules.loan_request_validation,
        'Should have loan request validation'
      );
      assert(
        validationRules.loan_request_validation.required_fields,
        'Should have required loan request fields'
      );
    });
    
    it('should define credit score ranges', function() {
      assert(
        validationRules.credit_score_validation,
        'Should have credit score validation'
      );
      assert(
        validationRules.credit_score_validation.score_ranges,
        'Should have score ranges'
      );
    });
    
    it('should define risk thresholds', function() {
      assert(
        validationRules.risk_validation,
        'Should have risk validation'
      );
      assert(
        validationRules.risk_validation.risk_thresholds,
        'Should have risk thresholds'
      );
    });
    
    it('should define tax validation rules', function() {
      assert(
        validationRules.tax_validation,
        'Should have tax validation rules'
      );
    });
  });
  
  describe('Permission Schema', function() {
    let schema;
    
    before(function() {
      schema = loadSchema();
    });
    
    it('should have valid schema structure', function() {
      assert(schema, 'Schema should exist');
      assert(schema.$schema, 'Should have $schema');
      assert(schema.$id, 'Should have $id');
      assert(schema.definitions, 'Should have definitions');
    });
    
    it('should define all role structures', function() {
      assert(
        schema.definitions.role_definition,
        'Should have role definition'
      );
    });
    
    it('should define all action structures', function() {
      assert(
        schema.definitions.action_definition,
        'Should have action definition'
      );
    });
    
    it('should define threshold structures', function() {
      assert(
        schema.definitions.threshold_definition,
        'Should have threshold definition'
      );
    });
  });
  
  describe('Permission Consistency', function() {
    it('should have consistent role permissions across files', function() {
      const permissionMatrix = loadPermissionFile('permission-matrix.yaml');
      const allowedActions = loadPermissionFile('allowed-actions.yaml');
      
      // Founder should have all actions in permission matrix
      const founderPermissions = permissionMatrix.roles.richard_founder.permissions;
      const founderAllowedActions = allowedActions.founder_allowed_actions;
      
      // Check that defined permissions match allowed actions
      const allowedActionTypes = founderAllowedActions.map(a => a.action);
      
      for (const permission of founderPermissions) {
        if (typeof permission === 'string') {
          assert(
            allowedActionTypes.includes(permission) || 
            allowedActionTypes.some(a => a.includes(permission)),
            `Permission ${permission} should have corresponding allowed action`
          );
        }
      }
    });
    
    it('should have escalation rules that reference valid roles', function() {
      const permissionMatrix = loadPermissionFile('permission-matrix.yaml');
      
      if (permissionMatrix.escalation_rules) {
        const validRoles = Object.keys(permissionMatrix.roles);
        
        for (const rule of permissionMatrix.escalation_rules) {
          if (rule.escalate_to) {
            assert(
              validRoles.includes(rule.escalate_to),
              `Escalation target ${rule.escalate_to} should be a valid role`
            );
          }
        }
      }
    });
  });
});

// Export for use in other test files
module.exports = {
  CONFIG,
  loadPermissionFile,
  loadSchema
};
