export default function App() {
  return (
    <div style={{padding: 20}}>
      <h1>Richards Credit Authority</h1>
      <p>Authority engine online.</p>
    </div>
  )
}
