# Loan Governance
Rules for issuing loans.
