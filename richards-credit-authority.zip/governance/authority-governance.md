# Authority Governance
Defines authority scope.
