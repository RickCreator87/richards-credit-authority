# Permission Matrix
Defines role capabilities.
