# Emergency Freeze Rules
Immediate halt conditions.
