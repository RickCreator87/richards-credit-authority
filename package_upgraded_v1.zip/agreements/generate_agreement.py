from datetime import date

def generate_agreement(loan_id, lender, borrower, amount, rate, term_months):
    return f"""
LOAN AGREEMENT

Loan ID: {loan_id}
Lender: {lender}
Borrower: {borrower}
Principal: ${amount}
Interest Rate: {rate * 100}%
Term: {term_months} months

Issued on: {date.today().isoformat()}

This agreement is governed by internal authority and ledger systems.
"""
