"""
Permission Update Handler for Personal Credit Authority Webhook System

This handler processes permission-related events from GitHub, validates
permission matrix changes, enforces multi-signature requirements, and
propagates permission updates to dependent systems.

Events Handled:
- permission.updated: Triggered when permission matrix is modified
- permission.override_used: Triggered when founder override is invoked
- permission.freeze_initiated: Triggered when emergency freeze is activated
- permission.multisig_completed: Triggered when multi-sig approval is achieved

Author: MiniMax Agent
Version: 1.0.0
"""

import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Any, Optional, Tuple, List
from dataclasses import dataclass


@dataclass
class PermissionChange:
    """Represents a change to a permission."""
    role: str
    action: str
    old_allowed: bool
    new_allowed: bool
    changed_by: str
    timestamp: str


class PermissionUpdateHandler:
    """
    Handles synchronization of permission changes across the Personal Credit Authority.
    
    This class provides comprehensive permission management including validation
    of permission updates, enforcement of multi-signature requirements, and
    detection of security-sensitive changes.
    """
    
    def __init__(self, base_path: Optional[str] = None):
        """
        Initialize the Permission Update Handler.
        
        Args:
            base_path: Base directory path for the repository (defaults to current directory)
        """
        self.base_path = base_path or os.getcwd()
        self.permission_dir = Path(self.base_path) / "permission"
        self.governance_dir = Path(self.base_path) / "governance"
        
        # Load governance rules
        self.multisig_rules = self._load_multisig_rules()
        self.override_rules = self._load_override_rules()
        self.freeze_rules = self._load_freeze_rules()
        
    def _load_multisig_rules(self) -> Dict[str, Any]:
        """Load multi-signature approval rules."""
        rules_path = self.permission_dir / "multisig-approval-rules.json"
        if rules_path.exists():
            with open(rules_path, 'r') as f:
                return json.load(f)
        return {'threshold': 2, 'required_approvers': []}
    
    def _load_override_rules(self) -> Dict[str, Any]:
        """Load founder override rules."""
        rules_path = self.permission_dir / "founder-override-rules.json"
        if rules_path.exists():
            with open(rules_path, 'r') as f:
                return json.load(f)
        return {'allowed': False, 'audit_required': True}
    
    def _load_freeze_rules(self) -> Dict[str, Any]:
        """Load emergency freeze rules."""
        rules_path = self.permission_dir / "emergency-freeze-rules.json"
        if rules_path.exists():
            with open(rules_path, 'r') as f:
                return json.load(f)
        return {'max_duration_hours': 168, 'requires_approval': True}
    
    def handle_event(self, event_type: str, payload: Dict[str, Any]) -> Tuple[bool, str]:
        """
        Main entry point for handling permission-related webhook events.
        
        Args:
            event_type: The type of GitHub event (e.g., 'permission.updated')
            payload: The GitHub webhook payload
            
        Returns:
            Tuple of (success: bool, message: str)
        """
        handlers = {
            'permission.updated': self._handle_permission_updated,
            'permission.override_used': self._handle_permission_override,
            'permission.freeze_initiated': self._handle_freeze_initiated,
            'permission.freeze_lifted': self._handle_freeze_lifted,
            'permission.multisig_completed': self._handle_multisig_completed,
        }
        
        handler = handlers.get(event_type)
        if not handler:
            return False, f"No handler found for event type: {event_type}"
        
        try:
            return handler(payload)
        except Exception as e:
            return False, f"Error handling permission event: {str(e)}"
    
    def _handle_permission_updated(self, payload: Dict[str, Any]) -> Tuple[bool, str]:
        """
        Handle permission.updated events.
        
        This method validates permission matrix changes, checks for security-sensitive
        modifications, and enforces approval workflows.
        """
        changes = payload.get('changes', {})
        files = payload.get('files', [])
        sender = payload.get('sender', {}).get('login', 'unknown')
        
        # Find permission matrix files
        matrix_file = None
        for f in files:
            filename = f.get('filename', '')
            if 'role-action-matrix.json' in filename or 'permission' in filename:
                matrix_file = f
                break
        
        if not matrix_file:
            return False, "No permission file found in changes"
        
        # Analyze the permission changes
        permission_changes = self._analyze_permission_changes(payload)
        
        # Check for security-sensitive changes
        sensitive_changes = self._detect_sensitive_changes(permission_changes)
        
        if sensitive_changes:
            # Security-sensitive changes require additional approval
            result = self._request_additional_approval(sensitive_changes, sender)
            if not result[0]:
                return result
        
        # Validate the updated permission matrix
        validation_result = self._validate_permission_matrix()
        if not validation_result[0]:
            return validation_result
        
        # Check if multi-signature is required
        if self._requires_multisig(permission_changes):
            result = self._initiate_multisig(permission_changes, sender)
            return result
        
        # Apply the permission changes
        self._apply_permission_changes(permission_changes)
        
        # Log the permission update
        self._log_permission_update(permission_changes, sender)
        
        sensitive_info = " (security-sensitive changes detected)" if sensitive_changes else ""
        return True, f"Permission matrix updated by {sender}{sensitive_info}"
    
    def _handle_permission_override(self, payload: Dict[str, Any]) -> Tuple[bool, str]:
        """
        Handle permission.override_used events.
        
        This method processes founder override actions, validates that the
        override is permitted, and logs the override for audit purposes.
        """
        sender = payload.get('sender', {})
        action = payload.get('action', '')
        reason = payload.get('reason', 'No reason provided')
        
        # Check if override is allowed
        if not self.override_rules.get('allowed', False):
            return False, "Founder override is not currently allowed"
        
        # Verify sender has founder role
        if not self._has_role(sender.get('login', ''), 'founder'):
            return False, f"User {sender.get('login', ''} does not have founder role"
        
        # Log the override
        override_log = {
            'timestamp': datetime.now(timezone.utc).isoformat(),
            'overrider': sender.get('login', ''),
            'action': action,
            'reason': reason,
            'status': 'applied',
        }
        
        self._log_override(override_log)
        
        # Require audit if specified
        if self.override_rules.get('audit_required', False):
            self._request_audit(override_log)
        
        return True, f"Founder override applied by {sender.get('login', '')}"
    
    def _handle_freeze_initiated(self, payload: Dict[str, Any]) -> Tuple[bool, str]:
        """
        Handle permission.freeze_initiated events.
        
        This method processes emergency freeze activation, validates the
        freeze conditions, and applies the freeze to all permissions.
        """
        sender = payload.get('sender', {})
        reason = payload.get('reason', 'Emergency')
        duration = payload.get('duration_hours', self.freeze_rules.get('max_duration_hours', 168))
        
        # Validate freeze conditions
        if not self._validate_freeze_conditions(reason):
            return False, "Freeze conditions not met"
        
        # Check approval requirements
        if self.freeze_rules.get('requires_approval', True):
            if not self._verify_freeze_approval(sender.get('login', '')):
                return False, "Freeze requires additional approval"
        
        # Apply the freeze
        freeze_data = {
            'frozen': True,
            'frozen_at': datetime.now(timezone.utc).isoformat(),
            'frozen_by': sender.get('login', ''),
            'reason': reason,
            'expires_at': datetime.now(timezone.utc).timestamp() + (duration * 3600),
        }
        
        self._apply_freeze(freeze_data)
        self._log_freeze(freeze_data)
        
        return True, f"Emergency freeze activated by {sender.get('login', '')} for {duration} hours"
    
    def _handle_freeze_lifted(self, payload: Dict[str, Any]) -> Tuple[bool, str]:
        """
        Handle permission.freeze_lifted events.
        
        This method processes emergency freeze deactivation and restores
        normal permission operations.
        """
        sender = payload.get('sender', {})
        reason = payload.get('reason', 'Emergency resolved')
        
        # Verify sender has authority to lift freeze
        if not self._has_role(sender.get('login', ''), 'founder'):
            if not self._has_role(sender.get('login', ''), 'auditor'):
                return False, "Insufficient permissions to lift freeze"
        
        # Lift the freeze
        freeze_data = {
            'frozen': False,
            'lifted_at': datetime.now(timezone.utc).isoformat(),
            'lifted_by': sender.get('login', ''),
            'reason': reason,
        }
        
        self._lift_freeze(freeze_data)
        self._log_freeze_lift(freeze_data)
        
        return True, f"Emergency freeze lifted by {sender.get('login', '')}"
    
    def _handle_multisig_completed(self, payload: Dict[str, Any]) -> Tuple[bool, str]:
        """
        Handle permission.multisig_completed events.
        
        This method processes multi-signature approval completion and
        applies the approved changes.
        """
        approvals = payload.get('approvals', [])
        changes = payload.get('changes', {})
        request_id = payload.get('request_id', '')
        
        # Verify we have enough approvals
        required = self.multisig_rules.get('threshold', 2)
        if len(approvals) < required:
            return False, f"Insufficient approvals: {len(approvals)}/{required}"
        
        # Verify all approvers have required roles
        for approval in approvals:
            approver = approval.get('approver', '')
            role = approval.get('role', '')
            if not self._has_role(approver, role):
                return False, f"Approver {approver} does not have required role {role}"
        
        # Apply the approved changes
        self._apply_approved_changes(changes)
        
        # Log the completion
        self._log_multisig_completion(request_id, approvals)
        
        return True, f"Multi-sig approval completed with {len(approvals)} approvals"
    
    def _analyze_permission_changes(self, payload: Dict[str, Any]) -> List[PermissionChange]:
        """
        Analyze permission matrix changes from the webhook payload.
        
        Args:
            payload: The webhook payload
            
        Returns:
            List of PermissionChange objects representing the changes
        """
        changes = []
        sender = payload.get('sender', {}).get('login', 'unknown')
        timestamp = datetime.now(timezone.utc).isoformat()
        
        # Parse the changes from the payload
        # This is a simplified implementation - in production, 
        # you would parse the actual diff
        changed_files = payload.get('files', [])
        
        for f in changed_files:
            filename = f.get('filename', '')
            if 'role-action-matrix.json' in filename:
                # Parse the specific changes
                if 'add' in filename or 'modify' in filename:
                    # Simplified change detection
                    change = PermissionChange(
                        role='contributor',  # Would be parsed from diff
                        action='read',  # Would be parsed from diff
                        old_allowed=False,
                        new_allowed=True,
                        changed_by=sender,
                        timestamp=timestamp,
                    )
                    changes.append(change)
        
        return changes
    
    def _detect_sensitive_changes(self, changes: List[PermissionChange]) -> List[PermissionChange]:
        """
        Detect security-sensitive permission changes.
        
        Args:
            changes: List of permission changes
            
        Returns:
            List of security-sensitive changes
        """
        sensitive_changes = []
        
        for change in changes:
            # Adding founder permissions is highly sensitive
            if change.role == 'founder' and change.new_allowed:
                sensitive_changes.append(change)
            
            # Enabling delete operations for non-admin roles
            if 'delete' in change.action and change.role not in ['founder', 'admin']:
                sensitive_changes.append(change)
            
            # Modifying audit permissions
            if 'audit' in change.action and change.new_allowed:
                sensitive_changes.append(change)
        
        return sensitive_changes
    
    def _validate_permission_matrix(self) -> Tuple[bool, str]:
        """
        Validate the current permission matrix for consistency.
        
        Returns:
            Tuple of (is_valid: bool, message: str)
        """
        matrix_path = self.permission_dir / "role-action-matrix.json"
        
        if not matrix_path.exists():
            return False, "Permission matrix file not found"
        
        with open(matrix_path, 'r') as f:
            matrix = json.load(f)
        
        # Basic validation
        if 'roles' not in matrix:
            return False, "Permission matrix missing 'roles' section"
        
        required_roles = ['founder', 'auditor']
        for role in required_roles:
            if role not in matrix.get('roles', {}):
                return False, f"Permission matrix missing required role: {role}"
        
        # Check for dangerous configurations
        roles = matrix.get('roles', {})
        for role, permissions in roles.items():
            if permissions.get('can_override_audit', False) and role != 'founder':
                return False, f"Non-founder role {role} cannot override audit"
        
        return True, "Permission matrix validation passed"
    
    def _requires_multisig(self, changes: List[PermissionChange]) -> bool:
        """
        Check if the permission changes require multi-signature approval.
        
        Args:
            changes: List of permission changes
            
        Returns:
            True if multi-signature is required, False otherwise
        """
        for change in changes:
            # Founder role changes always require multi-sig
            if change.role == 'founder' and change.new_allowed:
                return True
            
            # Audit permission changes require multi-sig
            if 'audit' in change.action:
                return True
        
        return False
    
    def _has_role(self, username: str, role: str) -> bool:
        """
        Check if a user has a specific role.
        
        Args:
            username: The GitHub username
            role: The role to check
            
        Returns:
            True if the user has the role, False otherwise
        """
        matrix_path = self.permission_dir / "role-action-matrix.json"
        
        if not matrix_path.exists():
            return False
        
        with open(matrix_path, 'r') as f:
            matrix = json.load(f)
        
        user_roles = matrix.get('user_roles', {})
        return role in user_roles.get(username, [])
    
    def _initiate_multisig(self, changes: List[PermissionChange], requester: str) -> Tuple[bool, str]:
        """
        Initiate a multi-signature approval process for permission changes.
        
        Args:
            changes: List of permission changes requiring approval
            requester: The user requesting the changes
            
        Returns:
            Tuple of (initiated: bool, message: str)
        """
        request_id = f"multisig-{datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S')}"
        
        multisig_request = {
            'request_id': request_id,
            'requester': requester,
            'changes': [c.__dict__ for c in changes],
            'status': 'pending',
            'created_at': datetime.now(timezone.utc).isoformat(),
            'approvals': [],
        }
        
        # Store the request
        requests_dir = self.permission_dir / "multisig-requests"
        requests_dir.mkdir(exist_ok=True)
        
        request_file = requests_dir / f"{request_id}.json"
        with open(request_file, 'w') as f:
            json.dump(multisig_request, f, indent=2)
        
        return True, f"Multi-sig request initiated: {request_id}"
    
    def _request_additional_approval(self, changes: List[PermissionChange], requester: str) -> Tuple[bool, str]:
        """
        Request additional approval for security-sensitive changes.
        
        Args:
            changes: List of security-sensitive changes
            requester: The user requesting the changes
            
        Returns:
            Tuple of (requested: bool, message: str)
        """
        # In a real implementation, this would create a PR review request
        # or notify approvers through appropriate channels
        return True, "Additional approval requested"
    
    def _verify_freeze_approval(self, username: str) -> bool:
        """
        Verify that a user has approval to initiate a freeze.
        
        Args:
            username: The GitHub username
            
        Returns:
            True if approved, False otherwise
        """
        # Simplified implementation - in production, check against
        # freeze approval records
        return self._has_role(username, 'founder') or self._has_role(username, 'auditor')
    
    def _validate_freeze_conditions(self, reason: str) -> bool:
        """
        Validate that freeze conditions are met.
        
        Args:
            reason: The reason for the freeze
            
        Returns:
            True if conditions are met, False otherwise
        """
        if not reason or len(reason) < 10:
            return False
        
        return True
    
    def _apply_permission_changes(self, changes: List[PermissionChange]) -> None:
        """
        Apply permission changes to the permission matrix.
        
        Args:
            changes: List of permission changes to apply
        """
        matrix_path = self.permission_dir / "role-action-matrix.json"
        
        if not matrix_path.exists():
            return
        
        with open(matrix_path, 'r') as f:
            matrix = json.load(f)
        
        for change in changes:
            role = change.role
            action = change.action
            
            if role not in matrix.get('roles', {}):
                matrix['roles'][role] = {}
            
            matrix['roles'][role][action] = change.new_allowed
        
        with open(matrix_path, 'w') as f:
            json.dump(matrix, f, indent=2)
    
    def _apply_approved_changes(self, changes: Dict[str, Any]) -> None:
        """
        Apply multi-signature approved changes.
        
        Args:
            changes: The approved changes to apply
        """
        matrix_path = self.permission_dir / "role-action-matrix.json"
        
        if not matrix_path.exists():
            return
        
        with open(matrix_path, 'r') as f:
            matrix = json.load(f)
        
        # Apply the changes from the approval
        # Implementation depends on the specific change format
        matrix['last_updated'] = datetime.now(timezone.utc).isoformat()
        
        with open(matrix_path, 'w') as f:
            json.dump(matrix, f, indent=2)
    
    def _apply_freeze(self, freeze_data: Dict[str, Any]) -> None:
        """
        Apply emergency freeze to the permission system.
        
        Args:
            freeze_data: The freeze configuration
        """
        freeze_path = self.permission_dir / "freeze-status.json"
        
        with open(freeze_path, 'w') as f:
            json.dump(freeze_data, f, indent=2)
    
    def _lift_freeze(self, freeze_data: Dict[str, Any]) -> None:
        """
        Lift the emergency freeze.
        
        Args:
            freeze_data: The freeze lift configuration
        """
        freeze_path = self.permission_dir / "freeze-status.json"
        
        with open(freeze_path, 'w') as f:
            json.dump(freeze_data, f, indent=2)
    
    def _log_permission_update(self, changes: List[PermissionChange], updater: str) -> None:
        """
        Log permission updates for audit purposes.
        
        Args:
            changes: List of permission changes
            updater: The user who made the changes
        """
        log_dir = Path(self.base_path) / "governance" / "logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        
        log_entry = {
            'timestamp': datetime.now(timezone.utc).isoformat(),
            'eventType': 'permission.updated',
            'updater': updater,
            'changes': [c.__dict__ for c in changes],
        }
        
        log_file = log_dir / f"permission-update-{datetime.now().strftime('%Y%m%d')}.jsonl"
        with open(log_file, 'a') as f:
            f.write(json.dumps(log_entry) + '\n')
    
    def _log_override(self, override_log: Dict[str, Any]) -> None:
        """
        Log founder override actions.
        
        Args:
            override_log: The override log entry
        """
        log_dir = Path(self.base_path) / "governance" / "logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        
        log_file = log_dir / "override-log.jsonl"
        with open(log_file, 'a') as f:
            f.write(json.dumps(override_log) + '\n')
    
    def _request_audit(self, override_log: Dict[str, Any]) -> None:
        """
        Request audit for founder override actions.
        
        Args:
            override_log: The override log entry
        """
        # In a real implementation, this would create a ticket or notification
        audit_request = {
            'type': 'override_audit',
            'override': override_log,
            'status': 'pending',
            'created_at': datetime.now(timezone.utc).isoformat(),
        }
        
        audit_dir = Path(self.base_path) / "governance" / "audit-requests"
        audit_dir.mkdir(parents=True, exist_ok=True)
        
        audit_file = audit_dir / f"audit-{override_log.get('timestamp', '')}.json"
        with open(audit_file, 'w') as f:
            json.dump(audit_request, f, indent=2)
    
    def _log_freeze(self, freeze_data: Dict[str, Any]) -> None:
        """
        Log emergency freeze activation.
        
        Args:
            freeze_data: The freeze log entry
        """
        log_dir = Path(self.base_path) / "governance" / "logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        
        log_entry = {
            'timestamp': datetime.now(timezone.utc).isoformat(),
            'eventType': 'permission.freeze_initiated',
            **freeze_data,
        }
        
        log_file = log_dir / "freeze-log.jsonl"
        with open(log_file, 'a') as f:
            f.write(json.dumps(log_entry) + '\n')
    
    def _log_freeze_lift(self, freeze_data: Dict[str, Any]) -> None:
        """
        Log emergency freeze deactivation.
        
        Args:
            freeze_data: The freeze lift log entry
        """
        log_dir = Path(self.base_path) / "governance" / "logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        
        log_entry = {
            'timestamp': datetime.now(timezone.utc).isoformat(),
            'eventType': 'permission.freeze_lifted',
            **freeze_data,
        }
        
        log_file = log_dir / "freeze-log.jsonl"
        with open(log_file, 'a') as f:
            f.write(json.dumps(log_entry) + '\n')
    
    def _log_multisig_completion(self, request_id: str, approvals: List[Dict[str, Any]]) -> None:
        """
        Log multi-signature completion.
        
        Args:
            request_id: The multi-signature request ID
            approvals: List of approval records
        """
        log_dir = Path(self.base_path) / "governance" / "logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        
        log_entry = {
            'timestamp': datetime.now(timezone.utc).isoformat(),
            'eventType': 'permission.multisig_completed',
            'request_id': request_id,
            'approvals': approvals,
        }
        
        log_file = log_dir / "multisig-log.jsonl"
        with open(log_file, 'a') as f:
            f.write(json.dumps(log_entry) + '\n')


def route_permission_event(event_type: str, payload: Dict[str, Any]) -> Tuple[bool, str]:
    """
    Route a permission event to the appropriate handler.
    
    This is the main entry point for permission event handling in the webhook system.
    
    Args:
        event_type: The type of GitHub event
        payload: The webhook payload
        
    Returns:
        Tuple of (success: bool, message: str)
    """
    handler = PermissionUpdateHandler()
    return handler.handle_event(event_type, payload)


if __name__ == '__main__':
    import sys
    
    if len(sys.argv) < 3:
        print("Usage: python permission-update-handler.py <event_type> <payload_file>")
        sys.exit(1)
    
    event_type = sys.argv[1]
    payload_file = sys.argv[2]
    
    with open(payload_file, 'r') as f:
        payload = json.load(f)
    
    success, message = route_permission_event(event_type, payload)
    print(f"Result: {'Success' if success else 'Failure'} - {message}")
    
    sys.exit(0 if success else 1)
