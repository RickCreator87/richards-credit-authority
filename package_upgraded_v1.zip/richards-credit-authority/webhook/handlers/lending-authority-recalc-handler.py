"""
Lending Authority Recalculation Handler for Personal Credit Authority Webhook System

This handler processes financial data changes and recalculates lending authority
based on the tax-first governance principles. It ensures that all lending
decisions account for tax obligations before determining available credit.

Events Handled:
- authority.recalc_requested: Triggered when lending authority needs recalculation
- income.changed: Triggered when income data is updated
- assets.changed: Triggered when asset data is modified
- liabilities.changed: Triggered when liability data changes
- tax.updated: Triggered when tax information is updated

Author: MiniMax Agent
Version: 1.0.0
"""

import json
import os
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Any, Optional, Tuple, List
from dataclasses import dataclass, field
from decimal import Decimal, ROUND_HALF_UP


@dataclass
class FinancialSnapshot:
    """Represents a snapshot of financial data for lending calculations."""
    gross_income: Decimal = Decimal('0')
    net_income: Decimal = Decimal('0')
    assets: Decimal = Decimal('0')
    liabilities: Decimal = Decimal('0')
    tax_obligations: Decimal = Decimal('0')
    disposable_income: Decimal = Decimal('0')


@dataclass
class LendingCalculation:
    """Represents the result of a lending authority calculation."""
    max_lending_capacity: Decimal
    loan_to_income_ratio: Decimal
    loan_to_tax_ratio: Decimal
    risk_tier: str
    calculation_timestamp: str
    factors_used: Dict[str, Any] = field(default_factory=dict)


class LendingAuthorityRecalcHandler:
    """
    Handles recalculation of lending authority based on financial data changes.
    
    This class implements the tax-first governance principles by ensuring that
    all lending capacity calculations first account for tax obligations before
    determining available credit.
    """
    
    def __init__(self, base_path: Optional[str] = None):
        """
        Initialize the Lending Authority Recalculation Handler.
        
        Args:
            base_path: Base directory path for the repository (defaults to current directory)
        """
        self.base_path = base_path or os.getcwd()
        self.authority_dir = Path(self.base_path) / "authority"
        self.identity_dir = Path(self.base_path) / "identity"
        self.governance_dir = Path(self.base_path) / "governance"
        
        # Load rules and configurations
        self.risk_tiers = self._load_risk_tiers()
        self.lti_rules = self._load_lti_rules()
        self.ltt_rules = self._load_ltt_rules()
        self.annual_limits = self._load_annual_limits()
        self.tax_first_rules = self._load_tax_first_rules()
        
    def _load_risk_tiers(self) -> Dict[str, Any]:
        """Load risk tier definitions."""
        rules_path = self.authority_dir / "rules" / "risk-tier-definitions.json"
        if rules_path.exists():
            with open(rules_path, 'r') as f:
                return json.load(f)
        return {'tiers': []}
    
    def _load_lti_rules(self) -> Dict[str, Any]:
        """Load loan-to-income rules."""
        rules_path = self.authority_dir / "rules" / "loan-to-income-rules.json"
        if rules_path.exists():
            with open(rules_path, 'r') as f:
                return json.load(f)
        return {'max_lti_ratio': Decimal('4.0')}
    
    def _load_ltt_rules(self) -> Dict[str, Any]:
        """Load loan-to-tax rules."""
        rules_path = self.authority_dir / "rules" / "loan-to-tax-rules.json"
        if rules_path.exists():
            with open(rules_path, 'r') as f:
                return json.load(f)
        return {'max_ltt_ratio': Decimal('0.5')}
    
    def _load_annual_limits(self) -> Dict[str, Any]:
        """Load annual lending limits."""
        limits_path = self.authority_dir / "rules" / "annual-lending-limit.json"
        if limits_path.exists():
            with open(limits_path, 'r') as f:
                return json.load(f)
        return {'max_annual_lending': Decimal('1000000')}
    
    def _load_tax_first_rules(self) -> Dict[str, Any]:
        """Load tax-first governance rules."""
        rules_path = self.governance_dir / "tax-first-governance-rules.json"
        if rules_path.exists():
            with open(rules_path, 'r') as f:
                return json.load(f)
        return {'tax_priority_weight': Decimal('1.0')}
    
    def handle_event(self, event_type: str, payload: Dict[str, Any]) -> Tuple[bool, str]:
        """
        Main entry point for handling lending authority-related webhook events.
        
        Args:
            event_type: The type of GitHub event
            payload: The GitHub webhook payload
            
        Returns:
            Tuple of (success: bool, message: str)
        """
        handlers = {
            'authority.recalc_requested': self._handle_recalc_requested,
            'income.changed': self._handle_income_changed,
            'assets.changed': self._handle_assets_changed,
            'liabilities.changed': self._handle_liabilities_changed,
            'tax.updated': self._handle_tax_updated,
        }
        
        handler = handlers.get(event_type)
        if not handler:
            return False, f"No handler found for event type: {event_type}"
        
        try:
            return handler(payload)
        except Exception as e:
            return False, f"Error handling lending authority event: {str(e)}"
    
    def _handle_recalc_requested(self, payload: Dict[str, Any]) -> Tuple[bool, str]:
        """
        Handle authority.recalc_requested events.
        
        This method performs a full recalculation of lending authority based on
        current financial data and governance rules.
        """
        sender = payload.get('sender', {}).get('login', 'unknown')
        reason = payload.get('reason', 'Manual recalculation request')
        
        # Get current financial data
        financial_data = self._gather_financial_data()
        
        # Perform the calculation
        calculation = self._calculate_lending_authority(financial_data)
        
        # Validate the calculation
        validation = self._validate_calculation(calculation)
        if not validation[0]:
            return validation
        
        # Apply the new authority
        self._apply_lending_authority(calculation)
        
        # Log the recalculation
        self._log_recalculation(calculation, sender, reason)
        
        return True, f"Lending authority recalculated: {calculation.max_lending_capacity} (Risk Tier: {calculation.risk_tier})"
    
    def _handle_income_changed(self, payload: Dict[str, Any]) -> Tuple[bool, str]:
        """
        Handle income.changed events.
        
        This method processes income changes and triggers lending authority
        recalculation with the updated income data.
        """
        changes = payload.get('changes', {})
        sender = payload.get('sender', {}).get('login', 'unknown')
        
        # Update income data
        self._update_income_data(changes)
        
        # Trigger recalculation
        return self._handle_recalc_requested({
            'sender': payload.get('sender', {}),
            'reason': f'Income data updated by {sender}',
        })
    
    def _handle_assets_changed(self, payload: Dict[str, Any]) -> Tuple[bool, str]:
        """
        Handle assets.changed events.
        
        This method processes asset changes and triggers lending authority
        recalculation with the updated asset data.
        """
        changes = payload.get('changes', {})
        sender = payload.get('sender', {}).get('login', 'unknown')
        
        # Update asset data
        self._update_assets_data(changes)
        
        # Trigger recalculation
        return self._handle_recalc_requested({
            'sender': payload.get('sender', {}),
            'reason': f'Asset data updated by {sender}',
        })
    
    def _handle_liabilities_changed(self, payload: Dict[str, Any]) -> Tuple[bool, str]:
        """
        Handle liabilities.changed events.
        
        This method processes liability changes and triggers lending authority
        recalculation with the updated liability data.
        """
        changes = payload.get('changes', {})
        sender = payload.get('sender', {}).get('login', 'unknown')
        
        # Update liability data
        self._update_liabilities_data(changes)
        
        # Trigger recalculation
        return self._handle_recalc_requested({
            'sender': payload.get('sender', {}),
            'reason': f'Liability data updated by {sender}',
        })
    
    def _handle_tax_updated(self, payload: Dict[str, Any]) -> Tuple[bool, str]:
        """
        Handle tax.updated events.
        
        This method processes tax obligation updates and triggers lending
        authority recalculation with the updated tax data. This is critical
        for maintaining the tax-first governance principle.
        """
        changes = payload.get('changes', {})
        sender = payload.get('sender', {}).get('login', 'unknown')
        
        # Update tax data
        self._update_tax_data(changes)
        
        # Trigger recalculation
        return self._handle_recalc_requested({
            'sender': payload.get('sender', {}),
            'reason': f'Tax data updated by {sender}',
        })
    
    def _gather_financial_data(self) -> FinancialSnapshot:
        """
        Gather current financial data from all relevant sources.
        
        Returns:
            FinancialSnapshot containing all relevant financial data
        """
        snapshot = FinancialSnapshot()
        
        # Get identity for tax information
        identity_path = self.identity_dir / "identity-manifest.json"
        if identity_path.exists():
            with open(identity_path, 'r') as f:
                identity = json.load(f)
            
            # Extract tax information
            tax_info = identity.get('taxInformation', {})
            snapshot.tax_obligations = Decimal(str(tax_info.get('estimated_annual_tax', 0)))
        
        # Get financial data from authority data file
        data_path = self.authority_dir / "authority-data.json"
        if data_path.exists():
            with open(data_path, 'r') as f:
                data = json.load(f)
            
            snapshot.gross_income = Decimal(str(data.get('gross_annual_income', 0)))
            snapshot.net_income = Decimal(str(data.get('net_annual_income', 0)))
            snapshot.assets = Decimal(str(data.get('total_assets', 0)))
            snapshot.liabilities = Decimal(str(data.get('total_liabilities', 0)))
        
        # Calculate disposable income (net income minus tax obligations)
        snapshot.disposable_income = snapshot.net_income - snapshot.tax_obligations
        
        # Ensure non-negative disposable income
        if snapshot.disposable_income < Decimal('0'):
            snapshot.disposable_income = Decimal('0')
        
        return snapshot
    
    def _calculate_lending_authority(self, financial: FinancialSnapshot) -> LendingCalculation:
        """
        Calculate lending authority based on financial data and governance rules.
        
        This method implements the tax-first governance principle by:
        1. First accounting for tax obligations
        2. Calculating disposable income
        3. Applying loan-to-income ratio limits
        4. Applying loan-to-tax ratio limits
        5. Determining risk tier
        6. Applying annual limits
        
        Args:
            financial: The current financial snapshot
            
        Returns:
            LendingCalculation containing the calculated lending authority
        """
        factors = {}
        
        # Step 1: Calculate Loan-to-Income (LTI) based capacity
        max_lti = self.lti_rules.get('max_lti_ratio', Decimal('4.0'))
        lti_capacity = financial.net_income * max_lti
        factors['lti_capacity'] = str(lti_capacity)
        factors['lti_ratio_used'] = str(max_lti)
        
        # Step 2: Calculate Loan-to-Tax (LTT) based capacity
        # This ensures we don't lend more than a reasonable multiple of tax obligations
        max_ltt = self.ltt_rules.get('max_ltt_ratio', Decimal('0.5'))
        if financial.tax_obligations > Decimal('0'):
            ltt_capacity = financial.tax_obligations * max_ltt
        else:
            # If no tax obligations, use a conservative default
            ltt_capacity = financial.net_income * Decimal('0.1')
        factors['ltt_capacity'] = str(ltt_capacity)
        factors['ltt_ratio_used'] = str(max_ltt)
        
        # Step 3: Apply tax-first principle - capacity is limited by LTT if LTI is higher
        # This ensures tax obligations are always covered
        base_capacity = min(lti_capacity, ltt_capacity * Decimal('10'))  # Allow some multiplier
        factors['base_capacity_after_tax_first'] = str(base_capacity)
        
        # Step 4: Adjust for risk tier
        risk_tier = self._determine_risk_tier(financial)
        risk_adjustment = self._get_risk_adjustment(risk_tier)
        adjusted_capacity = base_capacity * risk_adjustment
        factors['risk_tier'] = risk_tier
        factors['risk_adjustment'] = str(risk_adjustment)
        
        # Step 5: Apply annual limits
        annual_limit = Decimal(str(self.annual_limits.get('max_annual_lending', Decimal('1000000'))))
        final_capacity = min(adjusted_capacity, annual_limit)
        factors['annual_limit'] = str(annual_limit)
        factors['limit_applied'] = str(adjusted_capacity > annual_limit)
        
        # Step 6: Calculate ratios for reporting
        if financial.net_income > Decimal('0'):
            loan_to_income = final_capacity / financial.net_income
        else:
            loan_to_income = Decimal('0')
        
        if financial.tax_obligations > Decimal('0'):
            loan_to_tax = final_capacity / financial.tax_obligations
        else:
            loan_to_tax = Decimal('0')
        
        return LendingCalculation(
            max_lending_capacity=final_capacity.quantize(Decimal('0.01'), rounding=ROUND_HALF_UP),
            loan_to_income_ratio=loan_to_income.quantize(Decimal('0.01'), rounding=ROUND_HALF_UP),
            loan_to_tax_ratio=loan_to_tax.quantize(Decimal('0.01'), rounding=ROUND_HALF_UP),
            risk_tier=risk_tier,
            calculation_timestamp=datetime.now(timezone.utc).isoformat(),
            factors_used=factors,
        )
    
    def _determine_risk_tier(self, financial: FinancialSnapshot) -> str:
        """
        Determine the risk tier based on financial data.
        
        Args:
            financial: The current financial snapshot
            
        Returns:
            Risk tier identifier
        """
        # Calculate debt-to-income ratio
        if financial.net_income > Decimal('0'):
            dti_ratio = financial.liabilities / financial.net_income
        else:
            dti_ratio = Decimal('999')  # Very high risk
        
        # Check against tier criteria
        tiers = self.risk_tiers.get('riskTiers', [])
        
        for tier in sorted(tiers, key=lambda t: t.get('tierId', '')):
            criteria = tier.get('criteria', {})
            
            # Check DTI ratio
            dti_max = criteria.get('debtToIncomeRatio', {}).get('max', Decimal('999'))
            if dti_ratio <= dti_max:
                return tier.get('tierId', 'T5_HIGH_RISK')
        
        # Default to highest risk tier
        return 'T5_HIGH_RISK'
    
    def _get_risk_adjustment(self, risk_tier: str) -> Decimal:
        """
        Get the capacity adjustment factor for a risk tier.
        
        Args:
            risk_tier: The risk tier identifier
            
        Returns:
            Decimal adjustment factor (e.g., 1.0 for no adjustment, 0.8 for 20% reduction)
        """
        tier_adjustments = {
            'T1_PRIME_PLUS': Decimal('1.0'),
            'T2_PRIME': Decimal('0.95'),
            'T3_SUBPRIME': Decimal('0.85'),
            'T4_DEEP_SUBPRIME': Decimal('0.7'),
            'T5_HIGH_RISK': Decimal('0.5'),
        }
        
        return tier_adjustments.get(risk_tier, Decimal('0.5'))
    
    def _validate_calculation(self, calculation: LendingCalculation) -> Tuple[bool, str]:
        """
        Validate a lending authority calculation.
        
        Args:
            calculation: The calculation to validate
            
        Returns:
            Tuple of (is_valid: bool, message: str)
        """
        # Check for negative capacity
        if calculation.max_lending_capacity < Decimal('0'):
            return False, "Lending capacity cannot be negative"
        
        # Check for reasonable LTI ratio
        if calculation.loan_to_income_ratio > Decimal('10'):
            return False, "Loan-to-income ratio exceeds maximum allowed"
        
        # Check for reasonable LTT ratio
        if calculation.loan_to_tax_ratio > Decimal('5'):
            return False, "Loan-to-tax ratio exceeds maximum allowed"
        
        return True, "Calculation validation passed"
    
    def _apply_lending_authority(self, calculation: LendingCalculation) -> None:
        """
        Apply the calculated lending authority to the authority data file.
        
        Args:
            calculation: The validated lending authority calculation
        """
        authority_path = self.authority_dir / "authority-data.json"
        
        # Load existing data or create new
        if authority_path.exists():
            with open(authority_path, 'r') as f:
                authority_data = json.load(f)
        else:
            authority_data = {}
        
        # Update with new calculation
        authority_data['max_lending_capacity'] = str(calculation.max_lending_capacity)
        authority_data['loan_to_income_ratio'] = str(calculation.loan_to_income_ratio)
        authority_data['loan_to_tax_ratio'] = str(calculation.loan_to_tax_ratio)
        authority_data['risk_tier'] = calculation.risk_tier
        authority_data['last_calculation_timestamp'] = calculation.calculation_timestamp
        authority_data['calculation_factors'] = calculation.factors_used
        authority_data['last_updated'] = datetime.now(timezone.utc).isoformat()
        
        # Write updated data
        with open(authority_path, 'w') as f:
            json.dump(authority_data, f, indent=2)
    
    def _update_income_data(self, changes: Dict[str, Any]) -> None:
        """
        Update income data from changes.
        
        Args:
            changes: Dictionary of income changes
        """
        data_path = self.authority_dir / "authority-data.json"
        
        if data_path.exists():
            with open(data_path, 'r') as f:
                data = json.load(f)
        else:
            data = {}
        
        if 'gross_income' in changes:
            data['gross_annual_income'] = str(changes['gross_income'])
        
        if 'net_income' in changes:
            data['net_annual_income'] = str(changes['net_income'])
        
        with open(data_path, 'w') as f:
            json.dump(data, f, indent=2)
    
    def _update_assets_data(self, changes: Dict[str, Any]) -> None:
        """
        Update asset data from changes.
        
        Args:
            changes: Dictionary of asset changes
        """
        data_path = self.authority_dir / "authority-data.json"
        
        if data_path.exists():
            with open(data_path, 'r') as f:
                data = json.load(f)
        else:
            data = {}
        
        if 'total_assets' in changes:
            data['total_assets'] = str(changes['total_assets'])
        
        with open(data_path, 'w') as f:
            json.dump(data, f, indent=2)
    
    def _update_liabilities_data(self, changes: Dict[str, Any]) -> None:
        """
        Update liability data from changes.
        
        Args:
            changes: Dictionary of liability changes
        """
        data_path = self.authority_dir / "authority-data.json"
        
        if data_path.exists():
            with open(data_path, 'r') as f:
                data = json.load(f)
        else:
            data = {}
        
        if 'total_liabilities' in changes:
            data['total_liabilities'] = str(changes['total_liabilities'])
        
        with open(data_path, 'w') as f:
            json.dump(data, f, indent=2)
    
    def _update_tax_data(self, changes: Dict[str, Any]) -> None:
        """
        Update tax data from changes.
        
        Args:
            changes: Dictionary of tax changes
        """
        identity_path = self.identity_dir / "identity-manifest.json"
        
        if identity_path.exists():
            with open(identity_path, 'r') as f:
                identity = json.load(f)
            
            if 'taxInformation' not in identity:
                identity['taxInformation'] = {}
            
            if 'estimated_annual_tax' in changes:
                identity['taxInformation']['estimated_annual_tax'] = str(changes['estimated_annual_tax'])
            
            with open(identity_path, 'w') as f:
                json.dump(identity, f, indent=2)
    
    def _log_recalculation(self, calculation: LendingCalculation, requester: str, reason: str) -> None:
        """
        Log lending authority recalculation.
        
        Args:
            calculation: The calculation that was performed
            requester: The user who requested the recalculation
            reason: The reason for recalculation
        """
        log_dir = Path(self.base_path) / "governance" / "logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        
        log_entry = {
            'timestamp': datetime.now(timezone.utc).isoformat(),
            'eventType': 'authority.recalculated',
            'requester': requester,
            'reason': reason,
            'result': {
                'max_lending_capacity': str(calculation.max_lending_capacity),
                'loan_to_income_ratio': str(calculation.loan_to_income_ratio),
                'loan_to_tax_ratio': str(calculation.loan_to_tax_ratio),
                'risk_tier': calculation.risk_tier,
                'factors': calculation.factors_used,
            },
        }
        
        log_file = log_dir / f"authority-recalc-{datetime.now().strftime('%Y%m%d')}.jsonl"
        with open(log_file, 'a') as f:
            f.write(json.dumps(log_entry) + '\n')


def route_lending_event(event_type: str, payload: Dict[str, Any]) -> Tuple[bool, str]:
    """
    Route a lending authority event to the appropriate handler.
    
    This is the main entry point for lending authority event handling in the webhook system.
    
    Args:
        event_type: The type of GitHub event
        payload: The webhook payload
        
    Returns:
        Tuple of (success: bool, message: str)
    """
    handler = LendingAuthorityRecalcHandler()
    return handler.handle_event(event_type, payload)


if __name__ == '__main__':
    import sys
    
    if len(sys.argv) < 3:
        print("Usage: python lending-authority-recalc-handler.py <event_type> <payload_file>")
        sys.exit(1)
    
    event_type = sys.argv[1]
    payload_file = sys.argv[2]
    
    with open(payload_file, 'r') as f:
        payload = json.load(f)
    
    success, message = route_lending_event(event_type, payload)
    print(f"Result: {'Success' if success else 'Failure'} - {message}")
    
    sys.exit(0 if success else 1)
