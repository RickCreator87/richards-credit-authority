"""
Identity Sync Handler for Personal Credit Authority Webhook System

This handler is responsible for processing identity-related events from GitHub,
validating identity updates, and synchronizing the identity authority state
across the system.

Events Handled:
- identity.updated: Triggered when the identity manifest is modified
- identity.verified: Triggered when identity verification status changes
- identity.proof_generated: Triggered when a new identity proof is created

Author: MiniMax Agent
Version: 1.0.0
"""

import json
import hashlib
import os
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Any, Optional, Tuple

# Add parent directory to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from authority.schema.lending_authority import LendingAuthority
from authority.rules.lending_formulas import LendingFormulas
from identity.schema.identity_schema import IdentitySchema


class IdentitySyncHandler:
    """
    Handles synchronization of identity changes across the Personal Credit Authority.
    
    This class provides comprehensive identity synchronization capabilities including
    validation of identity updates, propagation of changes to dependent systems,
    and maintenance of identity proof consistency.
    """
    
    def __init__(self, base_path: Optional[str] = None):
        """
        Initialize the Identity Sync Handler.
        
        Args:
            base_path: Base directory path for the repository (defaults to current directory)
        """
        self.base_path = base_path or os.getcwd()
        self.identity_dir = Path(self.base_path) / "identity"
        self.authority_dir = Path(self.base_path) / "authority"
        self.schema_dir = Path(self.base_path) / "authority" / "schema"
        
        # Load the identity schema for validation
        self.identity_schema = self._load_identity_schema()
        self.lending_schema = self._load_lending_schema()
        
    def _load_identity_schema(self) -> Dict[str, Any]:
        """Load the identity schema from the schema directory."""
        schema_path = self.schema_dir / "identity.schema.json"
        if schema_path.exists():
            with open(schema_path, 'r') as f:
                return json.load(f)
        return {}
    
    def _load_lending_schema(self) -> Dict[str, Any]:
        """Load the lending authority schema."""
        schema_path = self.schema_dir / "lending-authority.schema.json"
        if schema_path.exists():
            with open(schema_path, 'r') as f:
                return json.load(f)
        return {}
    
    def handle_event(self, event_type: str, payload: Dict[str, Any]) -> Tuple[bool, str]:
        """
        Main entry point for handling identity-related webhook events.
        
        Args:
            event_type: The type of GitHub event (e.g., 'identity.updated')
            payload: The GitHub webhook payload
            
        Returns:
            Tuple of (success: bool, message: str)
        """
        handlers = {
            'identity.updated': self._handle_identity_updated,
            'identity.verified': self._handle_identity_verified,
            'identity.proof_generated': self._handle_identity_proof_generated,
        }
        
        handler = handlers.get(event_type)
        if not handler:
            return False, f"No handler found for event type: {event_type}"
        
        try:
            return handler(payload)
        except Exception as e:
            return False, f"Error handling identity event: {str(e)}"
    
    def _handle_identity_updated(self, payload: Dict[str, Any]) -> Tuple[bool, str]:
        """
        Handle identity.updated events.
        
        This method validates the updated identity, checks for consistency
        with existing authority settings, and triggers recalculation of
        lending capacity if necessary.
        """
        changes = payload.get('changes', {})
        sender = payload.get('sender', {}).get('login', 'unknown')
        
        # Get the modified file path
        files = payload.get('files', [])
        identity_file = None
        for f in files:
            if 'identity-manifest.json' in f.get('filename', ''):
                identity_file = f
                break
        
        if not identity_file:
            return False, "No identity manifest file found in changes"
        
        # Read the updated identity manifest
        identity_path = self.identity_dir / "identity-manifest.json"
        if not identity_path.exists():
            return False, "Identity manifest file not found"
        
        with open(identity_path, 'r') as f:
            updated_identity = json.load(f)
        
        # Validate the updated identity against schema
        validation_result = self._validate_identity(updated_identity)
        if not validation_result[0]:
            return validation_result
        
        # Check if changes require authority recalculation
        recalc_required = self._check_recalc_required(changes)
        
        # Generate new identity proof if personal data changed
        proof_updated = False
        if any(key in changes for key in ['legalName', 'dateOfBirth', 'taxId']):
            proof_updated = self._generate_identity_proof()
        
        # Log the identity update
        self._log_identity_update(updated_identity, sender, changes)
        
        if proof_updated:
            return True, f"Identity updated by {sender}, new proof generated, authority recalculation {'required' if recalc_required else 'not required'}"
        else:
            return True, f"Identity updated by {sender}, authority recalculation {'required' if recalc_required else 'not required'}"
    
    def _handle_identity_verified(self, payload: Dict[str, Any]) -> Tuple[bool, str]:
        """
        Handle identity.verified events.
        
        This method processes identity verification status changes and
        updates the authority configuration accordingly.
        """
        action = payload.get('action', '')
        sender = payload.get('sender', {})
        
        identity_path = self.identity_dir / "identity-manifest.json"
        if not identity_path.exists():
            return False, "Identity manifest not found"
        
        with open(identity_path, 'r') as f:
            identity = json.load(f)
        
        if action == 'verified':
            identity['verification']['status'] = 'verified'
            identity['verification']['verifiedAt'] = datetime.now(timezone.utc).isoformat()
            identity['verification']['verifiedBy'] = sender.get('login', 'unknown')
            
            with open(identity_path, 'w') as f:
                json.dump(identity, f, indent=2)
            
            return True, f"Identity verified by {sender.get('login', 'unknown')}"
        
        elif action == 'revoked':
            identity['verification']['status'] = 'unverified'
            identity['verification']['revokedAt'] = datetime.now(timezone.utc).isoformat()
            identity['verification']['revokedBy'] = sender.get('login', 'unknown')
            
            with open(identity_path, 'w') as f:
                json.dump(identity, f, indent=2)
            
            return True, f"Identity verification revoked by {sender.get('login', 'unknown')}"
        
        return False, f"Unknown verification action: {action}"
    
    def _handle_identity_proof_generated(self, payload: Dict[str, Any]) -> Tuple[bool, str]:
        """
        Handle identity.proof_generated events.
        
        This method validates newly generated identity proofs and
        updates the proof file.
        """
        sender = payload.get('sender', {})
        files = payload.get('files', [])
        
        proof_file = None
        for f in files:
            if 'identity-proof.hash' in f.get('filename', ''):
                proof_file = f
                break
        
        if not proof_file:
            return False, "No identity proof file found in changes"
        
        # Validate the proof against current identity
        proof_path = self.identity_dir / "identity-proof.hash"
        if not proof_path.exists():
            return False, "Identity proof file not found"
        
        with open(proof_path, 'r') as f:
            new_proof = f.read().strip()
        
        # Verify the proof
        identity_path = self.identity_dir / "identity-manifest.json"
        with open(identity_path, 'r') as f:
            identity = json.load(f)
        
        expected_proof = self._compute_identity_proof(identity)
        if new_proof != expected_proof:
            return False, "Identity proof does not match current identity manifest"
        
        return True, f"Identity proof validated by {sender.get('login', 'unknown')}"
    
    def _validate_identity(self, identity: Dict[str, Any]) -> Tuple[bool, str]:
        """
        Validate an identity object against the identity schema.
        
        Args:
            identity: The identity object to validate
            
        Returns:
            Tuple of (is_valid: bool, message: str)
        """
        if not self.identity_schema:
            return True, "No schema available for validation"
        
        # Basic validation (in production, use jsonschema library)
        required_fields = ['identityId', 'schemaVersion', 'identityType', 'legalName', 
                          'residency', 'taxInformation', 'verification']
        
        for field in required_fields:
            if field not in identity:
                return False, f"Missing required field: {field}"
        
        # Validate residency structure
        residency_required = ['country', 'address']
        for field in residency_required:
            if field not in identity.get('residency', {}):
                return False, f"Missing required residency field: {field}"
        
        # Validate tax information
        tax_required = ['taxId', 'taxResidency']
        for field in tax_required:
            if field not in identity.get('taxInformation', {}):
                return False, f"Missing required tax field: {field}"
        
        return True, "Identity validation passed"
    
    def _check_recalc_required(self, changes: Dict[str, Any]) -> bool:
        """
        Check if identity changes require lending authority recalculation.
        
        Args:
            changes: Dictionary of changes from the webhook payload
            
        Returns:
            True if recalculation is required, False otherwise
        """
        # Financial changes always require recalculation
        financial_fields = ['income', 'assets', 'liabilities', 'taxObligations']
        
        for field in financial_fields:
            if field in changes:
                return True
        
        # Address changes for tax residency may require recalculation
        if 'residency' in changes:
            return True
        
        # Name and contact changes don't require financial recalculation
        return False
    
    def _generate_identity_proof(self) -> bool:
        """
        Generate a new identity proof hash.
        
        Returns:
            True if proof was generated successfully, False otherwise
        """
        identity_path = self.identity_dir / "identity-manifest.json"
        proof_path = self.identity_dir / "identity-proof.hash"
        
        if not identity_path.exists():
            return False
        
        with open(identity_path, 'r') as f:
            identity = json.load(f)
        
        proof = self._compute_identity_proof(identity)
        
        with open(proof_path, 'w') as f:
            f.write(proof)
        
        return True
    
    def _compute_identity_proof(self, identity: Dict[str, Any]) -> str:
        """
        Compute the identity proof hash from an identity object.
        
        The proof is computed from a canonical representation of the identity
        to ensure consistent hashing.
        
        Args:
            identity: The identity object
            
        Returns:
            The computed proof hash
        """
        # Create a canonical representation for hashing
        canonical = {
            'identityId': identity.get('identityId', ''),
            'legalName': identity.get('legalName', {}),
            'dateOfBirth': identity.get('dateOfBirth', ''),
            'taxId': identity.get('taxInformation', {}).get('taxId', ''),
            'taxResidency': identity.get('taxInformation', {}).get('taxResidency', ''),
        }
        
        canonical_json = json.dumps(canonical, sort_keys=True)
        return hashlib.sha256(canonical_json.encode()).hexdigest()
    
    def _log_identity_update(self, identity: Dict[str, Any], updater: str, changes: Dict[str, Any]) -> None:
        """
        Log an identity update event.
        
        Args:
            identity: The updated identity object
            updater: The username of the person who made the update
            changes: Dictionary of changes made
        """
        log_dir = Path(self.base_path) / "governance" / "logs"
        log_dir.mkdir(parents=True, exist_ok=True)
        
        timestamp = datetime.now(timezone.utc).isoformat()
        log_entry = {
            'timestamp': timestamp,
            'eventType': 'identity.updated',
            'updater': updater,
            'identityId': identity.get('identityId', ''),
            'changes': changes,
        }
        
        log_file = log_dir / f"identity-update-{datetime.now().strftime('%Y%m%d')}.jsonl"
        with open(log_file, 'a') as f:
            f.write(json.dumps(log_entry) + '\n')


def route_identity_event(event_type: str, payload: Dict[str, Any]) -> Tuple[bool, str]:
    """
    Route an identity event to the appropriate handler.
    
    This is the main entry point for identity event handling in the webhook system.
    
    Args:
        event_type: The type of GitHub event
        payload: The webhook payload
        
    Returns:
        Tuple of (success: bool, message: str)
    """
    handler = IdentitySyncHandler()
    return handler.handle_event(event_type, payload)


if __name__ == '__main__':
    import sys
    
    if len(sys.argv) < 3:
        print("Usage: python identity-sync-handler.py <event_type> <payload_file>")
        sys.exit(1)
    
    event_type = sys.argv[1]
    payload_file = sys.argv[2]
    
    with open(payload_file, 'r') as f:
        payload = json.load(f)
    
    success, message = route_identity_event(event_type, payload)
    print(f"Result: {'Success' if success else 'Failure'} - {message}")
    
    sys.exit(0 if success else 1)
