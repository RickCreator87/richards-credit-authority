# Personal Credit Authority Webhook System

This directory contains the webhook infrastructure for the Personal Credit Authority system. The webhook system enables automated synchronization between GitHub events and the authority's internal state, implementing the tax-first governance principles through event-driven architecture.

## Architecture Overview

The webhook system is designed as an event-driven architecture that responds to GitHub webhook events and processes them according to predefined rules. When events occur in the repository—such as changes to identity files, permission matrices, or financial data—the webhook handlers automatically validate the changes, enforce governance rules, and update the authority's state accordingly.

The system consists of several interconnected components that work together to maintain the integrity of the Personal Credit Authority. The main entry point receives incoming HTTP requests from GitHub, verifies their authenticity using signature validation, and routes them to appropriate event handlers based on the event type. Each handler is specialized for a specific domain: identity synchronization, permission updates, and lending authority recalculation. This separation of concerns allows for maintainable and testable code while ensuring that complex governance rules are applied consistently across all operations.

The event routing mechanism uses a modular design where new event types can be added by implementing handlers and registering them in the router. This extensibility is crucial for adapting the system to future requirements while maintaining backward compatibility with existing workflows.

## Components

### Server Entry Point

The webhook server is implemented as a Python HTTP server that listens for incoming webhook deliveries from GitHub. The server is responsible for handling the HTTP endpoint configuration, managing request parsing, and delegating processing to the appropriate handlers. It supports both synchronous and asynchronous processing modes, allowing for flexible handling of different event types based on their processing requirements.

The server configuration includes environment-based settings for port binding, SSL/TLS configuration, and secret management. This approach allows for containerized deployments and cloud-native configurations while maintaining security through proper secret management practices.

### Signature Verification

Security is paramount in the webhook system, and the signature verification component ensures that all incoming requests originate from GitHub and have not been tampered with during transit. The verification process uses HMAC-SHA256 signatures computed using a shared secret that is configured in both GitHub and the webhook server. This shared secret is unique to each GitHub App installation and should be stored securely using environment variables or a secrets management system.

The verification process involves extracting the signature from the request headers, computing the expected signature from the request body, and comparing the two values using a constant-time comparison function to prevent timing attacks. If verification fails, the request is rejected with an appropriate HTTP status code, and the event is logged for security auditing purposes.

### Event Router

The event router serves as the central dispatch mechanism for all webhook events. It examines the event type from the request headers, loads the appropriate handler module, and routes the event payload to that handler for processing. The router also handles error cases gracefully, returning meaningful error messages and logging failures for troubleshooting.

The router implements a plugin-style architecture where handlers can be registered with priority levels and optional filters. This allows for sophisticated event processing pipelines where multiple handlers might respond to a single event, with each handler focusing on a specific aspect of the processing.

### Event Handlers

The webhook system includes three primary event handlers, each responsible for a distinct domain within the Personal Credit Authority. The identity sync handler processes identity-related events such as updates to identity manifests, verification status changes, and identity proof generation. It ensures that identity changes are properly validated, proof hashes are maintained, and dependent systems are notified of identity updates.

The permission update handler manages permission matrix changes, founder overrides, emergency freezes, and multi-signature approvals. It implements the complex rules governing who can perform what actions, including the multi-signature requirements for sensitive changes and the emergency freeze mechanisms for security incidents. This handler is critical for maintaining the security posture of the authority.

The lending authority recalculation handler responds to financial data changes and computes lending capacity based on the tax-first governance principles. It gathers financial data from multiple sources, applies the loan-to-income and loan-to-tax rules, adjusts for risk tier, and enforces annual limits. This handler ensures that lending capacity calculations are always current and consistent with the governance rules.

## Event Types Supported

The webhook system supports a comprehensive set of event types that cover all aspects of the Personal Credit Authority operations. Identity events include `identity.updated` for manifest changes, `identity.verified` for verification status changes, and `identity.proof_generated` for proof hash updates. These events ensure that identity data remains consistent and verifiable across all systems.

Permission events encompass `permission.updated` for matrix modifications, `permission.override_used` for founder override actions, `permission.freeze_initiated` and `permission.freeze_lifted` for emergency control, and `permission.multisig_completed` for approval workflows. These events implement the sophisticated access control model defined in the governance rules.

Authority events include `authority.recalc_requested` for manual recalculation triggers and `income.changed`, `assets.changed`, `liabilities.changed`, and `tax.updated` for automated recalculation when financial data changes. These events ensure that lending authority is always calculated from current data while maintaining the tax-first principle.

## Setup and Configuration

### Prerequisites

Before deploying the webhook system, ensure that you have Python 3.9 or higher installed along with the required dependencies. The system uses only standard library modules, minimizing external dependencies and simplifying deployment. However, for production use, consider using a production-grade WSGI server such as Gunicorn or uvicorn for better performance and reliability.

You will also need a GitHub App configured with webhook subscriptions and appropriate permissions. The GitHub App should have read permissions for contents and metadata, and write permissions for pull requests if you want the system to create automated reviews or comments.

### Environment Variables

The webhook server requires several environment variables to be configured for proper operation. These variables control security settings, paths, and behavioral parameters of the system.

The `GITHUB_WEBHOOK_SECRET` variable is critical for signature verification and must match the webhook secret configured in your GitHub App. This secret should be treated as a sensitive credential and stored securely using your cloud provider's secrets management service or a dedicated secrets manager.

The `WEBHOOK_PORT` variable specifies the port on which the server listens for incoming connections, defaulting to 8080 if not set. The `WEBHOOK_HOST` variable specifies the bind address, defaulting to 0.0.0.0 to listen on all network interfaces. For production deployments behind a reverse proxy, you may want to bind to localhost only.

The `REPO_BASE_PATH` variable specifies the base path to the repository containing the Personal Credit Authority files. This is useful when the webhook server runs in a different directory than the repository root.

### GitHub App Configuration

Creating a GitHub App involves several steps that require careful attention to security and permissions. Navigate to your GitHub organization or account settings, then to the Developer settings section, and create a new GitHub App. Configure the webhook URL to point to your server's endpoint, and set the webhook secret to match the `GITHUB_WEBHOOK_SECRET` environment variable.

Select the following webhook events to subscribe to: push events for code changes, pull request events for permission and authority updates, and any custom events that your handlers may need. For permissions, grant read access to contents for examining files during processing, and read/write access to pull requests if you want automated feedback.

After creating the GitHub App, install it in your repository and note the App ID and private key for any API interactions you may need to implement.

## Deployment Options

### Development Deployment

For local development and testing, you can run the webhook server directly using Python. Navigate to the webhook directory and execute the server script with the appropriate environment variables. The server will start listening for webhook deliveries and log all incoming requests to the console.

During development, consider using a tool like ngrok or localtunnel to expose your local server to GitHub's webhook delivery system. These tools create a public URL that forwards requests to your local development server, enabling full end-to-end testing without deploying to a production environment.

### Production Deployment

For production deployment, the webhook system should run behind a reverse proxy such as Nginx or Apache, which handles SSL termination and provides additional security features. Configure your reverse proxy to forward requests to the webhook server, and ensure that your firewall rules allow incoming connections only on the necessary ports.

Consider using a process manager like systemd or PM2 to ensure that the webhook server restarts automatically after system reboots or unexpected failures. Configure appropriate logging and monitoring to detect issues before they impact system availability.

For containerized deployments, the webhook server can be packaged as a Docker container with minimal configuration. The container should expose the webhook port and receive configuration through environment variables, following the twelve-factor app methodology for cloud-native applications.

### Serverless Options

If you prefer a serverless approach, the webhook handlers can be deployed as AWS Lambda functions or Google Cloud Functions triggered by API Gateway or Cloud Events. This approach eliminates server management overhead and provides automatic scaling based on webhook delivery volume. However, you will need to adapt the server implementation to the specific platform's execution model.

## Security Considerations

Signature verification is mandatory for all webhook deliveries and should never be disabled, even in development environments. Compromised webhook endpoints could allow attackers to manipulate identity data, permission matrices, or lending authority calculations, leading to serious security and financial implications.

All environment variables containing secrets should be managed through a secrets management system rather than stored in configuration files or environment scripts that might be committed to version control. Rotate webhook secrets periodically and immediately if you suspect any compromise.

The webhook handlers should validate all input data and reject requests that do not conform to expected schemas. This defense-in-depth approach prevents malformed or malicious payloads from causing unexpected behavior in the authority system.

## Monitoring and Logging

The webhook system generates detailed logs for all incoming requests, processing steps, and system errors. These logs are essential for troubleshooting issues and auditing system behavior. Configure your logging infrastructure to capture logs from all webhook components and store them in a centralized location for analysis.

Consider implementing metrics collection to track key performance indicators such as request latency, error rates, and event processing volume. These metrics can be exported to monitoring systems like Prometheus or Datadog for alerting and visualization.

Audit logs should be retained for compliance purposes, as they provide an immutable record of all changes to the authority system. The audit trail includes information about who made changes, when they were made, and what the changes entailed.

## Testing Webhooks

GitHub provides a webhook testing interface that allows you to send sample payloads to your webhook endpoint. Use this feature to verify that your handlers respond correctly to different event types before relying on the system in production.

When testing, start with simple events like push notifications and progressively test more complex scenarios involving multi-signature approvals and emergency freezes. Document your test cases and expected outcomes to ensure consistent testing across deployments.

## Troubleshooting

If webhook deliveries fail with signature verification errors, verify that the webhook secret matches exactly between GitHub and your server configuration. Pay special attention to encoding issues and ensure that the secret is passed as plain text rather than base64 encoded.

For timeout errors, check that your handlers complete processing within a reasonable timeframe. GitHub will retry failed deliveries, but extended processing times may indicate performance issues that should be addressed.

If events are not being processed correctly, review the handler implementation to ensure that event types are properly registered in the router and that payload parsing handles the expected data structure. Enable debug logging to trace the event flow through the system.

## Extension and Customization

The webhook system is designed for extensibility. To add support for new event types, create a handler function that accepts an event type and payload, and register it in the event router. Follow the patterns established by existing handlers to maintain consistency across the codebase.

For custom governance rules, modify the appropriate handler to incorporate your rules or add new rule files that the handler loads during initialization. The modular design allows you to update rules without modifying handler code, enabling faster iteration on governance policies.
