# API Reference

This document defines the interfaces through which external systems can interact with the Personal Credit Authority. The API provides programmatic access to identity verification, permission management, and lending authority calculations, enabling integration with external applications and services.

## Authentication and Security

All API requests must be authenticated using API keys issued by the Personal Credit Authority system. API keys are tied to specific roles and permissions, limiting access to appropriate functionality based on the calling application's authorized purpose.

To obtain API keys, submit a request through the developer portal with details about the intended use case. Keys are issued with specific scopes that determine which endpoints are accessible. Review the scope requirements carefully to request appropriate access levels for your application.

API requests must be made over HTTPS to ensure data confidentiality in transit. Requests made over plain HTTP will be rejected. The server certificate should be validated by the client to prevent man-in-the-middle attacks.

Rate limiting applies to all API endpoints to ensure system availability. Limits are defined per endpoint and vary based on the computational cost of the operation. Review the rate limit headers in API responses to understand your current usage status. Applications that exceed rate limits will receive HTTP 429 responses and should implement appropriate backoff strategies.

## Base URL and Versioning

The API base URL follows the pattern `https://api.authority.example.com/v1`, where `v1` indicates the major version of the API. Versioning follows semantic versioning principles: breaking changes increment the major version, backward-compatible changes increment the minor version, and patches do not change the version.

When making API requests, always specify the version explicitly. Requests without a version may be redirected to the current version, but relying on redirects is discouraged as behavior may change. The current API version is 1.0.0.

The API supports content negotiation for response formats. The default format is JSON, which is returned when no format is specified. Additional formats may be available for specific endpoints. Specify the desired format using the `Accept` header or a query parameter as documented for each endpoint.

## Identity Endpoints

The identity endpoints provide access to identity verification functionality. These endpoints allow external systems to verify identity claims, retrieve identity information, and manage identity proofs.

### GET /v1/identity/{identityId}

Retrieves the complete identity manifest for the specified identity ID. This endpoint requires the `identity:read` scope and returns the identity manifest including personal information, verification status, and cryptographic proofs.

The response includes all fields from the identity manifest except for sensitive fields that require additional authorization. Fields containing sensitive personal information may be redacted based on the calling application's authorized purposes.

Request headers should include the API key in the `Authorization` header using the Bearer token scheme. The request path should include the Base64-encoded identity ID.

Response fields include the complete identity manifest structure with all non-redacted fields. The response also includes metadata about the last verification time and the current verification status.

### POST /v1/identity/verify

Submits an identity claim for verification. This endpoint requires the `identity:verify` scope and accepts an identity manifest that will be validated against the identity schema and verified against provided supporting documentation.

The request body should contain a complete identity manifest in JSON format. The manifest must include all required fields and must be structurally valid according to the identity schema. Additional verification documents should be attached as separate parts of a multipart request.

The verification process may require manual review for certain claim types. The response includes a verification request ID that can be used to check the status of pending verifications. Automated verification decisions are returned immediately, while manual reviews may take several business days.

### GET /v1/identity/{identityId}/proof

Retrieves the cryptographic proof for the specified identity. This endpoint requires the `identity:read` scope and returns the proof hash that can be used to verify the integrity of the identity manifest.

The proof is returned as a plain text string containing the hexadecimal-encoded hash value. External systems can independently compute the hash of the identity manifest and compare it to the returned proof to verify that the manifest has not been modified.

This endpoint is particularly useful for third-party verification scenarios where the verifying party needs to confirm identity integrity without accessing the full manifest contents.

## Authority Endpoints

The authority endpoints provide access to lending authority calculations. These endpoints accept financial data inputs and return calculated lending capacity along with detailed breakdowns of the calculation factors.

### POST /v1/authority/calculate

Calculates lending authority based on provided financial data. This endpoint requires the `authority:calculate` scope and implements the complete tax-first governance calculation.

The request body should contain financial data including gross income, net income, asset values, liability values, and tax obligation estimates. All monetary values should be provided as decimal numbers in the currency specified in the request. The request should also include the identity ID of the individual for whom the calculation is being performed.

The calculation follows the tax-first governance methodology, first determining disposable income by subtracting tax obligations from net income, then applying loan-to-income and loan-to-tax constraints, adjusting for risk tier, and applying annual limits.

The response includes the calculated maximum lending capacity as a decimal value, along with the loan-to-income ratio, loan-to-tax ratio, and assigned risk tier. The response also includes a detailed factors object that breaks down each step of the calculation for transparency and audit purposes.

### GET /v1/authority/current

Retrieves the current lending authority for a specific identity. This endpoint requires the `authority:read` scope and returns the stored authority calculation without requiring financial data input.

This endpoint is useful for applications that need to access previously calculated authority values rather than performing new calculations. The returned authority reflects the most recent calculation based on the financial data stored in the system.

The response includes the same fields as the calculate endpoint, plus metadata about when the calculation was performed and what financial data was used. This metadata supports auditing requirements and helps applications determine whether a recalculation is needed.

### POST /v1/authority/recalculate

Triggers a recalculation of lending authority based on current financial data. This endpoint requires the `authority:write` scope and initiates an asynchronous recalculation process.

The request should include the identity ID for which recalculation is requested. Optionally, updated financial data can be provided to replace stored values. If no updated data is provided, the calculation uses the currently stored financial data.

The response acknowledges the recalculation request and provides a request ID that can be used to check the status. Recalculations are processed asynchronously, and large calculation volumes may result in queued processing with slight delays.

## Permission Endpoints

The permission endpoints provide access to permission management functionality. These endpoints allow external systems to check permissions, request permission changes, and manage role assignments.

### GET /v1/permissions/check

Checks whether a specific action is permitted for a given user and role. This endpoint requires the `permissions:read` scope and provides a lightweight way to verify authorization without retrieving the full permission matrix.

The request should include the user identifier, the role to check, and the specific action being performed. The response indicates whether the action is permitted, denied, or not applicable based on the current permission configuration.

This endpoint is useful for authorization checks in integrated applications. The lightweight response format minimizes latency for real-time authorization decisions.

### GET /v1/permissions/matrix

Retrieves the complete permission matrix. This endpoint requires the `permissions:admin` scope due to the sensitivity of the returned data. The matrix includes all role definitions, action mappings, and special rules configured in the system.

The response includes the full matrix structure with role names as keys and action-permission mappings as values. The response also includes special rules for founder overrides, emergency freezes, and multi-signature requirements.

This endpoint is intended for administrative purposes and audit compliance. Regular applications should use the check endpoint for authorization decisions rather than retrieving and processing the full matrix.

### POST /v1/permissions/request

Submits a request to modify permissions. This endpoint requires the `permissions:request` scope and initiates the permission change workflow including any required multi-signature approvals.

The request should include details about the proposed change including the affected roles, actions, and new permission values. The request body should also include a justification explaining why the change is necessary.

The response indicates whether the change can be applied immediately or requires additional approval. For changes requiring multi-signature approval, the response includes the request ID and the number of approvals needed. Approvals can be submitted through a separate endpoint.

### POST /v1/permissions/approve

Submits approval for a pending permission change request. This endpoint requires the `permissions:approve` scope and is used by authorized approvers to complete multi-signature workflows.

The request should include the request ID of the pending change and the approver's credentials. The system verifies that the approver has the required role for the specific change being approved.

The response indicates whether the approval was accepted and whether the change has been completed. If additional approvals are needed, the response indicates how many more are required. When the final required approval is submitted, the change is applied immediately.

## Webhook Endpoints

The webhook endpoints allow external systems to register for event notifications. Rather than polling for changes, applications can register webhooks to receive push notifications when relevant events occur.

### POST /v1/webhooks/subscribe

Creates a new webhook subscription. This endpoint requires the `webhooks:write` scope and registers a callback URL that will receive event notifications.

The request should include the callback URL, the event types to subscribe to, and optional filters to limit the events received. The callback URL must be reachable from the internet and must respond to verification challenges.

The response includes a subscription ID that can be used to manage the subscription. Subscriptions remain active until explicitly deleted or until they fail to respond to delivery attempts repeatedly.

### GET /v1/webhooks/subscriptions

Lists all active webhook subscriptions. This endpoint requires the `webhooks:read` scope and returns a paginated list of subscriptions with their configuration and status.

The response includes subscription IDs, callback URLs, subscribed event types, and delivery statistics. This endpoint is useful for auditing webhook configuration and identifying unused subscriptions.

### DELETE /v1/webhooks/subscribe/{subscriptionId}

Deletes an existing webhook subscription. This endpoint requires the `webhooks:write` scope and immediately stops event delivery to the specified callback.

The path parameter should include the subscription ID to delete. The response confirms deletion and stops billing for the subscription if applicable.

## Error Responses

All API errors return JSON response bodies with standardized error information. The response includes an error code identifying the general category of error, a human-readable message describing the specific issue, and optional details about the error context.

Common error codes include 400 for bad request when input validation fails, 401 for unauthorized when authentication is missing or invalid, 403 for forbidden when the authenticated user lacks required permissions, 404 for not found when the requested resource does not exist, 429 for rate limit exceeded when rate limits are reached, and 500 for internal error when server-side issues occur.

Error responses may include a request ID that can be provided to support personnel for troubleshooting. Include this request ID in any support requests to accelerate resolution.

## Rate Limits

Rate limits are defined per endpoint and vary based on the computational cost of the operation. Read operations typically allow higher rates than write operations, and calculation operations have the most restrictive limits due to their computational intensity.

Rate limit information is included in the response headers of each request. The `X-RateLimit-Limit` header indicates the total requests allowed in the window, `X-RateLimit-Remaining` indicates remaining requests in the current window, and `X-RateLimit-Reset` indicates when the window resets in Unix timestamp format.

When rate limits are exceeded, the API returns HTTP 429 with a brief message indicating the reset time. Implement exponential backoff with jitter to handle rate limit responses gracefully. Applications should proactively throttle requests when approaching limits to avoid disrupting service.

## SDKs and Client Libraries

Official client libraries are available for several programming languages to simplify API integration. The JavaScript/TypeScript SDK provides full TypeScript type definitions and is available via npm. The Python SDK is available via pip and includes async support for concurrent operations. The Go SDK is available via the Go module system and follows Go idioms for error handling and concurrency.

Community-contributed libraries may be available for additional languages. These libraries are not officially supported but may provide valuable functionality for specific use cases. When using community libraries, verify that they are actively maintained and follow security best practices for credential handling.

All client libraries require API key configuration. Store API keys securely using environment variables or secrets management systems. Never commit API keys to version control or embed them in client-side code.

## Version History and Migration

When breaking changes require API version increments, migration guides are provided to help applications transition smoothly. Migration guides document the specific changes between versions, provide code examples for updated requests, and identify deprecated features with recommended alternatives.

Deprecated endpoints continue to function for a minimum of twelve months after deprecation announcement. During the deprecation period, responses include deprecation warnings in headers and documentation. Applications should begin migration planning immediately upon deprecation announcement to avoid last-minute urgency.

Major version increments include breaking changes that cannot be made backward compatible. Review the migration guide carefully and test thoroughly in a non-production environment before deploying changes to production systems.
