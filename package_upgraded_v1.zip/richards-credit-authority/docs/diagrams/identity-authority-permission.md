# Identity-Authority-Permission Architecture Diagram

This document contains the Mermaid diagram source code for the Identity-Authority-Permission architecture. Render this diagram using a Mermaid-compatible viewer to visualize the system architecture.

```mermaid
flowchart TB
    subgraph Identity["Identity Domain"]
        direction TB
        IM[Identity Manifest]
        IS[Identity Schema]
        IP[Identity Proof]
        IV[Identity Verification]
        
        IM --> IS
        IP --> IM
        IV --> IM
    end
    
    subgraph Authority["Authority Domain"]
        direction TB
        LC[Lending Calculation]
        LTI[LTI Rules]
        LTT[LTT Rules]
        RT[Risk Tiers]
        AL[Annual Limits]
        AF[Lending Formulas]
        
        LC --> LTI
        LC --> LTT
        LC --> RT
        LC --> AL
        LC --> AF
    end
    
    subgraph Permission["Permission Domain"]
        direction TB
        PM[Permission Matrix]
        RA[Role Assignment]
        MS[Multi-Signature]
        FO[Founder Override]
        EF[Emergency Freeze]
        
        PM --> RA
        RA --> MS
        FO --> PM
        EF --> PM
    end
    
    subgraph Governance["Governance Domain"]
        direction TB
        GR[Governance Rules]
        ALG[Audit Logs]
        WR[Workflow Rules]
        AM[Amendment Process]
        
        GR --> WR
        ALG --> GR
        AM --> GR
    end
    
    subgraph Webhook["Webhook System"]
        direction TB
        WS[Webhook Server]
        SV[Signature Verification]
        ER[Event Router]
        EH[Event Handlers]
        
        WS --> SV
        SV --> ER
        ER --> EH
    end
    
    subgraph External["External Systems"]
        direction TB
        GH[GitHub]
        API[External API]
        LM[Lending Manager]
    end
    
    GH --> WS
    API --> LC
    LM --> LC
    
    EH --> IM
    EH --> PM
    EH --> LC
    
    IM --> LC
    PM --> LC
    
    GR --> LC
    GR --> PM
    GR --> IM
    
    style Identity fill:#e1f5fe
    style Authority fill:#f3e5f5
    style Permission fill:#e8f5e8
    style Governance fill:#fff3e0
    style Webhook fill:#fce4ec
    style External fill:#eceff1
```

## Diagram Legend

The diagram illustrates the relationship between the four core domains of the Personal Credit Authority system and their interactions with external systems through the webhook infrastructure.

The Identity Domain manages all aspects of personal identity including the manifest document that stores identity data, the schema that defines identity structure, cryptographic proofs that verify identity integrity, and the verification workflow that establishes trust.

The Authority Domain contains the lending calculation engine and its associated rules. The central calculation component coordinates loan-to-income rules, loan-to-tax rules, risk tier definitions, annual limits, and the lending formulas that produce the final lending capacity figure.

The Permission Domain implements access control through the permission matrix, role assignments, multi-signature requirements, founder override capabilities, and emergency freeze mechanisms. These components work together to ensure that only authorized users can perform sensitive operations.

The Governance Domain provides the overarching framework that governs all other domains. Governance rules define acceptable behaviors, audit logs record system activity, workflow rules define processes, and the amendment process enables controlled rule changes.

The Webhook System provides the event-driven infrastructure that connects GitHub events to system operations. The webhook server receives incoming requests, signature verification ensures authenticity, the event router dispatches to appropriate handlers, and event handlers implement domain-specific logic.

External Systems interact with the authority through GitHub webhook events, the external API for programmatic access, and lending managers that consume lending authority calculations.
