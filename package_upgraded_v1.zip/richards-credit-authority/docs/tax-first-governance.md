# Tax-First Governance Philosophy

The tax-first governance principle is the foundational concept that distinguishes the Personal Credit Authority from traditional credit systems. This document explains the philosophy behind tax-first governance, its practical implementation, and its implications for lending decisions.

## Philosophy and Rationale

Traditional credit evaluation typically begins with gross income and applies various adjustments to arrive at a credit decision. This approach often overlooks the reality that a significant portion of income is consumed by tax obligations, leaving less available for debt service than the raw income figures suggest. The tax-first governance principle corrects this oversight by placing tax obligations at the center of all lending calculations.

The core insight behind tax-first governance is that tax compliance is non-negotiable. While lenders can negotiate repayment terms, adjust interest rates, or work with borrowers facing difficulties, tax obligations must be met regardless of personal preferences or financial circumstances. A lending decision that ignores tax obligations is essentially assuming that taxes will somehow not need to be paid, which is fundamentally unrealistic.

This philosophy has profound implications for how lending capacity is calculated. Rather than viewing gross income as the starting point, tax-first governance begins with net income after taxes and builds lending capacity from there. This approach naturally produces more conservative lending limits that align with the borrower's actual ability to pay.

The principle also provides a clear framework for handling financial uncertainty. When tax obligations change, lending capacity adjusts automatically. This self-correcting mechanism ensures that the system responds appropriately to changing circumstances without requiring manual intervention or discretionary adjustments that could introduce inconsistency or bias.

## Theoretical Foundation

Tax-first governance draws from several established principles in finance and economics. The concept of disposable income, which measures income available for spending or saving after taxes, provides the mathematical foundation for the approach. By using disposable income as the base for lending calculations, the system ensures that lending capacity never exceeds what the borrower can actually use for debt service.

The principle of financial sustainability underlies the conservative approach to lending limits. Sustainable lending requires that borrowers can service their debt under reasonable assumptions about future income and expenses. By accounting for taxes upfront, tax-first governance builds a margin of safety into all lending decisions.

Behavioral economics research supports the tax-first approach to personal finance. Studies consistently show that people struggle to plan for tax obligations that occur in the future, often spending money that will eventually be needed for taxes. By embedding this planning into the lending authority calculation, the system compensates for these behavioral tendencies.

The legal framework around debt and taxes also supports this approach. In most jurisdictions, tax obligations have priority over other debts, with tax authorities having strong collection powers that can supersede creditor rights. A lending decision that ignores this priority is effectively ignoring the legal reality of how debts are treated in insolvency situations.

## Implementation in the Authority System

The tax-first governance principle is implemented through several specific mechanisms in the Personal Credit Authority system. These mechanisms work together to ensure that tax obligations are properly accounted for at every stage of the lending calculation.

The first implementation mechanism is the disposable income calculation. The system calculates disposable income by subtracting estimated tax obligations from net income. This calculation uses tax information from the identity manifest, which includes the individual's tax identification and residency information. The system can apply appropriate tax rates based on this information to estimate annual tax obligations.

The second mechanism is the loan-to-tax ratio constraint. While loan-to-income ratios are common in lending, the tax-first approach adds a loan-to-tax ratio as an additional constraint. This ratio ensures that total lending capacity remains proportional to tax obligations, preventing situations where borrowing becomes excessive relative to the tax burden. For example, a system might limit total borrowing to no more than five times annual tax obligations.

The third mechanism is the tax-priority rule in financial change processing. When financial data changes, the system processes tax changes before income or liability changes. This ordering ensures that lending capacity adjustments properly account for the tax implications of any financial change, rather than applying adjustments in an arbitrary order.

The fourth mechanism is the tax obligation verification. The system validates that tax identification information is complete and valid before performing any lending calculations. This verification prevents situations where missing tax information could result in calculations that do not properly account for tax obligations.

## Calculation Methodology

The lending authority calculation follows a specific methodology that implements the tax-first principle at each step. Understanding this methodology is important for interpreting calculation results and for troubleshooting when results seem unexpected.

The calculation begins by gathering all relevant financial data from the system data stores. This includes gross income from employment or business, net income after standard deductions, total assets including savings and investments, total liabilities including existing debts, and estimated tax obligations based on income and residency. All figures are annualized to provide a consistent basis for comparison.

The first calculation step computes disposable income by subtracting tax obligations from net income. This step implements the core tax-first principle by ensuring that the subsequent calculations are based on income that is actually available for debt service. If tax obligations exceed net income, the system records a zero disposable income and adjusts subsequent calculations accordingly.

The loan-to-income calculation applies a maximum ratio to disposable income to establish a preliminary lending capacity. The specific ratio depends on the risk tier assigned to the individual, with lower-risk tiers receiving higher ratios. This adjustment provides additional conservatism for riskier profiles while allowing appropriate capacity for well-qualified individuals.

The loan-to-tax calculation applies a separate ratio to tax obligations, creating a secondary constraint on lending capacity. This constraint ensures that borrowing remains proportional to tax burden, regardless of income level. For individuals with low effective tax rates, this constraint may be more restrictive than the loan-to-income calculation.

The final capacity is the minimum of the loan-to-income result, the loan-to-tax result, and the annual lending limit. This hierarchical approach ensures that all constraints are respected and that the most restrictive constraint determines the final capacity. The calculation factors are recorded for audit purposes, allowing anyone to trace how the final capacity was determined.

## Governance Rules Structure

The tax-first governance rules are stored in a machine-readable format that allows the system to apply rules consistently and the rules to be audited for compliance. The rule structure supports multiple jurisdictions, multiple entity types, and changing circumstances.

The rules file contains sections for disposable income calculation, loan-to-income constraints, loan-to-tax constraints, and annual limits. Each section defines the parameters used in the corresponding calculation and any conditions that modify those parameters. The structure allows for different parameters based on risk tier, entity type, or other relevant factors.

Jurisdiction-specific rules address the reality that tax systems vary significantly across countries and regions. The rules file can define different tax calculation parameters for different residency classifications, ensuring that the system produces appropriate results regardless of where the individual resides. This flexibility is essential for systems that serve international users.

Rule amendment procedures ensure that governance changes follow a controlled process. Proposed rule changes must be documented in a specific format, reviewed by authorized parties, and approved through the appropriate workflow before taking effect. This process ensures that rule changes are thoughtful and properly authorized rather than made impulsively.

## Practical Implications

The tax-first governance principle has several practical implications for how the Personal Credit Authority operates. These implications affect both how calculations are performed and how users interact with the system.

For borrowers, the tax-first approach provides more accurate lending capacity estimates. By accounting for taxes upfront, the capacity figures represent money that is actually available for debt service rather than money that will eventually be needed for taxes. This accuracy helps borrowers make informed decisions about taking on new debt.

For lenders, the tax-first approach provides additional assurance that lending decisions are sound. The transparent calculation methodology allows lenders to understand exactly how capacity was determined and to verify that the calculation properly accounts for all relevant factors. This transparency builds trust in the evaluation process.

For auditors, the tax-first rules provide a clear framework for evaluating system behavior. The machine-readable rules can be analyzed to ensure compliance with organizational policies and regulatory requirements. The detailed calculation factors provide a complete audit trail of how each capacity figure was determined.

For system administrators, the tax-first implementation provides flexibility in how rules are configured. The rule structure supports gradual changes to parameters, allowing the system to be tuned over time without requiring wholesale rewrites. This flexibility enables continuous improvement based on experience and changing circumstances.

## Comparison with Traditional Approaches

Traditional credit evaluation often uses gross income as the starting point for lending decisions. This approach can produce misleading results when tax obligations are significant, as it effectively assumes that taxes will not need to be paid or that they can somehow be deferred. The tax-first approach corrects this by placing taxes where they belong: at the center of the calculation.

Some credit systems attempt to account for taxes by applying a fixed percentage reduction to income. While this is an improvement over ignoring taxes entirely, it lacks the precision of the tax-first approach. Tax situations vary significantly based on income level, family status, deductions, and jurisdiction. A fixed percentage cannot capture this variation.

The tax-first approach also differs from income-based repayment plans used in some lending contexts. Those plans typically calculate payments based on a percentage of income, but they do not systematically account for tax obligations in the underlying capacity calculation. The tax-first approach provides a more complete picture of what borrowers can actually afford.

By making tax obligations explicit in the calculation, the tax-first approach also raises awareness of tax planning considerations. Users who see their lending capacity reduced due to tax obligations may be motivated to explore tax optimization strategies. This awareness can lead to better overall financial outcomes beyond just the lending context.

## Future Development Considerations

The tax-first governance principle provides a foundation for future enhancements to the Personal Credit Authority system. Several potential enhancements build on the tax-first concept while extending its applicability.

Multi-year projections could extend the tax-first calculation to consider how lending capacity might change over time. This would require modeling future income, tax rate changes, and other factors that affect long-term capacity. Such projections could help users plan major financial decisions more effectively.

Scenario analysis could allow users to explore how different circumstances would affect their lending capacity. For example, a user could see how taking a new job with higher income but different tax implications would affect their overall capacity. This analysis would help users make informed career and financial decisions.

Integration with tax preparation systems could automate the tax information updates that trigger recalculation. Rather than requiring users to manually update tax information, the system could receive updates directly from tax software or tax authorities. This automation would improve accuracy and reduce administrative burden.

International tax coordination could extend the system to handle individuals with tax obligations in multiple jurisdictions. This would require more complex rules that account for tax treaties, foreign income inclusions, and other international tax considerations. Such an extension would make the system applicable to a broader range of users.
