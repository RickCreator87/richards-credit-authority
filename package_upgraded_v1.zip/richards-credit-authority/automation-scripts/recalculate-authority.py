#!/usr/bin/env python3
"""
Recalculate Lending Authority Script

This script recalculates the lending authority based on current financial data
and governance rules. It implements the tax-first governance principle by
ensuring that tax obligations are accounted for before determining available
credit.

Usage:
    python recalculate-authority.py [--verbose] [--output FILE]

Author: MiniMax Agent
Version: 1.0.0
"""

import argparse
import json
import sys
from datetime import datetime, timezone
from decimal import Decimal, ROUND_HALF_UP
from pathlib import Path
from typing import Dict, Any, Optional


class LendingAuthorityRecalculator:
    """
    Handles the recalculation of lending authority based on current financial data.
    """
    
    def __init__(self, base_path: Optional[str] = None, verbose: bool = False):
        """
        Initialize the recalculator.
        
        Args:
            base_path: Base directory path for the repository
            verbose: Enable verbose output
        """
        self.base_path = Path(base_path) if base_path else Path.cwd()
        self.verbose = verbose
        self.authority_dir = self.base_path / "authority"
        self.identity_dir = self.base_path / "identity"
        self.governance_dir = self.base_path / "governance"
        
        # Load rules and configurations
        self.risk_tiers = self._load_risk_tiers()
        self.lti_rules = self._load_lti_rules()
        self.ltt_rules = self._load_ltt_rules()
        self.annual_limits = self._load_annual_limits()
        
    def _load_risk_tiers(self) -> Dict[str, Any]:
        """Load risk tier definitions."""
        rules_path = self.authority_dir / "rules" / "risk-tier-definitions.json"
        if rules_path.exists():
            with open(rules_path, 'r') as f:
                return json.load(f)
        return {'riskTiers': []}
    
    def _load_lti_rules(self) -> Dict[str, Any]:
        """Load loan-to-income rules."""
        rules_path = self.authority_dir / "rules" / "loan-to-income-rules.json"
        if rules_path.exists():
            with open(rules_path, 'r') as f:
                return json.load(f)
        return {'maxLtiRatio': Decimal('4.0')}
    
    def _load_ltt_rules(self) -> Dict[str, Any]:
        """Load loan-to-tax rules."""
        rules_path = self.authority_dir / "rules" / "loan-to-tax-rules.json"
        if rules_path.exists():
            with open(rules_path, 'r') as f:
                return json.load(f)
        return {'maxLttRatio': Decimal('0.5')}
    
    def _load_annual_limits(self) -> Dict[str, Any]:
        """Load annual lending limits."""
        limits_path = self.authority_dir / "rules" / "annual-lending-limit.json"
        if limits_path.exists():
            with open(limits_path, 'r') as f:
                return json.load(f)
        return {'maxAnnualLending': Decimal('1000000')}
    
    def gather_financial_data(self) -> Dict[str, Decimal]:
        """
        Gather current financial data from all relevant sources.
        
        Returns:
            Dictionary containing financial data
        """
        data = {
            'gross_income': Decimal('0'),
            'net_income': Decimal('0'),
            'assets': Decimal('0'),
            'liabilities': Decimal('0'),
            'tax_obligations': Decimal('0'),
            'disposable_income': Decimal('0'),
        }
        
        # Get tax information from identity
        identity_path = self.identity_dir / "identity-manifest.json"
        if identity_path.exists():
            with open(identity_path, 'r') as f:
                identity = json.load(f)
            
            tax_info = identity.get('taxInformation', {})
            data['tax_obligations'] = Decimal(str(tax_info.get('estimatedAnnualTax', 0)))
        
        # Get financial data from authority data file
        data_path = self.authority_dir / "authority-data.json"
        if data_path.exists():
            with open(data_path, 'r') as f:
                authority_data = json.load(f)
            
            data['gross_income'] = Decimal(str(authority_data.get('grossAnnualIncome', 0)))
            data['net_income'] = Decimal(str(authority_data.get('netAnnualIncome', 0)))
            data['assets'] = Decimal(str(authority_data.get('totalAssets', 0)))
            data['liabilities'] = Decimal(str(authority_data.get('totalLiabilities', 0)))
        
        # Calculate disposable income (net income minus tax obligations)
        data['disposable_income'] = data['net_income'] - data['tax_obligations']
        if data['disposable_income'] < Decimal('0'):
            data['disposable_income'] = Decimal('0')
        
        return data
    
    def determine_risk_tier(self, data: Dict[str, Decimal]) -> str:
        """
        Determine the risk tier based on financial data.
        
        Args:
            data: Financial data dictionary
            
        Returns:
            Risk tier identifier
        """
        # Calculate debt-to-income ratio
        if data['net_income'] > Decimal('0'):
            dti_ratio = data['liabilities'] / data['net_income']
        else:
            dti_ratio = Decimal('999')
        
        # Check against tier criteria
        tiers = self.risk_tiers.get('riskTiers', [])
        
        for tier in sorted(tiers, key=lambda t: t.get('tierId', '')):
            criteria = tier.get('criteria', {})
            
            dti_max = criteria.get('debtToIncomeRatio', {}).get('max', Decimal('999'))
            if dti_ratio <= dti_max:
                return tier.get('tierId', 'T5_HIGH_RISK')
        
        return 'T5_HIGH_RISK'
    
    def get_risk_adjustment(self, risk_tier: str) -> Decimal:
        """
        Get the capacity adjustment factor for a risk tier.
        
        Args:
            risk_tier: The risk tier identifier
            
        Returns:
            Decimal adjustment factor
        """
        tier_adjustments = {
            'T1_PRIME_PLUS': Decimal('1.0'),
            'T2_PRIME': Decimal('0.95'),
            'T3_SUBPRIME': Decimal('0.85'),
            'T4_DEEP_SUBPRIME': Decimal('0.7'),
            'T5_HIGH_RISK': Decimal('0.5'),
        }
        
        return tier_adjustments.get(risk_tier, Decimal('0.5'))
    
    def calculate_lending_authority(self) -> Dict[str, Any]:
        """
        Calculate lending authority based on current financial data.
        
        Returns:
            Dictionary containing calculation results
        """
        financial_data = self.gather_financial_data()
        
        if self.verbose:
            print("Financial Data:")
            for key, value in financial_data.items():
                print(f"  {key}: ${value:,.2f}")
        
        # Step 1: Calculate LTI-based capacity
        max_lti = Decimal(str(self.lti_rules.get('maxLtiRatio', Decimal('4.0'))))
        lti_capacity = financial_data['net_income'] * max_lti
        
        if self.verbose:
            print(f"\nLTI Calculation:")
            print(f"  Net Income: ${financial_data['net_income']:,.2f}")
            print(f"  Max LTI Ratio: {max_lti}")
            print(f"  LTI Capacity: ${lti_capacity:,.2f}")
        
        # Step 2: Calculate LTT-based capacity
        max_ltt = Decimal(str(self.ltt_rules.get('maxLttRatio', Decimal('0.5'))))
        if financial_data['tax_obligations'] > Decimal('0'):
            ltt_capacity = financial_data['tax_obligations'] * max_ltt * Decimal('10')
        else:
            ltt_capacity = financial_data['net_income'] * Decimal('0.1')
        
        if self.verbose:
            print(f"\nLTT Calculation:")
            print(f"  Tax Obligations: ${financial_data['tax_obligations']:,.2f}")
            print(f"  Max LTT Ratio: {max_ltt}")
            print(f"  LTT Capacity: ${ltt_capacity:,.2f}")
        
        # Step 3: Apply tax-first principle
        base_capacity = min(lti_capacity, ltt_capacity)
        
        # Step 4: Adjust for risk tier
        risk_tier = self.determine_risk_tier(financial_data)
        risk_adjustment = self.get_risk_adjustment(risk_tier)
        adjusted_capacity = base_capacity * risk_adjustment
        
        if self.verbose:
            print(f"\nRisk Adjustment:")
            print(f"  Risk Tier: {risk_tier}")
            print(f"  Adjustment Factor: {risk_adjustment}")
            print(f"  Adjusted Capacity: ${adjusted_capacity:,.2f}")
        
        # Step 5: Apply annual limits
        annual_limit = Decimal(str(self.annual_limits.get('maxAnnualLending', Decimal('1000000'))))
        final_capacity = min(adjusted_capacity, annual_limit)
        
        if self.verbose:
            print(f"\nAnnual Limit:")
            print(f"  Annual Limit: ${annual_limit:,.2f}")
            print(f"  Limit Applied: {adjusted_capacity > annual_limit}")
            print(f"  Final Capacity: ${final_capacity:,.2f}")
        
        # Calculate ratios
        if financial_data['net_income'] > Decimal('0'):
            loan_to_income = final_capacity / financial_data['net_income']
        else:
            loan_to_income = Decimal('0')
        
        if financial_data['tax_obligations'] > Decimal('0'):
            loan_to_tax = final_capacity / financial_data['tax_obligations']
        else:
            loan_to_tax = Decimal('0')
        
        result = {
            'maxLendingCapacity': str(final_capacity.quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)),
            'loanToIncomeRatio': str(loan_to_income.quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)),
            'loanToTaxRatio': str(loan_to_tax.quantize(Decimal('0.01'), rounding=ROUND_HALF_UP)),
            'riskTier': risk_tier,
            'calculationTimestamp': datetime.now(timezone.utc).isoformat(),
            'financialData': {k: str(v) for k, v in financial_data.items()},
            'calculationFactors': {
                'ltiCapacity': str(lti_capacity),
                'lttCapacity': str(ltt_capacity),
                'baseCapacityAfterTaxFirst': str(base_capacity),
                'riskAdjustment': str(risk_adjustment),
                'annualLimit': str(annual_limit),
            }
        }
        
        return result
    
    def apply_calculation(self, result: Dict[str, Any]) -> bool:
        """
        Apply the calculated lending authority to the authority data file.
        
        Args:
            result: Calculation result dictionary
            
        Returns:
            True if successful, False otherwise
        """
        data_path = self.authority_dir / "authority-data.json"
        
        # Load existing data or create new
        if data_path.exists():
            with open(data_path, 'r') as f:
                authority_data = json.load(f)
        else:
            authority_data = {}
        
        # Update with new calculation
        authority_data['maxLendingCapacity'] = result['maxLendingCapacity']
        authority_data['loanToIncomeRatio'] = result['loanToIncomeRatio']
        authority_data['loanToTaxRatio'] = result['loanToTaxRatio']
        authority_data['riskTier'] = result['riskTier']
        authority_data['lastCalculationTimestamp'] = result['calculationTimestamp']
        authority_data['calculationFactors'] = result['calculationFactors']
        authority_data['financialData'] = result['financialData']
        authority_data['lastUpdated'] = datetime.now(timezone.utc).isoformat()
        
        # Write updated data
        with open(data_path, 'w') as f:
            json.dump(authority_data, f, indent=2)
        
        if self.verbose:
            print(f"\nLending authority updated successfully.")
            print(f"Output file: {data_path}")
        
        return True
    
    def run(self) -> bool:
        """
        Run the complete recalculation process.
        
        Returns:
            True if successful, False otherwise
        """
        print(f"Lending Authority Recalculation")
        print(f"Started: {datetime.now().isoformat()}")
        print("=" * 50)
        
        try:
            result = self.calculate_lending_authority()
            
            print("\n" + "=" * 50)
            print("Results:")
            print(f"  Max Lending Capacity: ${result['maxLendingCapacity']}")
            print(f"  Loan-to-Income Ratio: {result['loanToIncomeRatio']}")
            print(f"  Loan-to-Tax Ratio: {result['loanToTaxRatio']}")
            print(f"  Risk Tier: {result['riskTier']}")
            print("=" * 50)
            
            self.apply_calculation(result)
            
            print(f"\nCompleted: {datetime.now().isoformat()}")
            return True
            
        except Exception as e:
            print(f"\nError during recalculation: {e}", file=sys.stderr)
            return False


def main():
    """Main entry point for the script."""
    parser = argparse.ArgumentParser(
        description="Recalculate lending authority based on current financial data."
    )
    parser.add_argument(
        "--verbose", "-v",
        action="store_true",
        help="Enable verbose output"
    )
    parser.add_argument(
        "--output", "-o",
        help="Output file path for results (optional)"
    )
    parser.add_argument(
        "--path",
        help="Base path to the repository (defaults to current directory)"
    )
    
    args = parser.parse_args()
    
    recalculator = LendingAuthorityRecalculator(
        base_path=args.path,
        verbose=args.verbose
    )
    
    success = recalculator.run()
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()
