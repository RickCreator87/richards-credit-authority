#!/usr/bin/env python3
"""
Generate Audit Log Script

This script generates audit logs for the Personal Credit Authority system,
aggregating events from various sources and producing comprehensive audit
trails for compliance and review purposes.

Usage:
    python generate-audit-log.py [--start-date DATE] [--end-date DATE]
                                 [--event-type TYPE] [--output FILE]

Author: MiniMax Agent
Version: 1.0.0
"""

import argparse
import json
import sys
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Dict, Any, List, Optional
from collections import defaultdict


class AuditLogGenerator:
    """
    Generates comprehensive audit logs by aggregating events from multiple sources.
    """
    
    def __init__(self, base_path: Optional[str] = None, verbose: bool = False):
        """
        Initialize the audit log generator.
        
        Args:
            base_path: Base directory path for the repository
            verbose: Enable verbose output
        """
        self.base_path = Path(base_path) if base_path else Path.cwd()
        self.verbose = verbose
        self.governance_dir = self.base_path / "governance"
        self.logs_dir = self.governance_dir / "logs"
        self.audit_dir = self.governance_dir / "audit-logs"
        
    def find_log_files(self, start_date: datetime, end_date: datetime) -> List[Path]:
        """
        Find all log files within the specified date range.
        
        Args:
            start_date: Start of the date range
            end_date: End of the date range
            
        Returns:
            List of log file paths
        """
        log_files = []
        
        if not self.logs_dir.exists():
            return log_files
        
        # Search for log files with date patterns
        date_pattern = start_date.strftime('%Y%m%d')
        end_pattern = end_date.strftime('%Y%m%d')
        
        for log_file in self.logs_dir.glob("*.jsonl"):
            # Extract date from filename
            filename = log_file.stem
            # Include all files that might contain relevant logs
            # In production, would parse dates from filenames or content
            log_files.append(log_file)
        
        return log_files
    
    def parse_log_entry(self, line: str) -> Optional[Dict[str, Any]]:
        """
        Parse a single log entry from JSONL format.
        
        Args:
            line: JSONL formatted line
            
        Returns:
            Parsed log entry or None if parsing fails
        """
        try:
            return json.loads(line.strip())
        except json.JSONDecodeError:
            return None
    
    def filter_by_date(self, entry: Dict[str, Any], 
                       start_date: datetime, 
                       end_date: datetime) -> bool:
        """
        Check if a log entry falls within the specified date range.
        
        Args:
            entry: Log entry dictionary
            start_date: Start of the date range
            end_date: End of the date range
            
        Returns:
            True if entry is within range, False otherwise
        """
        if 'timestamp' not in entry:
            return False
        
        try:
            entry_date = datetime.fromisoformat(entry['timestamp'].replace('Z', '+00:00'))
            return start_date <= entry_date <= end_date
        except (ValueError, AttributeError):
            return False
    
    def filter_by_type(self, entry: Dict[str, Any], event_type: Optional[str]) -> bool:
        """
        Check if a log entry matches the specified event type.
        
        Args:
            entry: Log entry dictionary
            event_type: Event type to filter by (None for all types)
            
        Returns:
            True if entry matches filter, False otherwise
        """
        if not event_type:
            return True
        return entry.get('eventType', '') == event_type
    
    def load_logs(self, log_files: List[Path], 
                  start_date: datetime, 
                  end_date: datetime,
                  event_type: Optional[str]) -> List[Dict[str, Any]]:
        """
        Load and filter logs from the specified files.
        
        Args:
            log_files: List of log file paths
            start_date: Start of the date range
            end_date: End of the date range
            event_type: Event type to filter by
            
        Returns:
            List of filtered log entries
        """
        entries = []
        
        for log_file in log_files:
            if self.verbose:
                print(f"Reading: {log_file}")
            
            try:
                with open(log_file, 'r') as f:
                    for line in f:
                        entry = self.parse_log_entry(line)
                        if entry:
                            if self.filter_by_date(entry, start_date, end_date):
                                if self.filter_by_type(entry, event_type):
                                    entries.append(entry)
            except (IOError, OSError) as e:
                if self.verbose:
                    print(f"  Warning: Could not read {log_file}: {e}")
        
        # Sort by timestamp
        entries.sort(key=lambda e: e.get('timestamp', ''))
        
        return entries
    
    def aggregate_by_event_type(self, entries: List[Dict[str, Any]]) -> Dict[str, List[Dict[str, Any]]]:
        """
        Aggregate log entries by event type.
        
        Args:
            entries: List of log entries
            
        Returns:
            Dictionary mapping event types to lists of entries
        """
        grouped = defaultdict(list)
        for entry in entries:
            event_type = entry.get('eventType', 'unknown')
            grouped[event_type].append(entry)
        return dict(grouped)
    
    def generate_summary(self, entries: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Generate a summary of the audit log entries.
        
        Args:
            entries: List of log entries
            
        Returns:
            Summary statistics
        """
        summary = {
            'totalEntries': len(entries),
            'uniqueActors': set(),
            'eventTypeCounts': defaultdict(int),
            'dateRange': {
                'earliest': None,
                'latest': None,
            },
        }
        
        for entry in entries:
            # Count event types
            event_type = entry.get('eventType', 'unknown')
            summary['eventTypeCounts'][event_type] += 1
            
            # Track unique actors
            actor = entry.get('updater', entry.get('requester', 
                           entry.get('actor', entry.get('user', 'unknown'))))
            summary['uniqueActors'].add(actor)
            
            # Track date range
            timestamp = entry.get('timestamp', '')
            if timestamp:
                if not summary['dateRange']['earliest'] or timestamp < summary['dateRange']['earliest']:
                    summary['dateRange']['earliest'] = timestamp
                if not summary['dateRange']['latest'] or timestamp > summary['dateRange']['latest']:
                    summary['dateRange']['latest'] = timestamp
        
        # Convert set to list for JSON serialization
        summary['uniqueActors'] = list(summary['uniqueActors'])
        summary['eventTypeCounts'] = dict(summary['eventTypeCounts'])
        
        return summary
    
    def generate_audit_report(self, entries: List[Dict[str, Any]]) -> Dict[str, Any]:
        """
        Generate a comprehensive audit report.
        
        Args:
            entries: List of log entries
            
        Returns:
            Complete audit report
        """
        report = {
            'reportMetadata': {
                'generatedAt': datetime.now(timezone.utc).isoformat(),
                'generatorVersion': '1.0.0',
                'totalEntriesAnalyzed': len(entries),
            },
            'summary': self.generate_summary(entries),
            'eventsByType': self.aggregate_by_event_type(entries),
            'detailedEntries': entries,
        }
        
        return report
    
    def run(self, start_date: datetime, end_date: datetime, 
            event_type: Optional[str], output_file: Optional[str]) -> bool:
        """
        Run the complete audit log generation process.
        
        Args:
            start_date: Start of the date range
            end_date: End of the date range
            event_type: Event type to filter by
            output_file: Output file path
            
        Returns:
            True if successful, False otherwise
        """
        print(f"Audit Log Generation")
        print(f"Date Range: {start_date.date()} to {end_date.date()}")
        if event_type:
            print(f"Event Type Filter: {event_type}")
        print(f"Started: {datetime.now().isoformat()}")
        print("=" * 60)
        
        try:
            # Find log files
            log_files = self.find_log_files(start_date, end_date)
            if self.verbose:
                print(f"Found {len(log_files)} log files")
            
            if not log_files:
                print("No log files found for the specified date range.")
                # Create empty report
                report = self.generate_audit_report([])
            else:
                # Load and filter logs
                entries = self.load_logs(log_files, start_date, end_date, event_type)
                if self.verbose:
                    print(f"Loaded {len(entries)} matching entries")
                
                # Generate report
                report = self.generate_audit_report(entries)
            
            # Print summary
            print("\n" + "=" * 60)
            print("Summary:")
            print(f"  Total Entries: {report['summary']['totalEntries']}")
            print(f"  Unique Actors: {len(report['summary']['uniqueActors'])}")
            print(f"  Event Types: {len(report['summary']['eventTypeCounts'])}")
            if report['summary']['dateRange']['earliest']:
                print(f"  Date Range: {report['summary']['dateRange']['earliest'][:10]} to {report['summary']['dateRange']['latest'][:10]}")
            print("=" * 60)
            
            # Event type breakdown
            if report['summary']['eventTypeCounts']:
                print("\nEvent Type Breakdown:")
                for event_type, count in sorted(report['summary']['eventTypeCounts'].items()):
                    print(f"  {event_type}: {count}")
            
            # Write output
            if output_file:
                output_path = Path(output_file)
                output_path.parent.mkdir(parents=True, exist_ok=True)
                
                with open(output_path, 'w') as f:
                    json.dump(report, f, indent=2)
                
                print(f"\nAudit report written to: {output_path}")
            else:
                # Print to stdout
                print("\n" + "=" * 60)
                print("Detailed Entries:")
                for entry in report['detailedEntries']:
                    print(json.dumps(entry, indent=2))
            
            print(f"\nCompleted: {datetime.now().isoformat()}")
            return True
            
        except Exception as e:
            print(f"\nError during audit log generation: {e}", file=sys.stderr)
            return False


def parse_date(date_str: str) -> datetime:
    """
    Parse a date string in YYYY-MM-DD format.
    
    Args:
        date_str: Date string
        
    Returns:
        datetime object
    """
    return datetime.strptime(date_str, '%Y-%m-%d').replace(
        hour=0, minute=0, second=0, microsecond=0, tzinfo=timezone.utc
    )


def main():
    """Main entry point for the script."""
    parser = argparse.ArgumentParser(
        description="Generate audit logs for the Personal Credit Authority system."
    )
    parser.add_argument(
        "--start-date", "-s",
        default=(datetime.now(timezone.utc) - timedelta(days=30)).strftime('%Y-%m-%d'),
        help="Start date in YYYY-MM-DD format (default: 30 days ago)"
    )
    parser.add_argument(
        "--end-date", "-e",
        default=datetime.now(timezone.utc).strftime('%Y-%m-%d'),
        help="End date in YYYY-MM-DD format (default: today)"
    )
    parser.add_argument(
        "--event-type", "-t",
        help="Filter by event type (optional)"
    )
    parser.add_argument(
        "--output", "-o",
        help="Output file path (prints to stdout if not specified)"
    )
    parser.add_argument(
        "--path",
        help="Base path to the repository (defaults to current directory)"
    )
    parser.add_argument(
        "--verbose", "-v",
        action="store_true",
        help="Enable verbose output"
    )
    
    args = parser.parse_args()
    
    try:
        start_date = parse_date(args.start_date)
        end_date = parse_date(args.end_date)
    except ValueError as e:
        print(f"Error parsing date: {e}", file=sys.stderr)
        sys.exit(1)
    
    generator = AuditLogGenerator(
        base_path=args.path,
        verbose=args.verbose
    )
    
    success = generator.run(start_date, end_date, args.event_type, args.output)
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()
