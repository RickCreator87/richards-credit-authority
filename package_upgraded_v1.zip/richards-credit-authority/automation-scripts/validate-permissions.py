#!/usr/bin/env python3
"""
Validate Permissions Script

This script validates permission matrices against the permission schema,
checks for consistency between roles and actions, and verifies that
multi-signature and override rules are properly configured.

Usage:
    python validate-permissions.py [--verbose] [--strict] [--output FILE]

Author: MiniMax Agent
Version: 1.0.0
"""

import argparse
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Any, List, Set, Tuple, Optional


class PermissionValidator:
    """
    Validates permission matrices for the Personal Credit Authority.
    """
    
    def __init__(self, base_path: Optional[str] = None, verbose: bool = False, strict: bool = False):
        """
        Initialize the permission validator.
        
        Args:
            base_path: Base directory path for the repository
            verbose: Enable verbose output
            strict: Enable strict validation mode
        """
        self.base_path = Path(base_path) if base_path else Path.cwd()
        self.verbose = verbose
        self.strict = strict
        self.permission_dir = self.base_path / "permission"
        self.schema_dir = self.base_path / "authority" / "schema"
        
        # Load schemas
        self.matrix_schema = self._load_schema("permission-matrix.schema.json")
        self.role_action_matrix = self._load_role_action_matrix()
        
        # Validation results
        self.warnings: List[str] = []
        self.errors: List[str] = []
        self.info: List[str] = []
        
        # Known valid roles
        self.valid_roles = {'founder', 'auditor', 'contributor', 'viewer', 'admin'}
        
        # Known valid actions
        self.valid_actions = {
            'read', 'write', 'delete', 'approve', 'override', 
            'freeze', 'audit', 'configure', 'invite', 'remove'
        }
    
    def _load_schema(self, schema_file: str) -> Dict[str, Any]:
        """Load a schema file."""
        schema_path = self.schema_dir / schema_file
        if schema_path.exists():
            with open(schema_path, 'r') as f:
                return json.load(f)
        return {}
    
    def _load_role_action_matrix(self) -> Dict[str, Any]:
        """Load the role-action matrix."""
        matrix_path = self.permission_dir / "role-action-matrix.json"
        if matrix_path.exists():
            with open(matrix_path, 'r') as f:
                return json.load(f)
        return {}
    
    def log_info(self, message: str) -> None:
        """Log an info message."""
        self.info.append(message)
        if self.verbose:
            print(f"  INFO: {message}")
    
    def log_warning(self, message: str) -> None:
        """Log a warning message."""
        self.warnings.append(message)
        if self.verbose or self.strict:
            print(f"  WARNING: {message}")
    
    def log_error(self, message: str) -> None:
        """Log an error message."""
        self.errors.append(message)
        print(f"  ERROR: {message}")
    
    def validate_matrix_structure(self) -> bool:
        """
        Validate the structure of the permission matrix.
        
        Returns:
            True if validation passes, False otherwise
        """
        valid = True
        
        if not self.role_action_matrix:
            self.log_error("Role-action matrix is empty or not found")
            return False
        
        # Check for required sections
        if 'roles' not in self.role_action_matrix:
            self.log_error("Matrix missing 'roles' section")
            valid = False
        
        if 'user_roles' not in self.role_action_matrix:
            self.log_warning("Matrix missing 'user_roles' section")
        
        # Validate each role
        roles = self.role_action_matrix.get('roles', {})
        for role, permissions in roles.items():
            if not isinstance(permissions, dict):
                self.log_error(f"Role '{role}' permissions must be an object")
                valid = False
                continue
            
            # Check for unknown actions
            for action in permissions.keys():
                if action not in self.valid_actions and not action.startswith('can_'):
                    self.log_warning(f"Unknown action '{action}' for role '{role}'")
        
        # Check for required roles
        required_roles = {'founder', 'auditor'}
        for role in required_roles:
            if role not in roles:
                self.log_error(f"Missing required role: {role}")
                valid = False
        
        # Validate founder role permissions
        if 'founder' in roles:
            founder_perms = roles['founder']
            # Founder should have all permissions
            founder_actions = set(founder_perms.keys())
            expected_actions = {'can_override', 'can_audit', 'can_freeze', 'can_delete'}
            for action in expected_actions:
                if action not in founder_actions and action.replace('can_', '') not in founder_actions:
                    self.log_warning(f"Founder role may be missing expected permission: {action}")
        
        # Validate auditor role permissions
        if 'auditor' in roles:
            auditor_perms = roles['auditor']
            if auditor_perms.get('can_override_audit', False):
                self.log_error("Auditor role cannot have audit override permission")
                valid = False
        
        return valid
    
    def validate_user_role_assignments(self) -> bool:
        """
        Validate user-to-role assignments.
        
        Returns:
            True if validation passes, False otherwise
        """
        valid = True
        
        user_roles = self.role_action_matrix.get('user_roles', {})
        
        for user, roles in user_roles.items():
            if not isinstance(roles, list):
                self.log_error(f"User '{user}' roles must be a list")
                valid = False
                continue
            
            for role in roles:
                if role not in self.valid_roles:
                    self.log_error(f"User '{user}' has invalid role: {role}")
                    valid = False
        
        # Check for users without roles
        if not user_roles:
            self.log_warning("No users have role assignments")
        
        return valid
    
    def validate_multisig_rules(self) -> bool:
        """
        Validate multi-signature approval rules.
        
        Returns:
            True if validation passes, False otherwise
        """
        valid = True
        
        multisig_path = self.permission_dir / "multisig-approval-rules.json"
        if not multisig_path.exists():
            self.log_warning("Multi-signature approval rules file not found")
            return True
        
        try:
            with open(multisig_path, 'r') as f:
                multisig_rules = json.load(f)
        except json.JSONDecodeError as e:
            self.log_error(f"Invalid JSON in multisig rules: {e}")
            return False
        
        # Validate threshold
        threshold = multisig_rules.get('threshold', 0)
        if threshold < 1:
            self.log_error("Multi-signature threshold must be at least 1")
            valid = False
        elif threshold > 10:
            self.log_warning("Multi-signature threshold is very high (> 10)")
        
        # Validate required approvers
        required_approvers = multisig_rules.get('required_approvers', [])
        if not isinstance(required_approvers, list):
            self.log_error("Required approvers must be a list")
            valid = False
        else:
            for approver in required_approvers:
                if not isinstance(approver, dict):
                    self.log_error("Approver specification must be an object")
                    valid = False
                    continue
                
                if 'role' not in approver:
                    self.log_error("Approver specification missing 'role'")
                    valid = False
        
        return valid
    
    def validate_override_rules(self) -> bool:
        """
        Validate founder override rules.
        
        Returns:
            True if validation passes, False otherwise
        """
        valid = True
        
        override_path = self.permission_dir / "founder-override-rules.json"
        if not override_path.exists():
            self.log_warning("Founder override rules file not found")
            return True
        
        try:
            with open(override_path, 'r') as f:
                override_rules = json.load(f)
        except json.JSONDecodeError as e:
            self.log_error(f"Invalid JSON in override rules: {e}")
            return False
        
        # Validate structure
        if 'allowed' not in override_rules:
            self.log_error("Override rules missing 'allowed' field")
            valid = False
        
        if 'audit_required' not in override_rules:
            self.log_warning("Override rules missing 'audit_required' field")
        
        # Validate audit requirements
        if override_rules.get('allowed', False) and not override_rules.get('audit_required', False):
            self.log_warning("Founder override is allowed without audit requirement")
        
        return valid
    
    def validate_freeze_rules(self) -> bool:
        """
        Validate emergency freeze rules.
        
        Returns:
            True if validation passes, False otherwise
        """
        valid = True
        
        freeze_path = self.permission_dir / "emergency-freeze-rules.json"
        if not freeze_path.exists():
            self.log_warning("Emergency freeze rules file not found")
            return True
        
        try:
            with open(freeze_path, 'r') as f:
                freeze_rules = json.load(f)
        except json.JSONDecodeError as e:
            self.log_error(f"Invalid JSON in freeze rules: {e}")
            return False
        
        # Validate max duration
        max_duration = freeze_rules.get('max_duration_hours', 0)
        if max_duration < 1:
            self.log_error("Freeze max duration must be at least 1 hour")
            valid = False
        elif max_duration > 720:  # 30 days
            self.log_warning("Freeze max duration is very long (> 720 hours)")
        
        # Validate approval requirements
        if freeze_rules.get('requires_approval', False):
            if 'approval_roles' not in freeze_rules:
                self.log_error("Freeze rules require approval but don't specify approval roles")
                valid = False
        
        return valid
    
    def check_security_constraints(self) -> bool:
        """
        Check for security-sensitive permission configurations.
        
        Returns:
            True if all security checks pass, False otherwise
        """
        valid = True
        
        roles = self.role_action_matrix.get('roles', {})
        
        # Check for dangerous permission combinations
        for role, permissions in roles.items():
            if role == 'contributor':
                # Contributors should not have delete or override permissions
                dangerous_perms = ['can_delete', 'can_override', 'can_override_audit']
                for perm in dangerous_perms:
                    if permissions.get(perm, False):
                        self.log_warning(f"Contributor role has dangerous permission: {perm}")
        
        # Check for roles with audit override
        for role, permissions in roles.items():
            if permissions.get('can_override_audit', False) and role != 'founder':
                self.log_error(f"Non-founder role '{role}' has audit override permission")
                valid = False
        
        # Check for users with both admin and auditor roles
        user_roles = self.role_action_matrix.get('user_roles', {})
        for user, roles_list in user_roles.items():
            if 'admin' in roles_list and 'auditor' in roles_list:
                self.log_warning(f"User '{user}' has both admin and auditor roles")
        
        return valid
    
    def validate(self) -> bool:
        """
        Run complete permission validation.
        
        Returns:
            True if all validations pass, False otherwise
        """
        print("Permission Matrix Validation")
        print("=" * 60)
        
        matrix_path = self.permission_dir / "role-action-matrix.json"
        
        if not matrix_path.exists():
            self.log_error("Permission matrix not found")
            return False
        
        print(f"Validating: {matrix_path}")
        print("-" * 60)
        
        # Run validations
        structure_valid = self.validate_matrix_structure()
        user_valid = self.validate_user_role_assignments()
        multisig_valid = self.validate_multisig_rules()
        override_valid = self.validate_override_rules()
        freeze_valid = self.validate_freeze_rules()
        security_valid = self.check_security_constraints()
        
        # Print results
        print("\n" + "=" * 60)
        print("Validation Results:")
        print(f"  Matrix Structure: {'PASS' if structure_valid else 'FAIL'}")
        print(f"  User Assignments: {'PASS' if user_valid else 'FAIL'}")
        print(f"  Multi-Signature Rules: {'PASS' if multisig_valid else 'FAIL'}")
        print(f"  Override Rules: {'PASS' if override_valid else 'FAIL'}")
        print(f"  Freeze Rules: {'PASS' if freeze_valid else 'FAIL'}")
        print(f"  Security Constraints: {'PASS' if security_valid else 'FAIL'}")
        
        if self.warnings:
            print(f"\nWarnings: {len(self.warnings)}")
            for warning in self.warnings[:5]:  # Show first 5 warnings
                print(f"  - {warning}")
            if len(self.warnings) > 5:
                print(f"  ... and {len(self.warnings) - 5} more")
        
        if self.errors:
            print(f"\nErrors: {len(self.errors)}")
            for error in self.errors:
                print(f"  - {error}")
        
        print("=" * 60)
        
        all_valid = (structure_valid and user_valid and multisig_valid 
                    and override_valid and freeze_valid and security_valid)
        
        if all_valid:
            print("\n✓ Permission validation PASSED")
        else:
            print("\n✗ Permission validation FAILED")
        
        return all_valid


def main():
    """Main entry point for the script."""
    parser = argparse.ArgumentParser(
        description="Validate permission matrices and rules."
    )
    parser.add_argument(
        "--verbose", "-v",
        action="store_true",
        help="Enable verbose output"
    )
    parser.add_argument(
        "--strict", "-s",
        action="store_true",
        help="Enable strict validation (warnings cause failure)"
    )
    parser.add_argument(
        "--output", "-o",
        help="Output file path for results (optional)"
    )
    parser.add_argument(
        "--path",
        help="Base path to the repository (defaults to current directory)"
    )
    
    args = parser.parse_args()
    
    validator = PermissionValidator(
        base_path=args.path,
        verbose=args.verbose,
        strict=args.strict
    )
    
    success = validator.validate()
    
    if args.output and success:
        output_path = Path(args.output)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        
        results = {
            'timestamp': datetime.now(timezone.utc).isoformat(),
            'valid': success,
            'warnings': validator.warnings,
            'errors': validator.errors,
            'info': validator.info,
        }
        
        with open(output_path, 'w') as f:
            json.dump(results, f, indent=2)
        
        print(f"\nResults written to: {output_path}")
    
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()
