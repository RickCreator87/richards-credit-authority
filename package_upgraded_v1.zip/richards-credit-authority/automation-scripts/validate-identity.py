#!/usr/bin/env python3
"""
Validate Identity Script

This script validates identity manifests against the identity schema,
verifies identity proofs, and checks for consistency between identity
records and related system data.

Usage:
    python validate-identity.py [--verbose] [--strict] [--output FILE]

Author: MiniMax Agent
Version: 1.0.0
"""

import argparse
import hashlib
import json
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, Any, List, Tuple, Optional


class IdentityValidator:
    """
    Validates identity manifests and proofs for the Personal Credit Authority.
    """
    
    def __init__(self, base_path: Optional[str] = None, verbose: bool = False, strict: bool = False):
        """
        Initialize the identity validator.
        
        Args:
            base_path: Base directory path for the repository
            verbose: Enable verbose output
            strict: Enable strict validation mode
        """
        self.base_path = Path(base_path) if base_path else Path.cwd()
        self.verbose = verbose
        self.strict = strict
        self.identity_dir = self.base_path / "identity"
        self.schema_dir = self.base_path / "authority" / "schema"
        
        # Load schema
        self.identity_schema = self._load_schema()
        
        # Validation results
        self.warnings: List[str] = []
        self.errors: List[str] = []
        self.info: List[str] = []
    
    def _load_schema(self) -> Dict[str, Any]:
        """Load the identity schema."""
        schema_path = self.schema_dir / "identity.schema.json"
        if schema_path.exists():
            with open(schema_path, 'r') as f:
                return json.load(f)
        return {}
    
    def log_info(self, message: str) -> None:
        """Log an info message."""
        self.info.append(message)
        if self.verbose:
            print(f"  INFO: {message}")
    
    def log_warning(self, message: str) -> None:
        """Log a warning message."""
        self.warnings.append(message)
        if self.verbose or self.strict:
            print(f"  WARNING: {message}")
    
    def log_error(self, message: str) -> None:
        """Log an error message."""
        self.errors.append(message)
        print(f"  ERROR: {message}")
    
    def validate_manifest_structure(self, manifest: Dict[str, Any]) -> bool:
        """
        Validate the structure of an identity manifest against the schema.
        
        Args:
            manifest: The identity manifest to validate
            
        Returns:
            True if validation passes, False otherwise
        """
        valid = True
        
        # Check required top-level fields
        required_fields = ['identityId', 'schemaVersion', 'identityType', 
                          'legalName', 'residency', 'taxInformation', 'verification']
        
        for field in required_fields:
            if field not in manifest:
                self.log_error(f"Missing required field: {field}")
                valid = False
        
        # Validate identity ID format (UUID v4)
        if 'identityId' in manifest:
            identity_id = manifest['identityId']
            if not self._is_valid_uuid4(identity_id):
                self.log_error(f"Invalid identity ID format (must be UUID v4): {identity_id}")
                valid = False
        
        # Validate schema version
        if 'schemaVersion' in manifest:
            schema_version = manifest.get('schemaVersion')
            if schema_version != '1.0.0':
                self.log_warning(f"Schema version mismatch: expected 1.0.0, got {schema_version}")
        
        # Validate legal name structure
        if 'legalName' in manifest:
            legal_name = manifest['legalName']
            if not isinstance(legal_name, dict):
                self.log_error("legalName must be an object")
                valid = False
            else:
                required_name_parts = ['givenName', 'familyName']
                for part in required_name_parts:
                    if part not in legal_name:
                        self.log_error(f"Missing legal name part: {part}")
                        valid = False
        
        # Validate residency structure
        if 'residency' in manifest:
            residency = manifest['residency']
            if not isinstance(residency, dict):
                self.log_error("residency must be an object")
                valid = False
            else:
                if 'country' not in residency:
                    self.log_error("Missing residency field: country")
                    valid = False
        
        # Validate tax information structure
        if 'taxInformation' in manifest:
            tax_info = manifest['taxInformation']
            if not isinstance(tax_info, dict):
                self.log_error("taxInformation must be an object")
                valid = False
            else:
                if 'taxId' not in tax_info:
                    self.log_error("Missing tax information field: taxId")
                    valid = False
                if 'taxResidency' not in tax_info:
                    self.log_error("Missing tax information field: taxResidency")
                    valid = False
        
        # Validate verification status
        if 'verification' in manifest:
            verification = manifest['verification']
            if not isinstance(verification, dict):
                self.log_error("verification must be an object")
                valid = False
            else:
                required_verification = ['status']
                for field in required_verification:
                    if field not in verification:
                        self.log_error(f"Missing verification field: {field}")
                        valid = False
        
        return valid
    
    def _is_valid_uuid4(self, value: str) -> bool:
        """
        Check if a string is a valid UUID v4.
        
        Args:
            value: String to check
            
        Returns:
            True if valid UUID v4, False otherwise
        """
        import re
        uuid_pattern = r'^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-4[0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}$'
        return bool(re.match(uuid_pattern, value))
    
    def validate_proof(self, manifest: Dict[str, Any]) -> Tuple[bool, bool]:
        """
        Validate the identity proof against the manifest.
        
        Args:
            manifest: The identity manifest
            
        Returns:
            Tuple of (has_proof: bool, is_valid: bool)
        """
        proof_path = self.identity_dir / "identity-proof.hash"
        
        if not proof_path.exists():
            self.log_warning("Identity proof file not found")
            return False, False
        
        # Read the proof
        with open(proof_path, 'r') as f:
            stored_proof = f.read().strip()
        
        # Compute expected proof
        expected_proof = self._compute_proof(manifest)
        
        # Compare proofs
        if stored_proof == expected_proof:
            self.log_info("Identity proof is valid")
            return True, True
        else:
            self.log_error("Identity proof mismatch - manifest may have been modified")
            self.log_info(f"Stored proof: {stored_proof}")
            self.log_info(f"Expected proof: {expected_proof}")
            return True, False
    
    def _compute_proof(self, manifest: Dict[str, Any]) -> str:
        """
        Compute the identity proof hash from a manifest.
        
        Args:
            manifest: The identity manifest
            
        Returns:
            Computed proof hash
        """
        # Create canonical representation for hashing
        canonical = {
            'identityId': manifest.get('identityId', ''),
            'legalName': manifest.get('legalName', {}),
            'dateOfBirth': manifest.get('dateOfBirth', ''),
            'taxId': manifest.get('taxInformation', {}).get('taxId', ''),
            'taxResidency': manifest.get('taxInformation', {}).get('taxResidency', ''),
        }
        
        canonical_json = json.dumps(canonical, sort_keys=True)
        return hashlib.sha256(canonical_json.encode()).hexdigest()
    
    def check_related_files(self, manifest: Dict[str, Any]) -> bool:
        """
        Check consistency between identity and related system files.
        
        Args:
            manifest: The identity manifest
            
        Returns:
            True if all checks pass, False otherwise
        """
        valid = True
        
        # Check if identity ID matches authority data
        authority_data_path = self.base_path / "authority" / "authority-data.json"
        if authority_data_path.exists():
            with open(authority_data_path, 'r') as f:
                authority_data = json.load(f)
            
            stored_identity_id = authority_data.get('identityId')
            manifest_identity_id = manifest.get('identityId')
            
            if stored_identity_id and stored_identity_id != manifest_identity_id:
                self.log_warning("Authority data has different identity ID")
                valid = False
        
        # Check verification timestamp
        verification = manifest.get('verification', {})
        status = verification.get('status', 'unverified')
        
        if status == 'verified':
            verified_at = verification.get('verifiedAt')
            if not verified_at:
                self.log_warning("Identity is marked as verified but has no verification timestamp")
            else:
                try:
                    verified_date = datetime.fromisoformat(verified_at.replace('Z', '+00:00'))
                    if verified_date > datetime.now(timezone.utc):
                        self.log_warning("Verification timestamp is in the future")
                except ValueError:
                    self.log_warning("Invalid verification timestamp format")
        
        # Check for expired verification
        if status == 'verified':
            verified_at = verification.get('verifiedAt')
            if verified_at:
                try:
                    verified_date = datetime.fromisoformat(verified_at.replace('Z', '+00:00'))
                    age = datetime.now(timezone.utc) - verified_date
                    if age.days > 365:
                        self.log_warning("Identity verification is over 1 year old - consider re-verification")
                except ValueError:
                    pass
        
        return valid
    
    def validate(self) -> bool:
        """
        Run complete identity validation.
        
        Returns:
            True if all validations pass, False otherwise
        """
        print("Identity Validation")
        print("=" * 60)
        
        manifest_path = self.identity_dir / "identity-manifest.json"
        
        if not manifest_path.exists():
            self.log_error("Identity manifest not found")
            return False
        
        print(f"Validating: {manifest_path}")
        
        # Load manifest
        try:
            with open(manifest_path, 'r') as f:
                manifest = json.load(f)
        except json.JSONDecodeError as e:
            self.log_error(f"Invalid JSON in manifest: {e}")
            return False
        
        print("-" * 60)
        
        # Run validations
        structure_valid = self.validate_manifest_structure(manifest)
        has_proof, proof_valid = self.validate_proof(manifest)
        related_valid = self.check_related_files(manifest)
        
        # Print results
        print("\n" + "=" * 60)
        print("Validation Results:")
        print(f"  Structure: {'PASS' if structure_valid else 'FAIL'}")
        print(f"  Proof: {'N/A' if not has_proof else ('PASS' if proof_valid else 'FAIL')}")
        print(f"  Related Files: {'PASS' if related_valid else 'FAIL'}")
        
        if self.warnings:
            print(f"\nWarnings: {len(self.warnings)}")
            for warning in self.warnings:
                print(f"  - {warning}")
        
        if self.errors:
            print(f"\nErrors: {len(self.errors)}")
            for error in self.errors:
                print(f"  - {error}")
        
        print("=" * 60)
        
        all_valid = structure_valid and (not has_proof or proof_valid) and related_valid
        
        if all_valid:
            print("\n✓ Identity validation PASSED")
        else:
            print("\n✗ Identity validation FAILED")
        
        return all_valid


def main():
    """Main entry point for the script."""
    parser = argparse.ArgumentParser(
        description="Validate identity manifests and proofs."
    )
    parser.add_argument(
        "--verbose", "-v",
        action="store_true",
        help="Enable verbose output"
    )
    parser.add_argument(
        "--strict", "-s",
        action="store_true",
        help="Enable strict validation (warnings cause failure)"
    )
    parser.add_argument(
        "--output", "-o",
        help="Output file path for results (optional)"
    )
    parser.add_argument(
        "--path",
        help="Base path to the repository (defaults to current directory)"
    )
    
    args = parser.parse_args()
    
    validator = IdentityValidator(
        base_path=args.path,
        verbose=args.verbose,
        strict=args.strict
    )
    
    success = validator.validate()
    
    if args.output and success:
        output_path = Path(args.output)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        
        results = {
            'timestamp': datetime.now(timezone.utc).isoformat(),
            'valid': success,
            'warnings': validator.warnings,
            'errors': validator.errors,
            'info': validator.info,
        }
        
        with open(output_path, 'w') as f:
            json.dump(results, f, indent=2)
        
        print(f"\nResults written to: {output_path}")
    
    sys.exit(0 if success else 1)


if __name__ == "__main__":
    main()
