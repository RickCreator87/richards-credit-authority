# Lending Capacity Formula

This document defines the mathematical formulas and calculation methodology for determining lending capacity within the Personal Credit Authority system. The formula implements a tax-first governance model where tax obligations take priority over all other lending calculations.

## Overview

The lending capacity formula calculates the maximum amount that can be lent to an identity holder based on their financial profile, risk assessment, and compliance with governance rules. The calculation follows a hierarchical priority structure where tax obligations are deducted first, followed by debt service requirements, with the remaining capacity adjusted for risk factors and regulatory limits.

The formula is designed to be deterministic, meaning that the same inputs will always produce the same output when calculated using the standard methodology. This predictability enables identity holders to plan their financial activities with confidence and provides lending partners with consistent capacity information for underwriting decisions.

All monetary values in the formula are expressed in cents (the smallest currency unit) to avoid floating-point precision errors. Income, assets, debts, and other financial figures must be converted to cents before inclusion in calculations. The final lending capacity is expressed in cents with a currency identifier.

## Formula Components

The lending capacity calculation consists of four primary components that are combined through a specific sequence. The components are calculated independently and then assembled according to the formula hierarchy. Understanding each component and its role in the overall calculation is essential for proper implementation.

### Component A: Gross Lending Capacity

The gross lending capacity establishes the maximum theoretical lending amount based on income and assets before any deductions or limitations. This component uses income multipliers and asset contributions to establish a baseline that will be refined through subsequent calculations.

The gross lending capacity is calculated as the sum of income-based capacity and asset-based capacity. Income-based capacity uses a multiplier applied to verified net annual income, while asset-based capacity uses a different multiplier applied to verified liquid assets. The multipliers vary based on verification level and risk tier.

```
GrossLendingCapacity = (NetAnnualIncome × IncomeMultiplier) + (LiquidAssets × AssetMultiplier)
```

The income multiplier ranges from 2.0 for minimal verification to 4.0 for premium verification with minimal risk profile. The asset multiplier ranges from 0.5 to 0.8 depending on asset type, with cash receiving the highest multiplier and illiquid assets receiving lower multipliers.

For example, an identity holder with $120,000 net annual income and $50,000 in liquid assets at standard verification (multiplier of 3.0 for income and 0.7 for assets) would have:

```
GrossLendingCapacity = ($120,000 × 3.0) + ($50,000 × 0.7)
                     = $360,000 + $35,000
                     = $395,000
```

### Component B: Tax Deduction

The tax-first governance principle requires that tax obligations be deducted from gross lending capacity before any other calculations. This ensures that tax obligations take absolute priority over lending activities and that the system never enables lending that would compromise tax compliance.

The tax deduction includes the annual tax liability for the current tax year plus any outstanding tax balance from previous years. The deduction is calculated as:

```
TaxDeduction = AnnualTaxLiability + OutstandingTaxBalance
```

If the tax payment status is "delinquent," an additional penalty multiplier of 1.25 is applied to the outstanding balance portion of the deduction. This penalty reflects the elevated risk associated with tax delinquency and provides additional protection for the system.

```
if TaxPaymentStatus = "delinquent":
    TaxDeduction = AnnualTaxLiability + (OutstandingTaxBalance × 1.25)
else:
    TaxDeduction = AnnualTaxLiability + OutstandingTaxBalance
```

Continuing the previous example, if the identity holder has an annual tax liability of $24,000 and no outstanding balance:

```
TaxDeduction = $24,000
```

### Component C: Debt Service Deduction

After tax obligations are deducted, the formula accounts for existing debt service requirements. This deduction ensures that the lending capacity calculation considers the borrower's ability to service additional debt based on their existing obligations.

The debt service deduction is calculated by determining the maximum allowable debt payment based on the debt-to-income ratio limit and comparing it to actual debt payments. The lesser of actual payments or maximum allowable payments is deducted.

```
DebtToIncomeRatioLimit = 0.43  // Maximum DTI ratio allowed
MaximumAllowableDebtPayment = NetMonthlyIncome × DebtToIncomeRatioLimit
ActualDebtPayment = Sum of all monthly debt payments

DebtServiceDeduction = min(MaximumAllowableDebtPayment, ActualDebtPayment) × 12
```

The 0.43 debt-to-income ratio limit is derived from the Consumer Financial Protection Bureau guidelines for qualified mortgages and represents a conservative threshold for sustainable debt levels.

If the identity holder has $2,000 in monthly debt payments and net monthly income of $8,000 (net annual income of $96,000):

```
MaximumAllowableDebtPayment = $8,000 × 0.43 = $3,440
ActualDebtPayment = $2,000
DebtServiceDeduction = $2,000 × 12 = $24,000
```

### Component D: Risk Adjustment

The risk adjustment applies positive or negative modifications to the lending capacity based on the calculated risk tier and individual risk factors. This component enables the system to calibrate lending capacity based on comprehensive risk assessment beyond simple income and debt metrics.

The risk adjustment is expressed as a percentage of the capacity remaining after tax and debt deductions. Positive adjustments increase capacity for low-risk profiles, while negative adjustments decrease capacity for elevated risk profiles.

```
BaseCapacity = GrossLendingCapacity - TaxDeduction - DebtServiceDeduction

RiskAdjustmentPercentage = RiskTierScore / 100  // Convert 0-100 score to percentage
                          × RiskDirection  // -1 for negative, +1 for positive

RiskAdjustment = BaseCapacity × RiskAdjustmentPercentage
```

The risk direction is determined by the risk tier level. Minimal and low risk tiers use positive direction (capacity enhancement), moderate and elevated tiers use neutral direction (no adjustment), and high and critical tiers use negative direction (capacity reduction).

For an identity holder with a "low" risk tier (score of 25) and BaseCapacity of $347,000 (from previous calculations):

```
RiskAdjustmentPercentage = 25 / 100 × (+1) = 0.25
RiskAdjustment = $347,000 × 0.25 = $86,750
```

## Final Calculation

The final lending capacity is assembled by combining the base capacity with the risk adjustment and then applying regulatory limits. The calculation sequence is critical to ensure correct application of all deductions and adjustments.

```
Step 1: Calculate GrossLendingCapacity
Step 2: Calculate TaxDeduction
Step 3: Calculate DebtServiceDeduction
Step 4: Calculate BaseCapacity = GrossLendingCapacity - TaxDeduction - DebtServiceDeduction
Step 5: Calculate RiskAdjustment
Step 6: Calculate AdjustedCapacity = BaseCapacity + RiskAdjustment
Step 7: Apply AnnualLendingLimit
Step 8: Apply LoanToIncomeLimit
Step 9: Apply LoanToTaxLimit
Step 10: FinalLendingCapacity = max(0, result after all steps)
```

Applying this to our example:

```
Step 1: GrossLendingCapacity = $395,000
Step 2: TaxDeduction = $24,000
Step 3: DebtServiceDeduction = $24,000
Step 4: BaseCapacity = $395,000 - $24,000 - $24,000 = $347,000
Step 5: RiskAdjustment = $86,750
Step 6: AdjustedCapacity = $347,000 + $86,750 = $433,750
Step 7-9: Apply limits (assume all limits exceed AdjustedCapacity)
Step 10: FinalLendingCapacity = $433,750
```

## Regulatory Limit Application

After the base calculation, several regulatory limits cap the lending capacity to ensure compliance with lending regulations and prudent risk management. These limits are applied in a specific order to ensure the most restrictive limit takes precedence.

### Annual Lending Limit

The annual lending limit caps the maximum lending capacity based on the identity holder's overall financial profile and regulatory requirements. This limit prevents excessive concentration of lending risk and ensures alignment with regulatory capital requirements.

```
AnnualLendingLimit = min(
    IndividualLoanLimit,
    TotalOutstandingLimit,
    AggregatedLimit
)
```

The limits are determined by verification level and risk tier, with higher verification levels and lower risk tiers receiving higher limits. The specific limits are configured in the annual-lending-limit.json file.

### Loan-to-Income Limit

The loan-to-income limit ensures that total lending exposure does not exceed a reasonable multiple of annual income. This limit protects both the borrower and the system from over-leveraged positions.

```
LoanToIncomeLimit = NetAnnualIncome × LoanToIncomeRatio
```

The LoanToIncomeRatio varies by verification level, ranging from 3.0 for minimal verification to 5.0 for premium verification. The specific ratios are configured in the loan-to-income-rules.json file.

### Loan-to-Tax Limit

The loan-to-tax limit implements the tax-first governance principle by ensuring that lending capacity never exceeds a maximum multiple of annual tax liability. This limit provides a final backstop to protect tax priority.

```
LoanToTaxLimit = AnnualTaxLiability × LoanToTaxRatio
```

The LoanToTaxRatio is set at 15.0 for all verification levels, ensuring that lending capacity does not exceed 15 times annual tax liability. This provides significant lending capacity while maintaining the priority of tax obligations. The specific ratio is configured in the loan-to-tax-rules.json file.

## Verification Level Modifiers

The calculation applies different modifiers based on the identity holder's verification level. Higher verification levels provide access to higher multipliers, lower risk weightings, and higher regulatory limits.

### Minimal Verification Level

Minimal verification applies the most conservative multipliers and limits. This level is appropriate for newly verified identities or identities where full documentation is not available.

- Income Multiplier: 2.0
- Asset Multiplier: 0.5
- Loan-to-Income Ratio: 3.0
- Annual Lending Caps: Reduced by 50% from standard

### Standard Verification Level

Standard verification applies moderate multipliers and limits. This level represents the baseline for most verified identities with complete documentation.

- Income Multiplier: 3.0
- Asset Multiplier: 0.7
- Loan-to-Income Ratio: 4.0
- Annual Lending Caps: Standard values

### Premium Verification Level

Premium verification applies the most favorable multipliers and limits. This level requires enhanced documentation and ongoing verification.

- Income Multiplier: 4.0
- Asset Multiplier: 0.8
- Loan-to-Income Ratio: 5.0
- Annual Lending Caps: Increased by 25% from standard

## Risk Tier Modifiers

The calculation applies risk adjustments based on the calculated risk tier. The risk tier is determined by evaluating multiple risk factors and their weights in the overall risk score.

### Minimal Risk Tier (Score 0-10)

Minimal risk tier represents the most creditworthy identity holders with excellent financial profiles. This tier receives positive capacity adjustments.

- Risk Direction: Positive (+1)
- Adjustment Range: +20% to +30%

### Low Risk Tier (Score 11-25)

Low risk tier represents creditworthy identity holders with good financial profiles. This tier receives moderate positive capacity adjustments.

- Risk Direction: Positive (+1)
- Adjustment Range: +10% to +20%

### Moderate Risk Tier (Score 26-40)

Moderate risk tier represents identity holders with acceptable financial profiles. This tier receives no capacity adjustment.

- Risk Direction: Neutral (0)
- Adjustment Range: 0%

### Elevated Risk Tier (Score 41-60)

Elevated risk tier represents identity holders with marginal financial profiles. This tier receives no capacity adjustment but may face additional restrictions.

- Risk Direction: Neutral (0)
- Adjustment Range: 0%
- Additional Restrictions: May apply

### High Risk Tier (Score 61-80)

High risk tier represents identity holders with concerning financial profiles. This tier receives negative capacity adjustments.

- Risk Direction: Negative (-1)
- Adjustment Range: -10% to -25%

### Critical Risk Tier (Score 81-100)

Critical risk tier represents identity holders with unacceptable financial profiles. This tier receives significant negative capacity adjustments and likely restrictions.

- Risk Direction: Negative (-1)
- Adjustment Range: -25% to -50%
- Restrictions: Likely denial or minimal capacity only

## Edge Cases and Special Conditions

The formula includes special handling for edge cases and unusual circumstances that may arise during calculation. These provisions ensure robust handling of atypical situations.

### Zero or Negative Income

If net annual income is zero or negative, the income-based capacity contribution is zero. The calculation relies entirely on asset-based capacity, which requires positive liquid assets.

```
if NetAnnualIncome ≤ 0:
    IncomeBasedCapacity = 0
```

### Insufficient Income for Debt Service

If actual debt payments exceed the maximum allowable debt payment based on debt-to-income ratio, the excess debt is flagged as a concern but does not increase the debt service deduction beyond the maximum limit.

```
DebtServiceDeduction = min(MaximumAllowableDebtPayment, ActualDebtPayment) × 12
// Excess debt is flagged for review but not deducted
```

### Tax Delinquency

If tax payment status is delinquent, the tax deduction includes a penalty multiplier on the outstanding balance. Additionally, the identity holder is flagged for mandatory review.

```
if TaxPaymentStatus = "delinquent":
    TaxDeduction = AnnualTaxLiability + (OutstandingTaxBalance × 1.25)
    FlagForReview = true
```

### Verification Level Changes

If verification level changes during a calculation period, the lending capacity is recalculated using the new level. The change is documented and the identity holder is notified of capacity changes.

### Expired Attestations

If any attestations used in the calculation have expired, the affected data is flagged and the verification level is temporarily reduced until attestations are renewed. This may result in reduced lending capacity.

## Calculation Verification

All lending capacity calculations must be verifiable through audit procedures. The calculation must produce consistent results when the same inputs are provided, and all intermediate values must be documented for audit purposes.

### Deterministic Requirements

The calculation implementation must be deterministic across all environments. This means that the same inputs must always produce the same outputs, regardless of the platform, runtime, or other environmental factors. Non-deterministic behavior indicates implementation errors that must be corrected.

### Audit Trail Requirements

Each calculation must generate an audit trail that includes all input values, intermediate calculation results, and the final output. The audit trail must be stored in a tamper-evident format and must be retrievable for regulatory examination or dispute resolution.

### Validation Requirements

Before storing or publishing a lending capacity calculation, the result must be validated against the input constraints. If any constraint violation is detected, the calculation must be rejected and the error must be logged for investigation.

## Implementation Notes

This section provides guidance for implementing the lending capacity formula in software systems. The guidance addresses common implementation challenges and ensures consistent behavior across different platforms.

### Integer Arithmetic

All calculations should use integer arithmetic to avoid floating-point precision errors. Monetary values should be converted to cents (multiply by 100) before calculation and converted back to dollars (divide by 100) only for display purposes.

```
// Example: Using integer arithmetic
const GROSS_LENDING_CAPACITY = (netAnnualIncome * INCOME_MULTIPLIER) + 
                                (liquidAssets * ASSET_MULTIPLIER);
```

### Overflow Prevention

Calculations may produce values that exceed the range of standard integer types. Implementations should use arbitrary-precision integers or check for overflow conditions before performing calculations that might exceed available range.

### Validation Before Calculation

All input values should be validated before use in calculations. Invalid inputs should be rejected with clear error messages that identify the specific validation failure.

### Caching Considerations

Lending capacity calculations may be cached to improve performance, but cache invalidation must be properly implemented. The cache must be invalidated when any input data changes or when the formula configuration changes.
