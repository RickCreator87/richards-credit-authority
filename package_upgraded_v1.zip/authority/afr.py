def get_current_afr():
    """Deterministic AFR source (stub).
    Replace with IRS AFR table ingestion when ready.
    """
    return {
        "short_term": 0.045,
        "mid_term": 0.047,
        "long_term": 0.049
    }
