import hashlib
from datetime import datetime

def generate_loan_id(founder_id, entity_id):
    seed = f"{founder_id}:{entity_id}:{datetime.utcnow().isoformat()}"
    return hashlib.sha256(seed.encode()).hexdigest()[:16]
