# State vs Federal Tax Separation

This document defines the governance framework for managing the separation between state and federal tax obligations within the Personal Credit Authority system. The tax-first governance model requires that all tax obligations be properly identified, prioritized, and protected in lending capacity calculations.

## Overview

The Personal Credit Authority implements a comprehensive tax-first governance principle that ensures tax obligations take absolute priority over all lending activities. Within this principle, federal tax obligations receive the highest priority, followed by state tax obligations, with local obligations receiving the lowest priority among governmental tax claims. This hierarchical structure reflects both legal priority rules and practical considerations for risk management.

The separation between state and federal tax obligations is essential for several reasons. Federal tax liens automatically attach to all property and have super-priority over most other claims, making federal tax compliance a critical factor in any lending decision. State tax systems vary significantly across jurisdictions, with some states having no income tax and others having complex multi-jurisdictional requirements. Local taxes add another layer of complexity that must be properly accounted for in lending calculations.

Understanding the interplay between federal and state tax obligations is crucial for accurate lending capacity calculation. The system must correctly identify which jurisdictions impose tax obligations on each identity holder, calculate the appropriate amounts, verify compliance status, and apply the correct priority factors in the lending formula.

## Federal Tax Priority

Federal tax obligations receive the highest priority in the Personal Credit Authority's tax-first governance model. This priority reflects the legal reality that federal tax claims have super-priority over most other claims against property and that failure to comply with federal tax obligations can result in severe consequences including tax liens, levies, and criminal prosecution.

### Federal Tax Types

The Personal Credit Authority recognizes several categories of federal tax obligations that must be considered in lending capacity calculations. Federal income tax is the primary obligation for most taxpayers and is calculated based on taxable income after deductions and exemptions. The federal income tax system uses progressive brackets with rates ranging from 10% to 37% for tax year 2024, and the system must apply the correct rates based on filing status and income level.

Self-employment tax represents the social security and Medicare taxes owed by self-employed individuals and is calculated at 15.3% of self-employment income up to the social security wage base. This obligation is particularly important for identity holders with significant self-employment income, as it can represent a substantial deduction from gross income. The system must correctly identify self-employment income and apply the appropriate tax calculations.

The Alternative Minimum Tax (AMT) is a parallel tax system that ensures high-income taxpayers pay a minimum amount of tax regardless of deductions and credits. The AMT exemption amounts and phase-out thresholds are adjusted annually for inflation, and the system must apply the correct AMT calculations for identity holders whose income exceeds AMT thresholds. AMT liability increases the total federal tax obligation and reduces lending capacity accordingly.

Net Investment Income Tax (NIIT) applies to individuals with modified adjusted gross income above threshold amounts ($200,000 for single filers, $250,000 for married filing jointly) and is calculated at 3.8% on the lesser of net investment income or the amount by which modified adjusted gross income exceeds the threshold. This tax is particularly relevant for identity holders with significant investment income.

### Federal Tax Compliance Status

Federal tax compliance status is assessed through multiple indicators that the system monitors and evaluates. The primary indicator is whether all required federal tax returns have been filed. The system verifies that returns have been filed for the current tax year and the three preceding years, and flags any missing returns that would indicate non-compliance.

The second indicator is whether estimated tax payments are current. Taxpayers with income not subject to withholding, including self-employed individuals, investors, and business owners, are required to make quarterly estimated tax payments. The system verifies that estimated payments have been made on time and in the correct amounts, and calculates any underpayment penalties that may apply.

The third indicator is the existence of any outstanding federal tax liabilities, payment plans, or collection actions. The system checks for balances due on federal tax accounts, active installment agreements, offers in compromise, currently collectible status, and any active tax liens or levies. These factors significantly impact lending capacity and may trigger additional restrictions.

### Federal Tax Calculation

Federal tax calculation begins with determining the identity holder's filing status based on their marital status and family situation. The system supports single, married filing jointly, married filing separately, head of household, and qualifying surviving spouse filing statuses. Each status has different tax brackets, standard deduction amounts, and eligibility requirements.

Gross income is calculated by summing all taxable income sources including wages, self-employment income, investment income, rental income, business income, and other income categories. The system applies the appropriate inclusions and exclusions for each income type and calculates adjusted gross income by subtracting above-the-line deductions such as traditional IRA contributions, self-employment tax deductions, and self-employed health insurance deductions.

Taxable income is determined by subtracting either the standard deduction or itemized deductions from adjusted gross income. For tax year 2024, the standard deduction is $14,600 for single filers, $29,200 for married filing jointly, and $21,900 for head of household. Itemized deductions must be documented and verified, and include categories such as state and local taxes (capped at $10,000), mortgage interest, charitable contributions, and medical expenses exceeding 7.5% of adjusted gross income.

The system applies the progressive tax brackets to calculate federal income tax liability, then adds any additional taxes such as self-employment tax, AMT, and NIIT. Tax credits are applied to reduce the final tax liability, including child tax credits, education credits, energy credits, and other eligible credits. The result is the net federal tax liability for the tax year.

## State Tax Priority

State tax obligations receive second priority in the Personal Credit Authority's tax-first governance model. While federal taxes have super-priority over all other claims, state taxes generally have priority over general unsecured claims and may have priority over some secured claims depending on the jurisdiction and circumstances.

### State Tax Jurisdictions

The United States has a complex landscape of state taxation, with some states imposing no income tax and others imposing complex multi-jurisdictional requirements. The system must correctly identify which state(s) have tax authority over each identity holder based on residency, nexus, and sourcing rules.

Residency-based taxation applies to identity holders who are residents of a taxing state. Most states that impose income tax are residency states, meaning they tax all income earned by residents regardless of where it was earned. The system identifies state residency from the identity manifest and applies the appropriate state tax rates and rules.

Apportionment rules apply to identity holders who earn income in multiple states or who have connections to multiple states. The system must correctly apply apportionment formulas to determine how much income is taxable in each state with taxing authority. Most states use a three-factor apportionment formula weighted toward sales, though some states use single-factor or double-factor formulas.

Economic nexus thresholds determine when an identity holder has sufficient connection to a state to establish tax liability. The system monitors for situations where nexus thresholds may be triggered, such as significant property, payroll, or sales in a state. This is particularly relevant for business owners and self-employed individuals with multi-state activities.

### State-Specific Considerations

State tax rates and rules vary significantly across jurisdictions, requiring the system to maintain current information on each taxing state. California has among the highest state income tax rates, with a top rate of 13.1% for incomes exceeding $1 million. New York also has high rates, with a top rate of 10.9% for incomes exceeding $25 million. Other high-tax states include New Jersey, Massachusetts, and Minnesota.

Some states have no state income tax, including Alaska, Florida, Nevada, South Dakota, Tennessee, Texas, Washington, and Wyoming. Identity holders residing in these states have no state income tax obligation, though they may have obligations in other states where they earn income. The system correctly identifies non-taxing states and applies zero state income tax where appropriate.

Local income taxes apply in some jurisdictions, particularly in Ohio, Pennsylvania, and certain localities in other states. The system must identify and calculate local income taxes where applicable, adding them to the total state and local tax obligation. Local tax rates vary by jurisdiction and may be a flat rate or progressive.

### State Tax Compliance

State tax compliance verification includes checking that all required state tax returns have been filed, that estimated payments are current if required, and that there are no outstanding state tax liabilities or collection actions. The system verifies compliance with each state where the identity holder has filing obligations.

State tax liens may be filed by state taxing authorities and generally have priority over general unsecured claims but are subordinate to federal tax liens. The system checks for state tax liens in all jurisdictions where the identity holder may have tax obligations and factors these into the lending capacity calculation.

Multistate tax compliance can be complex for identity holders with activities in multiple states. The system maintains information on state filing requirements, nexus standards, and apportionment rules to ensure accurate compliance assessment for identity holders with multi-state activities.

## Federal-State Interaction

The interaction between federal and state tax systems creates both opportunities and challenges for the Personal Credit Authority's tax-first governance model. Understanding these interactions is essential for accurate lending capacity calculation and proper risk assessment.

### Deduction Interactions

Federal tax law allows taxpayers to deduct state and local taxes (SALT) as itemized deductions, subject to a $10,000 cap for tax years 2018 through 2025. This deduction reduces federal tax liability for identity holders who itemize deductions and pay significant state and local taxes. The system must account for this interaction when calculating both federal and state tax obligations.

The SALT deduction cap means that identity holders in high-tax states may not be able to fully deduct their state tax obligations on their federal return, increasing their effective total tax burden. This affects lending capacity calculation because the effective tax rate is higher for these identity holders.

### Basis Effects

State tax payments affect basis in various ways that impact lending calculations. State taxes paid reduce the basis of investment property, increase the cost basis of assets when calculating capital gains, and affect the calculation of depreciation and amortization deductions. These basis effects have long-term implications for wealth building and debt capacity.

### Timing Differences

The timing of tax payments differs between federal and state systems, with estimated payments due on different schedules and refund timing varying by jurisdiction. The system must account for these timing differences when calculating tax obligations and assessing compliance status.

Federal estimated payments are due on April 15, June 15, September 15, and January 15. State estimated payment due dates vary by state, with some aligning with federal dates and others having different schedules. The system tracks all estimated payment due dates and verifies that payments are made on time.

## Tax-First Calculation Methodology

The tax-first governance principle requires that tax obligations be deducted from lending capacity before any other calculations. The methodology ensures that the identity holder's ability to meet tax obligations is fully protected.

### Priority Structure

The priority structure for tax-first calculation follows the legal priority of tax claims. Federal tax obligations are deducted first, followed by state tax obligations, and then local tax obligations. This structure ensures that the most urgent tax claims are fully protected.

Federal priority factor of 1.25 is applied to federal tax obligations, providing a 25% buffer to account for estimation variance, unexpected tax liabilities, and timing differences. This buffer ensures that even if the actual federal tax liability exceeds the calculated amount, the identity holder will have sufficient capacity to meet the obligation.

State priority factor of 1.15 is applied to state tax obligations, providing a 15% buffer for estimation variance and timing differences. The lower buffer for state taxes reflects the generally more predictable nature of state tax calculations for residents of a single state.

Local priority factors vary by jurisdiction based on predictability and collection practices. The system maintains local priority factors for all taxing localities and applies them appropriately.

### Calculation Sequence

The tax-first calculation sequence begins with calculating federal tax obligations and applying the federal priority factor. The result is the protected federal tax amount that is deducted from gross lending capacity.

State tax obligations are calculated next, with the state priority factor applied. The protected state tax amount is calculated and made available for the deduction step, though it is conceptually separate from the federal deduction.

Local tax obligations are calculated last, with local priority factors applied. The protected local tax amount is calculated and made available for the deduction step.

The sum of all protected tax amounts is then deducted from gross lending capacity, ensuring that all tax obligations are fully protected before any other claims on income or assets.

### Verification Requirements

Tax-first calculations require verification of tax obligations and compliance status. For federal taxes, required verification includes the most recent two years of federal tax returns, current year withholding statements, and IRS account transcript for balance due status.

For state taxes, required verification includes the most recent two years of state tax returns, current year estimated payment records, and state tax department account status. For identity holders in multiple states, verification is required for each state with taxing authority.

For local taxes, verification includes local tax compliance records where local taxes apply. This may include city income tax records, school district tax records, or special assessment tax records.

### Documentation and Audit

All tax-first calculations must be documented with sufficient detail to enable reconstruction and audit. The documentation must include the tax calculation inputs and methodology, the verification documents reviewed, the priority factors applied, and the final protected tax amounts.

Audit procedures for tax-first calculations include verifying that all applicable tax jurisdictions were identified, that tax calculations were performed correctly, that appropriate priority factors were applied, and that verification requirements were met.

## Risk Assessment Implications

The separation between federal and state tax obligations has significant implications for risk assessment within the Personal Credit Authority system. Tax compliance issues at either the federal or state level can indicate broader financial stress and may predict future credit problems.

### Federal Tax Risk Indicators

Federal tax risk indicators include failure to file required returns, underpayment of estimated taxes, outstanding tax liabilities, active collection actions, tax liens, and prior IRS audit adjustments. Each of these indicators suggests potential financial stress and requires additional scrutiny in the lending decision.

Identity holders with federal tax liens face significant restrictions on lending capacity. The federal lien priority means that any lending activity occurs subject to the government's superior claim, and lenders may be unable to recover their investment if the federal government exercises its lien rights.

### State Tax Risk Indicators

State tax risk indicators parallel federal indicators but may have different implications depending on the state's collection practices and priority rules. Some states have aggressive collection practices and may file tax liens quickly, while others are more lenient.

Identity holders with multi-state tax obligations face additional complexity and risk. The potential for nexus-related assessments, apportionment disputes, and compliance errors increases the risk profile for these identity holders.

### Combined Risk Assessment

The combined federal and state tax risk assessment provides a comprehensive view of the identity holder's tax compliance. The assessment considers both federal and state factors, weights them according to their priority and potential impact, and produces an overall tax risk score.

The tax risk score is one component of the overall risk tier calculation and affects the final lending capacity. Identity holders with excellent tax compliance across all jurisdictions may receive positive adjustments to lending capacity, while those with tax compliance issues may face significant reductions.

## Compliance Monitoring

Ongoing tax compliance monitoring is essential for maintaining accurate lending capacity and managing risk. The system implements continuous monitoring for tax compliance indicators and triggers re-verification when compliance issues are detected.

### Monitoring Triggers

Monitoring triggers include the approach of tax payment due dates, the filing deadline for tax returns, changes in income that may affect estimated payment requirements, and external indicators of tax compliance issues such as lien filings or collection actions.

The system monitors IRS and state tax account status through available channels and flags any changes that may affect lending capacity. Changes in compliance status may trigger immediate re-calculation of lending capacity and possible adjustment to lending authority.

### Re-Verification Procedures

Re-verification procedures are triggered when monitoring detects potential compliance issues or when regular re-verification cycles occur. Re-verification requires updated tax return copies, current account status statements, and explanation of any issues identified during monitoring.

Identity holders who fail to provide re-verification documentation within the specified timeframe may have their lending authority suspended pending resolution. This protects the system from extending credit to identity holders whose tax compliance status may have deteriorated.

### Documentation Updates

Tax compliance documentation must be updated regularly and maintained in the identity record. The system tracks the age of tax documentation and triggers update requests when documentation approaches expiration.

Updated documentation is compared against prior documentation to identify changes in tax compliance status, income, deductions, or other factors that may affect lending capacity. Significant changes trigger re-calculation of lending capacity.
