#!/usr/bin/env python3
"""
Personal Credit Authority Webhook Server

This module implements the webhook server entry point for handling incoming
GitHub App webhooks and external events for the Personal Credit
Authority system.

Author integration: MiniMax Agent
Version: 1.0.0
"""

import os
import sys
import json
import logging
import hmac
import hashlib
from datetime import datetime
from typing import Dict, Any, Optional, Tuple
from http.server import HTTPServer, BaseHTTPRequestHandler
from pathlib import Path

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

# Webhook server configuration
CONFIG = {
    'host': os.getenv('WEBHOOK_HOST', '0.0.0.0'),
    'port': int(os.getenv('WEBHOOK_PORT', 8080)),
    'secret': os.getenv('WEBHOOK_SECRET', 'your-webhook-secret'),
    'github_app_id': os.getenv('GITHUB_APP_ID', ''),
    'github_private_key': os.getenv('GITHUB_PRIVATE_KEY', ''),
    'log_level': os.getenv('LOG_LEVEL', 'INFO'),
    'max_payload_size': int(os.getenv('MAX_PAYLOAD_SIZE', 10485760)),  # 10MB
    'allowed_events': [
        'push',
        'pull_request',
        'pull_request_review',
        'issues',
        'check_run',
        'check_suite',
        'identity_update',
        'permission_update',
        'authority_recalculation',
        'compliance_alert'
    ],
    'health_check_path': '/health',
    'webhook_path': '/webhook'
}


class WebhookHandler(BaseHTTPRequestHandler):
    """HTTP request handler for webhook endpoints."""
    
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
    
    def _send_response(self, status_code: int, body: Dict[str, Any]) -> None:
        """Send a JSON response with the given status code and body."""
        self.send_response(status_code)
        self.send_header('Content-Type', 'application/json')
        self.end_headers()
        response_body = json.dumps(body)
        self.wfile.write(response_body.encode('utf-8'))
    
    def _get_request_body(self) -> bytes:
        """Read and return the request body."""
        content_length = int(self.headers.get('Content-Length', 0))
        if content_length > CONFIG['max_payload_size']:
            raise ValueError(f"Payload too large: {content_length} bytes")
        return self.rfile.read(content_length)
    
    def _verify_github_signature(self, body: bytes, signature: str) -> bool:
        """Verify GitHub webhook signature."""
        if not CONFIG['secret']:
            logger.warning("Webhook secret not configured, skipping signature verification")
            return True
        
        if not signature:
            logger.warning("No signature provided")
            return False
        
        # GitHub signature format: sha256=<signature>
        expected_signature = 'sha256=' + hmac.new(
            CONFIG['secret'].encode('utf-8'),
            body,
            hashlib.sha256
        ).hexdigest()
        
        return hmac.compare_digest(signature, expected_signature)
    
    def _verify_internal_signature(self, body: bytes, signature: str) -> bool:
        """Verify internal webhook signature."""
        if not CONFIG['secret']:
            logger.warning("Webhook secret not configured, skipping signature verification")
            return True
        
        if not signature:
            logger.warning("No signature provided")
            return False
        
        expected_signature = hmac.new(
            CONFIG['secret'].encode('utf-8'),
            body,
            hashlib.sha256
        ).hexdigest()
        
        return hmac.compare_digest(signature, expected_signature)
    
    def _route_event(self, event_type: str, payload: Dict[str, Any]) -> Tuple[bool, str]:
        """Route the event to the appropriate handler.
        
        Returns:
            Tuple of (success: bool, message: str)
        """
        event_router = EventRouter()
        return event_router.handle_event(event_type, payload)
    
    def do_GET(self) -> None:
        """Handle GET requests."""
        if self.path == CONFIG['health_check_path']:
            self._send_response(200, {
                'status': 'healthy',
                'timestamp': datetime.utcnow().isoformat() + 'Z',
                'version': '1.0.0'
            })
        else:
            self._send_response(404, {
                'error': 'Not Found',
                'message': f'No handler for path: {self.path}'
            })
    
    def do_POST(self) -> None:
        """Handle POST requests (webhook events)."""
        if self.path != CONFIG['webhook_path']:
            self._send_response(404, {
                'error': 'Not Found',
                'message': f'No handler for path: {self.path}'
            })
            return
        
        try:
            # Get request body
            body = self._get_request_body()
            
            # Get event type
            event_type = self.headers.get('X-GitHub-Event', '')
            if not event_type:
                # Try internal event header
                event_type = self.headers.get('X-Internal-Event', '')
            
            if not event_type:
                self._send_response(400, {
                    'error': 'Bad Request',
                    'message': 'Missing event type header (X-GitHub-Event or X-Internal-Event)'
                })
                return
            
            # Verify signature based on event source
            signature = self.headers.get('X-Hub-Signature-256', '') or \
                       self.headers.get('X-Signature', '')
            
            is_github_event = bool(self.headers.get('X-GitHub-Event'))
            
            if is_github_event:
                if not self._verify_github_signature(body, signature):
                    self._send_response(401, {
                        'error': 'Unauthorized',
                        'message': 'Invalid signature'
                    })
                    return
            else:
                if not self._verify_internal_signature(body, signature):
                    self._send_response(401, {
                        'error': 'Unauthorized',
                        'message': 'Invalid signature'
                    })
                    return
            
            # Parse payload
            try:
                payload = json.loads(body)
            except json.JSONDecodeError as e:
                self._send_response(400, {
                    'error': 'Bad Request',
                    'message': f'Invalid JSON: {str(e)}'
                })
                return
            
            # Check if event type is allowed
            if event_type not in CONFIG['allowed_events']:
                logger.info(f"Ignoring untracked event type: {event_type}")
                self._send_response(200, {
                    'status': 'ignored',
                    'message': f'Event type {event_type} not tracked'
                })
                return
            
            # Log event receipt
            logger.info(f"Received event: {event_type}")
            
            # Route event to handler
            success, message = self._route_event(event_type, payload)
            
            if success:
                self._send_response(200, {
                    'status': 'success',
                    'message': message
                })
            else:
                self._send_response(500, {
                    'status': 'error',
                    'message': message
                })
                
        except ValueError as e:
            self._send_response(400, {
                'error': 'Bad Request',
                'message': str(e)
            })
        except Exception as e:
            logger.exception(f"Error processing webhook: {e}")
            self._send_response(500, {
                'error': 'Internal Server Error',
                'message': 'An error occurred processing the webhook'
            })
    
    def log_message(self, format: str, *args) -> None:
        """Override to use logger instead of stderr."""
        logger.info(f"{self.address_string()} - {format % args}")


class EventRouter:
    """Routes webhook events to appropriate handlers."""
    
    def __init__(self):
        """Initialize event router with handler mappings."""
        self.handlers = {
            'push': self._handle_push,
            'pull_request': self._handle_pull_request,
            'pull_request_review': self._handle_pull_request_review,
            'issues': self._handle_issues,
            'check_run': self._handle_check_run,
            'check_suite': self._handle_check_suite,
            'identity_update': self._handle_identity_sync,
            'permission_update': self._handle_permission_update,
            'authority_recalculation': self._handle_authority_recalculation,
            'compliance_alert': self._handle_compliance_alert
        }
    
    def handle_event(self, event_type: str, payload: Dict[str, Any]) -> Tuple[bool, str]:
        """Handle an incoming event.
        
        Args:
            event_type: Type of the event
            payload: Event payload
            
        Returns:
            Tuple of (success: bool, message: str)
        """
        handler = self.handlers.get(event_type)
        
        if not handler:
            return False, f"No handler for event type: {event_type}"
        
        try:
            handler(payload)
            return True, f"Event {event_type} processed successfully"
        except Exception as e:
            logger.exception(f"Error handling {event_type}: {e}")
            return False, f"Error processing event: {str(e)}"
    
    def _handle_push(self, payload: Dict[str, Any]) -> None:
        """Handle push events."""
        logger.info(f"Push event: {payload.get('ref', 'unknown')}")
        
        # Import and run identity sync handler if identity files changed
        from handlers.identity_sync_handler import IdentitySyncHandler
        handler = IdentitySyncHandler()
        handler.handle_push_event(payload)
    
    def _handle_pull_request(self, payload: Dict[str, Any]) -> None:
        """Handle pull request events."""
        action = payload.get('action', 'unknown')
        pr_number = payload.get('pull_request', {}).get('number', 'unknown')
        logger.info(f"Pull request event: action={action}, PR=#{pr_number}")
        
        # Import and run permission update handler if permission files changed
        from handlers.permission_update_handler import PermissionUpdateHandler
        handler = PermissionUpdateHandler()
        handler.handle_pull_request_event(payload)
    
    def _handle_pull_request_review(self, payload: Dict[str, Any]) -> None:
        """Handle pull request review events."""
        action = payload.get('action', 'unknown')
        review = payload.get('review', {})
        logger.info(f"Pull request review event: action={action}, state={review.get('state', 'unknown')}")
    
    def _handle_issues(self, payload: Dict[str, Any]) -> None:
        """Handle issues events."""
        action = payload.get('action', 'unknown')
        issue = payload.get('issue', {})
        logger.info(f"Issues event: action={action}, issue=#{issue.get('number', 'unknown')}")
    
    def _handle_check_run(self, payload: Dict[str, Any]) -> None:
        """Handle check run events."""
        action = payload.get('action', 'unknown')
        check_run = payload.get('check_run', {})
        logger.info(f"Check run event: action={action}, name={check_run.get('name', 'unknown')}")
    
    def _handle_check_suite(self, payload: Dict[str, Any]) -> None:
        """Handle check suite events."""
        action = payload.get('action', 'unknown')
        check_suite = payload.get('check_suite', {})
        logger.info(f"Check suite event: action={action}, repo={payload.get('repository', {}).get('full_name', 'unknown')}")
    
    def _handle_identity_sync(self, payload: Dict[str, Any]) -> None:
        """Handle identity sync events."""
        logger.info(f"Identity sync event: {payload}")
        
        from handlers.identity_sync_handler import IdentitySyncHandler
        handler = IdentitySyncHandler()
        handler.handle_sync_event(payload)
    
    def _handle_permission_update(self, payload: Dict[str, Any]) -> None:
        """Handle permission update events."""
        logger.info(f"Permission update event: {payload}")
        
        from handlers.permission_update_handler import PermissionUpdateHandler
        handler = PermissionUpdateHandler()
        handler.handle_sync_event(payload)
    
    def _handle_authority_recalculation(self, payload: Dict[str, Any]) -> None:
        """Handle authority recalculation events."""
        logger.info(f"Authority recalculation event: {payload}")
        
        from handlers.lending_authority_recalc_handler import LendingAuthorityRecalcHandler
        handler = LendingAuthorityRecalcHandler()
        handler.handle_recalc_event(payload)
    
    def _handle_compliance_alert(self, payload: Dict[str, Any]) -> None:
        """Handle compliance alert events."""
        alert_type = payload.get('alert_type', 'unknown')
        severity = payload.get('severity', 'unknown')
        logger.info(f"Compliance alert: type={alert_type}, severity={severity}")


class WebhookServer:
    """Webhook server wrapper for management operations."""
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """Initialize the webhook server.
        
        Args:
            config: Optional configuration overrides
        """
        global CONFIG
        if config:
            CONFIG.update(config)
        
        self.server: Optional[HTTPServer] = None
        self._configure_logging()
    
    def _configure_logging(self) -> None:
        """Configure logging based on config."""
        logging.getLogger().setLevel(getattr(logging, CONFIG.get('log_level', 'INFO')))
    
    def start(self) -> None:
        """Start the webhook server."""
        self.server = HTTPServer(
            (CONFIG['host'], CONFIG['port']),
            WebhookHandler
        )
        
        logger.info(f"Starting webhook server on {CONFIG['host']}:{CONFIG['port']}")
        logger.info(f"Webhook endpoint: {CONFIG['webhook_path']}")
        logger.info(f"Health check endpoint: {CONFIG['health_check_path']}")
        
        try:
            self.server.serve_forever()
        except KeyboardInterrupt:
            logger.info("Shutting down webhook server...")
            self.stop()
    
    def stop(self) -> None:
        """Stop the webhook server."""
        if self.server:
            self.server.shutdown()
            self.server.server_close()
            logger.info("Webhook server stopped")


def main():
    """Main entry point for the webhook server."""
    server = WebhookServer()
    
    # Set up signal handlers for graceful shutdown
    import signal
    
    def signal_handler(signum, frame):
        logger.info(f"Received signal {signum}")
        server.stop()
        sys.exit(0)
    
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    # Start the server
    server.start()


if __name__ == '__main__':
    main()
