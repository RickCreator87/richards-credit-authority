#!/usr/bin/env python3
"""
Webhook Signature Verification Module

This module provides functions for validating GitHub App webhook signatures
and internal webhook signatures to ensure message authenticity and integrity.

Author: MiniMax Agent
Version: 1.0.0
"""

import os
import hmac
import hashlib
import logging
from typing import Tuple, Optional, Dict, Any
from pathlib import Path

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class SignatureVerifier:
    """Handles webhook signature verification for GitHub and internal events."""
    
    def __init__(self, webhook_secret: Optional[str] = None):
        """Initialize the signature verifier.
        
        Args:
            webhook_secret: The webhook secret for signature verification.
                           Falls back to WEBHOOK_SECRET environment variable.
        """
        self.webhook_secret = webhook_secret or os.getenv('WEBHOOK_SECRET', '')
        
        # Known GitHub IP ranges (for additional validation)
        self.github_ips = self._load_github_ips()
    
    def _load_github_ips(self) -> set:
        """Load known GitHub IP addresses/ranges."""
        # In production, this would fetch from GitHub's API
        # For now, return a basic set
        return {
            '192.30.252.0/22',
            '192.30.252.0/22',
            '185.199.108.0/22',
            '140.82.112.0/20',
            '143.55.64.0/20'
        }
    
    def verify_github_signature(
        self,
        payload: bytes,
        signature_header: str,
        secret: Optional[str] = None
    ) -> Tuple[bool, str]:
        """Verify a GitHub webhook signature.
        
        GitHub signs webhooks using HMAC-SHA256 with the webhook secret.
        The signature is provided in the X-Hub-Signature-256 header in the
        format: sha256=<signature>
        
        Args:
            payload: The raw request body bytes
            signature_header: The signature from the request header
            secret: Optional secret override
            
        Returns:
            Tuple of (is_valid: bool, message: str)
        """
        secret = secret or self.webhook_secret
        
        if not secret:
            return False, "Webhook secret not configured"
        
        if not signature_header:
            return False, "No signature header provided"
        
        try:
            # GitHub format: sha256=<hex signature>
            if not signature_header.startswith('sha256='):
                return False, "Invalid signature format"
            
            expected_sig = signature_header[7:]  # Remove 'sha256=' prefix
            
            # Calculate expected signature
            calculated_sig = hmac.new(
                secret.encode('utf-8'),
                payload,
                hashlib.sha256
            ).hexdigest()
            
            # Use constant-time comparison to prevent timing attacks
            if hmac.compare_digest(expected_sig, calculated_sig):
                logger.debug("GitHub signature verification successful")
                return True, "Signature verified"
            else:
                logger.warning("GitHub signature verification failed - signature mismatch")
                return False, "Signature verification failed"
                
        except Exception as e:
            logger.exception(f"Error verifying GitHub signature: {e}")
            return False, f"Verification error: {str(e)}"
    
    def verify_internal_signature(
        self,
        payload: bytes,
        signature_header: str,
        secret: Optional[str] = None
    ) -> Tuple[bool, str]:
        """Verify an internal webhook signature.
        
        Internal webhooks use the same HMAC-SHA256 signing but may have
        different header names or formats.
        
        Args:
            payload: The raw request body bytes
            signature_header: The signature from the request header
            secret: Optional secret override
            
        Returns:
            Tuple of (is_valid: bool, message: str)
        """
        secret = secret or self.webhook_secret
        
        if not secret:
            return False, "Webhook secret not configured"
        
        if not signature_header:
            return False, "No signature header provided"
        
        try:
            # Internal format may vary - try hex signature
            calculated_sig = hmac.new(
                secret.encode('utf-8'),
                payload,
                hashlib.sha256
            ).hexdigest()
            
            if hmac.compare_digest(signature_header, calculated_sig):
                logger.debug("Internal signature verification successful")
                return True, "Signature verified"
            else:
                logger.warning("Internal signature verification failed - signature mismatch")
                return False, "Signature verification failed"
                
        except Exception as e:
            logger.exception(f"Error verifying internal signature: {e}")
            return False, f"Verification error: {str(e)}"
    
    def verify_signature(
        self,
        payload: bytes,
        signature_header: str,
        event_type: str,
        secret: Optional[str] = None
    ) -> Tuple[bool, str]:
        """Verify a webhook signature based on event type.
        
        Routes to the appropriate verification method based on whether
        this is a GitHub or internal event.
        
        Args:
            payload: The raw request body bytes
            signature_header: The signature from the request header
            event_type: The type of event (determines verification method)
            secret: Optional secret override
            
        Returns:
            Tuple of (is_valid: bool, message: str)
        """
        # GitHub events come with specific headers
        github_events = {
            'push', 'pull_request', 'pull_request_review', 'issues',
            'check_run', 'check_suite', 'commit_comment', 'create',
            'delete', 'deployment', 'deployment_status', 'fork',
            'gollum', 'installation', 'installation_repositories',
            'integration_installation', 'integration_installation_repositories',
            'issue_comment', 'label', 'member', 'membership',
            'milestone', 'organization', 'org_block', 'ping',
            'project_card', 'project_column', 'project', 'public',
            'release', 'repository', 'status', 'team',
            'team_add', 'watch'
        }
        
        if event_type in github_events:
            return self.verify_github_signature(payload, signature_header, secret)
        else:
            # Internal event - use internal verification
            return self.verify_internal_signature(payload, signature_header, secret)
    
    def generate_signature(
        self,
        payload: bytes,
        secret: Optional[str] = None,
        prefix: str = 'sha256='
    ) -> str:
        """Generate a signature for a payload.
        
        Useful for testing and for generating signatures for
        outgoing webhooks.
        
        Args:
            payload: The payload bytes to sign
            secret: Optional secret override
            prefix: Signature prefix (e.g., 'sha256=' for GitHub)
            
        Returns:
            The signature string
        """
        secret = secret or self.webhook_secret
        
        if not secret:
            raise ValueError("Webhook secret not configured")
        
        signature = hmac.new(
            secret.encode('utf-8'),
            payload,
            hashlib.sha256
        ).hexdigest()
        
        return f"{prefix}{signature}"
    
    def verify_request(
        self,
        payload: bytes,
        headers: Dict[str, str],
        event_type: str
    ) -> Tuple[bool, str]:
        """Verify a complete webhook request.
        
        Extracts the signature from appropriate headers and verifies it.
        
        Args:
            payload: The raw request body bytes
            headers: The request headers dictionary
            event_type: The type of event being received
            
        Returns:
            Tuple of (is_valid: bool, message: str)
        """
        # Try GitHub signature header first
        signature = headers.get('X-Hub-Signature-256', '')
        
        # Fall back to internal signature header
        if not signature:
            signature = headers.get('X-Signature', '')
        
        # Fall back to generic signature header
        if not signature:
            signature = headers.get('Authorization', '')
            # Remove 'Bearer ' prefix if present
            if signature.startswith('Bearer '):
                signature = signature[7:]
        
        if not signature:
            return False, "No signature header found in request"
        
        return self.verify_signature(payload, signature, event_type)


class GitHubAppVerifier:
    """Specialized verification for GitHub App webhooks."""
    
    def __init__(self, app_id: Optional[str] = None, private_key: Optional[str] = None):
        """Initialize the GitHub App verifier.
        
        Args:
            app_id: GitHub App ID
            private_key: GitHub App private key
        """
        self.app_id = app_id or os.getenv('GITHUB_APP_ID', '')
        self.private_key = private_key or os.getenv('GITHUB_PRIVATE_KEY', '')
        self.base_verifier = SignatureVerifier()
    
    def verify_installation(
        self,
        payload: Dict[str, Any],
        signature_header: str
    ) -> Tuple[bool, str]:
        """Verify a GitHub App installation webhook.
        
        Args:
            payload: The webhook payload
            signature_header: The signature header
            
        Returns:
            Tuple of (is_valid: bool, message: str)
        """
        import json
        body = json.dumps(payload).encode('utf-8')
        return self.base_verifier.verify_github_signature(body, signature_header)
    
    def verify_request(
        self,
        payload: bytes,
        headers: Dict[str, str],
        event_type: str
    ) -> Tuple[bool, str]:
        """Verify a GitHub App webhook request.
        
        Args:
            payload: The raw request body
            headers: Request headers
            event_type: Type of event
            
        Returns:
            Tuple of (is_valid: bool, message: str)
        """
        signature = headers.get('X-Hub-Signature-256', '')
        return self.base_verifier.verify_github_signature(payload, signature)
    
    def get_installation_token(self, installation_id: int) -> Dict[str, Any]:
        """Get an installation access token for the GitHub App.
        
        This is used to authenticate API calls on behalf of the installation.
        
        Args:
            installation_id: The GitHub App installation ID
            
        Returns:
            Dict containing token and expiration info
            
        Note:
            This requires proper GitHub App credentials to be configured.
        """
        # This would use the GitHub API to get an installation token
        # Implementation requires requests library and GitHub App credentials
        logger.info(f"Getting installation token for installation {installation_id}")
        return {
            'token': '',
            'expires_at': '',
            'permissions': {}
        }


def verify_webhook_signature(
    payload: bytes,
    signature: str,
    secret: str,
    event_type: str = 'github'
) -> Tuple[bool, str]:
    """Convenience function for webhook signature verification.
    
    Args:
        payload: The raw request body bytes
        signature: The signature from the request header
        secret: The webhook secret
        event_type: Either 'github' or 'internal'
        
    Returns:
        Tuple of (is_valid: bool, message: str)
    """
    verifier = SignatureVerifier(secret)
    
    if event_type == 'github':
        return verifier.verify_github_signature(payload, signature)
    else:
        return verifier.verify_internal_signature(payload, signature)


def create_signature_header(payload: bytes, secret: str) -> str:
    """Create a signature header for outgoing webhooks.
    
    Args:
        payload: The payload bytes
        secret: The webhook secret
        
    Returns:
        The signature header value (without 'sha256=' prefix)
    """
    return hmac.new(
        secret.encode('utf-8'),
        payload,
        hashlib.sha256
    ).hexdigest()


# Test functions for module testing
def _run_tests():
    """Run basic verification tests."""
    import json
    
    test_secret = 'test-secret'
    test_payload = json.dumps({'test': 'data'}).encode('utf-8')
    
    verifier = SignatureVerifier(test_secret)
    
    # Test signature generation
    signature = verifier.generate_signature(test_payload, test_secret)
    print(f"Generated signature: {signature}")
    
    # Test verification
    is_valid, message = verifier.verify_github_signature(
        test_payload,
        f'sha256={signature}'
    )
    print(f"Verification result: {is_valid}, {message}")
    
    # Test failure case
    is_valid, message = verifier.verify_github_signature(
        test_payload,
        'sha256=invalid'
    )
    print(f"Expected failure: {is_valid}, {message}")


if __name__ == '__main__':
    _run_tests()
