#!/usr/bin/env python3
"""
Webhook Event Router

This module implements the event routing logic for the Personal Credit Authority
webhook system. It receives validated webhook events and routes them to
appropriate handlers based on event type and payload content.

Author integration: MiniMax Agent
Version: 1.0.0
"""

import os
import sys
import json
import logging
import importlib
from typing import Dict, Any, Optional, Tuple, Type
from pathlib import Path
from datetime import datetime

# Add parent directory to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent))

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)


class EventHandler:
    """Base class for event handlers."""
    
    def __init__(self, name: str = "EventHandler"):
        """Initialize the event handler.
        
        Args:
            name: Human-readable name for logging
        """
        self.name = name
        self.logger = logging.getLogger(f"handler.{name}")
    
    def can_handle(self, event_type: str, payload: Dict[str, Any]) -> bool:
        """Check if this handler can process the given event.
        
        Args:
            event_type: Type of the event
            payload: Event payload
            
        Returns:
            True if this handler can process the event
        """
        raise NotImplementedError
    
    def handle(self, payload: Dict[str, Any]) -> bool:
        """Handle the event.
        
        Args:
            payload: Event payload
            
        Returns:
            True if handled successfully
        """
        raise NotImplementedError
    
    def log_event(self, event_type: str, payload: Dict[str, Any], success: bool) -> None:
        """Log event processing result.
        
        Args:
            event_type: Type of event
            payload: Event payload
            success: Whether processing was successful
        """
        action = payload.get('action', 'unknown')
        self.logger.info(
            f"Event {event_type} (action={action}) - "
            f"Success={success}"
        )


class EventRouter:
    """Routes webhook events to appropriate handlers."""
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """Initialize the event router.
        
        Args:
            config: Optional configuration dictionary
        """
        self.config = config or {}
        self.logger = logging.getLogger("event_router")
        self.handlers: Dict[str, Type[EventHandler]] = {}
        self._load_handlers()
    
    def _load_handlers(self) -> None:
        """Load all available event handlers."""
        # Import and register handlers
        try:
            from handlers.identity_sync_handler import IdentitySyncHandler
            from handlers.permission_update_handler import PermissionUpdateHandler
            from handlers.lending_authority_recalc_handler import LendingAuthorityRecalcHandler
            
            self.register_handler('push', IdentitySyncHandler)
            self.register_handler('identity_update', IdentitySyncHandler)
            
            self.register_handler('pull_request', PermissionUpdateHandler)
            self.register_handler('permission_update', PermissionUpdateHandler)
            
            self.register_handler('authority_recalculation', LendingAuthorityRecalcHandler)
            
            self.logger.info("Loaded default event handlers")
            
        except ImportError as e:
            self.logger.warning(f"Could not load handlers: {e}")
    
    def register_handler(self, event_type: str, handler_class: Type[EventHandler]) -> None:
        """Register an event handler for a specific event type.
        
        Args:
            event_type: The event type to handle
            handler_class: The handler class to use
        """
        self.handlers[event_type] = handler_class
        self.logger.debug(f"Registered handler for event type: {event_type}")
    
    def unregister_handler(self, event_type: str) -> None:
        """Unregister the handler for a specific event type.
        
        Args:
            event_type: The event type to unregister
        """
        if event_type in self.handlers:
            del self.handlers[event_type]
            self.logger.debug(f"Unregistered handler for event type: {event_type}")
    
    def get_handler(self, event_type: str, payload: Dict[str, Any]) -> Optional[EventHandler]:
        """Get the appropriate handler for an event.
        
        Args:
            event_type: Type of the event
            payload: Event payload
            
        Returns:
            The appropriate EventHandler instance, or None
        """
        # Direct match
        if event_type in self.handlers:
            handler_class = self.handlers[event_type]
            return handler_class()
        
        # Pattern-based matching
        handler = self._find_handler_by_pattern(event_type, payload)
        if handler:
            return handler
        
        self.logger.warning(f"No handler found for event type: {event_type}")
        return None
    
    def _find_handler_by_pattern(
        self,
        event_type: str,
        payload: Dict[str, Any]
    ) -> Optional[EventHandler]:
        """Find handler using pattern matching.
        
        Args:
            event_type: Type of the event
            payload: Event payload
            
        Returns:
            Handler if found, None otherwise
        """
        # Check for pull_request related events
        if event_type.startswith('pull_request'):
            if 'pull_request' in self.handlers:
                return self.handlers['pull_request']()
        
        # Check for identity-related events
        if event_type in ['identity_created', 'identity_updated', 'identity_verified']:
            if 'identity_update' in self.handlers:
                return self.handlers['identity_update']()
        
        return None
    
    def handle_event(self, event_type: str, payload: Dict[str, Any]) -> Tuple[bool, str]:
        """Handle an incoming event by routing to appropriate handler.
        
        Args:
            event_type: Type of the event
            payload: Event payload
            
        Returns:
            Tuple of (success: bool, message: str)
        """
        self.logger.info(f"Routing event: {event_type}")
        
        # Get the appropriate handler
        handler = self.get_handler(event_type, payload)
        
        if not handler:
            return True, f"No handler for event type: {event_type} - skipped"
        
        try:
            # Check if handler can process this event
            if not handler.can_handle(event_type, payload):
                return True, f"Handler declined event: {event_type} - skipped"
            
            # Process the event
            success = handler.handle(payload)
            
            # Log the result
            handler.log_event(event_type, payload, success)
            
            if success:
                return True, f"Event {event_type} processed successfully"
            else:
                return False, f"Event {event_type} processing failed"
                
        except Exception as e:
            handler.log_event(event_type, payload, False)
            self.logger.exception(f"Error handling event {event_type}: {e}")
            return False, f"Error processing event: {str(e)}"
    
    def handle_batch(
        self,
        events: list
    ) -> Dict[str, Tuple[bool, str]]:
        """Handle a batch of events.
        
        Args:
            events: List of (event_type, payload) tuples
            
        Returns:
            Dictionary mapping event identifiers to results
        """
        results = {}
        
        for i, (event_type, payload) in enumerate(events):
            event_id = f"event_{i}"
            success, message = self.handle_event(event_type, payload)
            results[event_id] = (success, message)
        
        return results


class PriorityEventRouter(EventRouter):
    """Event router with priority handling and rate limiting."""
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """Initialize the priority event router.
        
        Args:
            config: Optional configuration with priority settings
        """
        super().__init__(config)
        
        # Priority levels
        self.priority_levels = {
            'critical': 1,
            'high': 2,
            'normal': 3,
            'low': 4
        }
        
        # Event type to priority mapping
        self.event_priorities = {
            'compliance_alert': 'critical',
            'security_event': 'critical',
            'identity_revoked': 'high',
            'governance_updated': 'high',
            'push': 'normal',
            'pull_request': 'normal',
            'identity_update': 'normal',
            'permission_update': 'normal',
            'authority_recalculation': 'normal',
            'check_run': 'low'
        }
        
        # Rate limiting
        self.event_counts: Dict[str, int] = {}
        self.rate_limit_window = 60  # seconds
        self.max_events_per_window = 100
    
    def get_event_priority(self, event_type: str, payload: Dict[str, Any]) -> str:
        """Determine the priority of an event.
        
        Args:
            event_type: Type of the event
            payload: Event payload
            
        Returns:
            Priority level string
        """
        # Check explicit mapping
        if event_type in self.event_priorities:
            return self.event_priorities[event_type]
        
        # Check payload for priority indicators
        action = payload.get('action', '')
        if 'critical' in action.lower() or 'urgent' in action.lower():
            return 'high'
        
        return 'normal'
    
    def check_rate_limit(self, event_type: str) -> Tuple[bool, int]:
        """Check if event type is within rate limits.
        
        Args:
            event_type: Type of the event
            
        Returns:
            Tuple of (is_allowed: bool, remaining: int)
        """
        # Simple rate limiting implementation
        current_time = datetime.utcnow().timestamp()
        key = f"{event_type}_{int(current_time / self.rate_limit_window)}"
        
        current_count = self.event_counts.get(key, 0)
        remaining = self.max_events_per_window - current_count
        
        if current_count >= self.max_events_per_window:
            return False, 0
        
        self.event_counts[key] = current_count + 1
        return True, remaining - 1
    
    def handle_event(self, event_type: str, payload: Dict[str, Any]) -> Tuple[bool, str]:
        """Handle an event with priority and rate limiting.
        
        Args:
            event_type: Type of the event
            payload: Event payload
            
        Returns:
            Tuple of (success: bool, message: str)
        """
        # Get priority
        priority = self.get_event_priority(event_type, payload)
        
        # Check rate limit
        allowed, remaining = self.check_rate_limit(event_type)
        if not allowed:
            self.logger.warning(f"Rate limit exceeded for event type: {event_type}")
            return False, f"Rate limit exceeded for {event_type}"
        
        # Log priority info
        self.logger.debug(f"Event {event_type} priority: {priority}, remaining: {remaining}")
        
        # Process event
        return super().handle_event(event_type, payload)


class ConditionalEventRouter(EventRouter):
    """Event router with conditional routing based on payload content."""
    
    def __init__(self, config: Optional[Dict[str, Any]] = None):
        """Initialize the conditional event router.
        
        Args:
            config: Optional configuration with routing rules
        """
        super().__init__(config)
        
        # Conditional routing rules
        self.routing_rules: list = []
    
    def add_routing_rule(
        self,
        condition: Dict[str, Any],
        handler: Type[EventHandler]
    ) -> None:
        """Add a conditional routing rule.
        
        Args:
            condition: Dictionary with matching conditions (e.g., {'action': 'opened'})
            handler: Handler class to use when condition matches
        """
        self.routing_rules.append({
            'condition': condition,
            'handler': handler
        })
    
    def get_handler(self, event_type: str, payload: Dict[str, Any]) -> Optional[EventHandler]:
        """Get handler based on event type and payload conditions.
        
        Args:
            event_type: Type of the event
            payload: Event payload
            
        Returns:
            The appropriate EventHandler instance, or None
        """
        # First check routing rules
        for rule in self.routing_rules:
            if self._matches_condition(payload, rule['condition']):
                handler_class = rule['handler']
                return handler_class()
        
        # Fall back to default routing
        return super().get_handler(event_type, payload)
    
    def _matches_condition(
        self,
        payload: Dict[str, Any],
        condition: Dict[str, Any]
    ) -> bool:
        """Check if payload matches the condition.
        
        Args:
            payload: Event payload
            condition: Matching conditions
            
        Returns:
            True if payload matches condition
        """
        for key, expected_value in condition.items():
            # Navigate nested keys (e.g., 'pull_request.title')
            parts = key.split('.')
            actual_value = payload
            
            for part in parts:
                if isinstance(actual_value, dict):
                    actual_value = actual_value.get(part)
                else:
                    return False
            
            if actual_value != expected_value:
                return False
        
        return True


def create_router(router_type: str = 'default') -> EventRouter:
    """Factory function to create event routers.
    
    Args:
        router_type: Type of router to create ('default', 'priority', 'conditional')
        
    Returns:
        Configured EventRouter instance
    """
    if router_type == 'priority':
        return PriorityEventRouter()
    elif router_type == 'conditional':
        return ConditionalEventRouter()
    else:
        return EventRouter()


# Handler implementations
class IdentitySyncHandler(EventHandler):
    """Handler for identity synchronization events."""
    
    def __init__(self):
        """Initialize the identity sync handler."""
        super().__init__("IdentitySyncHandler")
        self.identity_path = Path(__file__).parent.parent / 'identity'
    
    def can_handle(self, event_type: str, payload: Dict[str, Any]) -> bool:
        """Check if this handler can process identity events."""
        return event_type in ['push', 'identity_update']
    
    def handle(self, payload: Dict[str, Any]) -> bool:
        """Handle identity sync event."""
        try:
            # Check if identity files were changed
            changed_files = self._get_changed_files(payload)
            identity_files = [f for f in changed_files if 'identity' in f.lower()]
            
            if not identity_files:
                self.logger.debug("No identity files changed in event")
                return True
            
            # Process identity changes
            self.logger.info(f"Processing identity changes: {identity_files}")
            
            # In a full implementation, this would:
            # 1. Validate schema of changed identity files
            # 2. Update identity manifest if needed
            # 3. Recalculate identity hash
            # 4. Update related records
            
            return True
            
        except Exception as e:
            self.logger.exception(f"Error handling identity sync: {e}")
            return False
    
    def _get_changed_files(self, payload: Dict[str, Any]) -> list:
        """Extract list of changed files from push event."""
        commits = payload.get('commits', [])
        files = []
        for commit in commits:
            files.extend(commit.get('added', []))
            files.extend(commit.get('modified', []))
        return files


class PermissionUpdateHandler(EventHandler):
    """Handler for permission update events."""
    
    def __init__(self):
        """Initialize the permission update handler."""
        super().__init__("PermissionUpdateHandler")
        self.permission_path = Path(__file__).parent.parent / 'permission'
    
    def can_handle(self, event_type: str, payload: Dict[str, Any]) -> bool:
        """Check if this handler can process permission events."""
        return event_type in ['pull_request', 'permission_update']
    
    def handle(self, payload: Dict[str, Any]) -> bool:
        """Handle permission update event."""
        try:
            action = payload.get('action', '')
            
            if action in ['opened', 'synchronize']:
                # Validate permission changes in PR
                changes = self._get_permission_changes(payload)
                if changes:
                    self.logger.info(f"Permission changes detected: {changes}")
                    # In full implementation: validate against schema
            
            elif action == 'closed' and payload.get('pull_request', {}).get('merged'):
                # Apply permission changes after merge
                self.logger.info("Permission changes merged, applying updates")
                # In full implementation: apply changes to permission system
            
            return True
            
        except Exception as e:
            self.logger.exception(f"Error handling permission update: {e}")
            return False
    
    def _get_permission_changes(self, payload: Dict[str, Any]) -> list:
        """Extract permission-related file changes from PR."""
        files = []
        pr = payload.get('pull_request', {})
        files_data = pr.get('changed_files', [])
        
        # In full implementation, would fetch file list from GitHub API
        return files


class LendingAuthorityRecalcHandler(EventHandler):
    """Handler for lending authority recalculation events."""
    
    def __init__(self):
        """Initialize the authority recalculation handler."""
        super().__init__("LendingAuthorityRecalcHandler")
        self.authority_path = Path(__file__).parent.parent / 'authority'
    
    def can_handle(self, event_type: str, payload: Dict[str, Any]) -> bool:
        """Check if this handler can process authority events."""
        return event_type in ['authority_recalculation', 'push']
    
    def handle(self, payload: Dict[str, Any]) -> bool:
        """Handle authority recalculation event."""
        try:
            # Check if authority-related files changed
            changed_files = self._get_changed_files(payload)
            authority_files = [f for f in changed_files if 'authority' in f.lower()]
            
            if not authority_files:
                self.logger.debug("No authority files changed in event")
                return True
            
            self.logger.info(f"Authority changes detected: {authority_files}")
            
            # In full implementation, this would:
            # 1. Validate changed authority files
            # 2. Recalculate lending capacity for affected identities
            # 3. Update authority records
            # 4. Notify affected parties
            
            return True
            
        except Exception as e:
            self.logger.exception(f"Error handling authority recalculation: {e}")
            return False
    
    def _get_changed_files(self, payload: Dict[str, Any]) -> list:
        """Extract list of changed files from push event."""
        commits = payload.get('commits', [])
        files = []
        for commit in commits:
            files.extend(commit.get('added', []))
            files.extend(commit.get('modified', []))
        return files


def main():
    """Main entry point for testing the event router."""
    import json
    
    # Create router
    router = create_router('default')
    
    # Test events
    test_events = [
        (
            'push',
            {
                'ref': 'refs/heads/main',
                'commits': [
                    {
                        'added': ['identity/new-identity.json'],
                        'modified': [],
                        'id': 'abc123'
                    }
                ]
            }
        ),
        (
            'pull_request',
            {
                'action': 'opened',
                'pull_request': {
                    'number': 42,
                    'title': 'Update permission matrix'
                }
            }
        )
    ]
    
    # Process test events
    for event_type, payload in test_events:
        success, message = router.handle_event(event_type, payload)
        print(f"Event {event_type}: {success} - {message}")


if __name__ == '__main__':
    main()
