# Annual Review Workflow

This document defines the yearly governance review process for the Personal Credit Authority. The annual review ensures that governance rules remain effective, compliant with evolving requirements, and aligned with system goals.

## Overview

The Personal Credit Authority conducts an annual review to evaluate the effectiveness of governance arrangements, assess compliance with policies and regulations, identify areas for improvement, and make recommendations for changes. The review process involves multiple stakeholders, follows a structured methodology, and produces documented findings and recommendations.

The annual review serves as the primary mechanism for ensuring that the governance framework remains fit for purpose as the system evolves and as the external environment changes. It provides accountability to stakeholders by demonstrating that governance is actively managed and continuously improved.

The review cycle aligns with the calendar year, with the review process occurring during the first quarter of each year. This timing allows findings from the prior year to be incorporated into the current year's operations while maintaining sufficient distance from year-end activities to enable objective assessment.

## Review Scope

The annual review encompasses all aspects of the Personal Credit Authority's governance framework. This comprehensive scope ensures that all governance elements are regularly examined and that interactions between elements are understood.

### Governance Framework Review

The governance framework review examines the fundamental governance structure and principles. This includes evaluating whether the governance principles remain appropriate and effective, whether the governance structure provides adequate oversight and accountability, whether roles and responsibilities are clearly defined and appropriately assigned, and whether decision-making processes are effective and efficient.

The framework review considers both the formal structure as documented in governance.json and the practical operation of governance. Discrepancies between documented policies and actual practice are identified and addressed. The review also considers whether the framework is appropriately aligned with system goals and stakeholder needs.

### Domain-Specific Reviews

Each governance domain undergoes detailed review as part of the annual process. The identity domain review examines the effectiveness of identity verification processes, the adequacy of attestation requirements, and the appropriateness of verification levels and their associated capabilities.

The authority domain review evaluates the lending capacity calculation methodology, the accuracy of risk tier assessments, and the effectiveness of lending limits. The review examines whether capacity calculations produce appropriate results and whether risk tier assignments are consistent and accurate.

The permission domain review assesses the effectiveness of access controls, the appropriateness of role definitions and permissions, and the adequacy of override and freeze mechanisms. The review considers whether permissions follow the principle of least privilege and whether security controls are appropriately implemented.

The governance domain review examines the effectiveness of governance procedures, the adequacy of audit and compliance mechanisms, and the appropriateness of amendment processes. The review also considers whether the governance documentation is complete and current.

### Compliance Review

The compliance review examines adherence to regulatory requirements and internal policies. This includes assessing compliance with relevant regulatory frameworks such as SOX, PCI-DSS, and GDPR, evaluating adherence to internal policies and procedures, reviewing the effectiveness of compliance monitoring and testing, and examining the handling of any compliance issues identified during the year.

The compliance review produces a compliance status assessment that identifies any areas of non-compliance and tracks remediation activities. The assessment is provided to the governance board and forms part of the annual compliance reporting.

### Risk Review

The risk review examines the risk landscape and the effectiveness of risk management controls. This includes assessing the current risk profile and any changes from the prior year, evaluating the effectiveness of risk mitigation controls, reviewing risk tolerance statements and risk appetite, and identifying emerging risks that may require attention.

The risk review informs the risk management priorities for the coming year and may result in adjustments to risk tolerances or control requirements.

## Review Team

The annual review is conducted by a team with appropriate expertise and independence. The team composition ensures that all aspects of governance receive competent scrutiny.

### Core Review Team

The core review team consists of the compliance officer who leads the review process and ensures completeness and quality, an independent auditor who provides objective assessment of controls and compliance, a system administrator who provides technical perspective on system operations, and a governance board representative who ensures board-level oversight and accountability.

The core team works together throughout the review process, with each member contributing expertise in their area while maintaining awareness of the overall review scope.

### Extended Team

Extended team members participate in specific review areas based on their expertise. Domain experts from identity, authority, permission, and governance areas participate in domain-specific reviews. Legal counsel participates in compliance reviews with regulatory implications. External advisors may be engaged for specialized assessments such as security assessments or regulatory consultations.

### Independence Requirements

Review team members must be independent from the areas they review. This means that no team member may review their own work or areas where they have significant personal involvement. The independence requirement ensures objective assessment and avoids conflicts of interest.

Team members disclose any potential conflicts at the beginning of the review process. Conflicts are evaluated and may result in reassignment of review responsibilities or additional oversight of the affected team member.

## Review Timeline

The annual review follows a structured timeline that ensures thoroughness while completing the review within the target timeframe. The timeline spans approximately twelve weeks from initiation to completion.

### Preparation Phase (Weeks 1-2)

The preparation phase establishes the review framework and gathers preliminary information. Activities include confirming the review scope and team composition, finalizing review procedures and checklists, requesting documentation from relevant parties, and scheduling review activities and interviews.

During this phase, the compliance officer prepares a review planning document that outlines the scope, methodology, timeline, and resource requirements. The planning document is reviewed and approved by the governance board before the review begins.

### Data Collection Phase (Weeks 3-5)

The data collection phase gathers the information needed to assess governance effectiveness. Activities include reviewing documentation including policies, procedures, and records, conducting interviews with key personnel, collecting and analyzing operational data, and examining audit logs and compliance reports.

Documentation review examines all relevant governance documents including the governance framework, domain-specific rules, procedures, and records of decisions. The review assesses whether documentation is complete, current, and consistent with actual practice.

Interviews are conducted with personnel involved in governance activities. Interviews follow a structured format but allow flexibility for follow-up questions based on responses. Interview notes are documented and form part of the review evidence.

Operational data collection includes metrics on system operations, compliance monitoring results, incident reports, and performance data. This quantitative data provides objective evidence of governance effectiveness.

### Analysis Phase (Weeks 6-8)

The analysis phase evaluates the collected information to form findings and recommendations. Activities include assessing governance effectiveness against requirements and best practices, identifying gaps, weaknesses, or areas for improvement, analyzing trends and patterns in the data, and developing findings and recommendations.

Analysis applies consistent criteria across all review areas. Criteria include effectiveness in achieving governance objectives, efficiency in resource utilization, compliance with requirements, consistency with best practices, and alignment with system goals.

Findings are developed through synthesis of evidence and application of professional judgment. Each finding includes a statement of the condition observed, the criteria against which it was assessed, the evidence supporting the finding, and the risk or impact if the finding is not addressed.

### Reporting Phase (Weeks 9-10)

The reporting phase documents the review findings and recommendations. Activities include drafting the annual review report, reviewing findings with relevant parties, finalizing recommendations, and presenting the report to the governance board.

The annual review report provides a comprehensive summary of the review process and findings. The report includes an executive summary for board-level overview, detailed findings organized by review area, recommendations with priorities and implementation guidance, and appendices with supporting documentation.

Findings are shared with relevant personnel before finalizing the report to ensure factual accuracy. Feedback received is considered and incorporated as appropriate.

### Follow-Up Phase (Weeks 11-12 and Ongoing)

The follow-up phase establishes accountability for addressing review findings. Activities include agreeing on action plans for recommendations, assigning responsibility and deadlines, establishing tracking mechanisms, and reporting progress to the governance board.

Action plans address each recommendation with specific activities, responsible parties, timelines, and success measures. Plans are reviewed and approved by the governance board before implementation begins.

Progress on action plans is tracked and reported to the governance board quarterly until all items are complete. Outstanding items are escalated when deadlines are missed or when issues require additional attention.

## Review Activities

The annual review encompasses specific activities designed to thoroughly assess each aspect of governance.

### Documentation Review

Documentation review examines all governance-related documents for completeness, currency, and consistency. The review verifies that policies and procedures are documented, that documentation is current with any approved changes, and that documentation is consistent across domains and with actual practice.

Documentation gaps are identified and noted as findings. Documentation that does not reflect actual practice indicates potential training or communication issues that should be addressed.

### Process Observation

Process observation assesses whether governance processes operate as intended. The review observes key processes including decision-making processes, compliance monitoring, incident handling, and change management. Observation identifies whether processes are followed consistently and whether they achieve their intended outcomes.

Process observations are compared against documented procedures to identify gaps. Significant discrepancies between documented and actual practice result in findings and recommendations for process improvement or documentation update.

### Metrics Review

Metrics review examines quantitative indicators of governance effectiveness. Metrics reviewed include compliance rates, audit results, incident counts and trends, decision-making timeliness, and system performance indicators. Metrics are analyzed to identify trends and to benchmark against targets or prior periods.

Metrics that fall outside acceptable ranges trigger deeper investigation to identify root causes. Trends are assessed to determine whether improvements or deteriorations are occurring and whether intervention is needed.

### Control Testing

Control testing verifies that governance controls operate effectively. Tests include access control testing to verify that permissions are properly configured and enforced, verification testing to confirm that identity verification procedures are followed, and calculation testing to validate that lending capacity calculations are accurate.

Testing uses sampling techniques appropriate to the risk level of the control being tested. Higher-risk controls receive more extensive testing. Test results are documented and form part of the review evidence.

### Interview Program

Interview program conduct structured interviews with key personnel. Interviewees include administrators, compliance personnel, domain experts, and governance board members. Interviews assess understanding of governance requirements, awareness of responsibilities, and perception of governance effectiveness.

Interview responses are analyzed for consistency with documentation and other evidence. Discrepancies are investigated and may indicate documentation issues or training needs.

## Review Criteria

Assessment criteria ensure consistent evaluation across all review areas. Criteria are derived from regulatory requirements, industry best practices, and system-specific needs.

### Effectiveness Criteria

Effectiveness criteria assess whether governance achieves its intended outcomes. Questions include whether governance processes produce the expected results, whether controls are adequate to manage identified risks, whether decisions are appropriate and consistent, and whether issues are identified and addressed promptly.

### Efficiency Criteria

Efficiency criteria assess whether governance achieves outcomes with appropriate resource utilization. Questions include whether processes are streamlined and avoid unnecessary complexity, whether automation is used where appropriate, whether duplicate efforts are avoided, and whether resources are deployed effectively.

### Compliance Criteria

Compliance criteria assess adherence to requirements. Questions include whether all applicable regulatory requirements are met, whether internal policies are followed consistently, whether audit findings are addressed appropriately, and whether compliance issues are identified and remediated.

### Consistency Criteria

Consistency criteria assess whether governance is applied uniformly. Questions include whether similar situations receive similar treatment, whether decision criteria are applied consistently, whether processes are followed consistently across areas, and whether documentation reflects actual practice.

## Output Documentation

The annual review produces several documents that capture findings, recommendations, and action plans.

### Annual Review Report

The annual review report is the primary output of the review process. The report provides a comprehensive summary of findings and recommendations. The report structure includes an executive summary that provides a high-level overview for board-level readers, a methodology section describing the review scope and approach, detailed findings organized by review area, an overall assessment of governance effectiveness, and recommendations with priorities and implementation guidance.

The report is prepared by the compliance officer and reviewed by the full review team before presentation to the governance board. The report is a confidential document intended for governance board and senior management.

### Management Response

The management response documents management's acceptance of findings and commitment to action. The response includes acceptance or rejection of each finding, agreed actions for addressing findings, responsible parties and timelines, and resource requirements.

The management response is prepared by system administrators in collaboration with the compliance officer. The response is reviewed and approved by the governance board.

### Action Plan

The action plan translates agreed recommendations into specific implementation steps. Each recommendation is broken down into actionable tasks with clear owners and deadlines. The plan includes progress tracking mechanisms and escalation procedures for delayed items.

Action plans are living documents that are updated as implementation progresses. Status updates are provided to the governance board quarterly until all actions are complete.

### Compliance Certificate

The compliance certificate provides an official statement of compliance status. The certificate summarizes the review findings, states the overall compliance assessment, and identifies any areas of non-compliance. The certificate is signed by the compliance officer and presented to the governance board.

## Governance Board Review

The governance board provides oversight of the annual review process and receives review findings and recommendations.

### Board Briefing

The governance board receives a briefing on the annual review at the conclusion of the review process. The briefing includes a summary of review findings, the overall assessment of governance effectiveness, and recommended priorities for the coming year. Board members have the opportunity to ask questions and request additional information.

The briefing is provided by the compliance officer with participation from other review team members as needed. The briefing format balances completeness with board members' time constraints.

### Board Discussion

The governance board discusses the review findings and their implications. Discussion topics include the overall assessment of governance effectiveness, the priority of findings and recommendations, resource requirements for implementation, and any policy or governance changes needed.

Board discussion may result in modifications to recommendations or the establishment of different priorities. The board's direction is documented in the meeting minutes.

### Board Approval

The governance board approves the annual review report and management response. Approval establishes the official record of the review findings and management's commitment to action. Approved documents are retained as permanent records.

## Continuous Improvement

The annual review supports continuous improvement of governance through identification and addressing of weaknesses and adoption of best practices.

### Finding Tracking

All findings from the annual review are tracked until resolved. The tracking system maintains visibility of outstanding findings, monitors progress on remediation, and provides reporting on finding status and age.

Finding categories include critical findings requiring immediate attention, high-priority findings requiring short-term remediation, medium-priority findings requiring remediation within the year, and low-priority findings that should be addressed when practical.

### Trend Analysis

Trend analysis examines findings and metrics across multiple review periods to identify patterns. Trends may reveal deteriorating controls, persistent weaknesses, or improving performance. Trend analysis informs priorities and resource allocation.

Significant adverse trends trigger additional scrutiny and may result in accelerated remediation or enhanced monitoring. Positive trends are recognized and inform best practice identification.

### Best Practice Identification

The review process identifies best practices observed during the review. Best practices are documented and shared across domains to promote adoption. Best practice identification supports continuous improvement through learning from effective approaches.

Best practices are considered for formal incorporation into governance documentation. Adoption of best practices is tracked and measured as part of the review process.

## Review Schedule

The annual review follows a regular schedule that enables consistent execution and stakeholder planning.

### Calendar Year Review

The annual review is conducted during the first quarter of each year, covering the prior calendar year. This timing aligns with regulatory reporting cycles and enables findings to inform the current year's planning.

The review schedule is published at the beginning of each year, enabling stakeholders to plan for participation. Key dates include the review initiation, data collection period, draft report availability, and board presentation.

### Ad Hoc Reviews

In addition to the annual review, ad hoc reviews may be conducted in response to significant events. Triggers for ad hoc reviews include major system changes, significant incidents, regulatory changes, and governance board requests.

Ad hoc reviews follow a streamlined process focused on the specific trigger while maintaining appropriate rigor. The scope and timeline of ad hoc reviews are determined based on the triggering event.

## Quality Assurance

Quality assurance ensures that the annual review produces reliable findings and recommendations.

### Review Methodology

The review methodology is documented and periodically assessed for effectiveness. Methodology reviews consider whether the approach produces complete and accurate findings, whether the methodology is consistently applied, and whether the methodology incorporates best practices.

Methodology improvements are incorporated into subsequent reviews. Significant methodology changes are documented and approved by the governance board.

### Peer Review

Review findings are subject to peer review by qualified individuals not involved in the current review. Peer review provides an independent check on the quality and accuracy of findings. Peer review comments are addressed before finalizing the review report.

### Review Effectiveness Assessment

The effectiveness of the annual review process is assessed periodically. Assessment considers whether the review identified significant issues, whether recommendations were implemented effectively, and whether the review provided value commensurate with its cost.

Assessment findings inform improvements to the review process. The review effectiveness assessment is conducted by the governance board with input from the review team.
