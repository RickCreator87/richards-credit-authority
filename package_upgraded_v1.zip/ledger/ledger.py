import json
from datetime import datetime

LEDGER_FILE = "ledger/ledger.json"

def create_ledger_entry(loan_id, amount, entry_type):
    entry = {
        "loan_id": loan_id,
        "amount": amount,
        "type": entry_type,
        "timestamp": datetime.utcnow().isoformat()
    }
    try:
        with open(LEDGER_FILE, "r") as f:
            ledger = json.load(f)
    except FileNotFoundError:
        ledger = []

    ledger.append(entry)
    with open(LEDGER_FILE, "w") as f:
        json.dump(ledger, f, indent=2)

    return entry
