# Architecture

System design overview.