# Authority Matrix

Roles and powers.