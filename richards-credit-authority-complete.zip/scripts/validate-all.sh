#!/bin/bash
echo Validating all