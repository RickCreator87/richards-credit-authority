# Validation Rules

Global validation logic.